﻿var Managers;
(function (Managers) {
    var AudioSoundFX = (function () {
        function AudioSoundFX(game) {
            this.game = game;

            this.errorSound = new Kiwi.Sound.Audio(this.game, 'errorButton', 1, false);
            this.successSound = new Kiwi.Sound.Audio(this.game, 'successButton', 1, false);
        }
        AudioSoundFX.prototype.playError = function () {
            if (!this.game.muteSFX)
                this.errorSound.play('default', true);
        };

        AudioSoundFX.prototype.playSuccess = function () {
            if (!this.game.muteSFX)
                this.successSound.play('default', true);
        };
        return AudioSoundFX;
    })();
    Managers.AudioSoundFX = AudioSoundFX;
})(Managers || (Managers = {}));
var Managers;
(function (Managers) {
    var GameDataManager = (function () {
        function GameDataManager(game) {
            this.game = game;

            this.userManager = this.game.userManager;

            this.leaderboard = this.game.gfleaderboard;
        }
        GameDataManager.prototype.getGameStats = function (callback, context, offset, max) {
            this.leaderboard.getData(callback, context, null, offset, max);
        };

        GameDataManager.prototype.postStats = function (dataMain, dataSecondary) {
            this.postMainUserStats(dataMain, function (success, info) {
                //Post the secondary user stats
                this.postSecondaryUserStats(dataSecondary, function (success, info) {
                    console.log('Posted!');
                }, this);
            }, this);
        };

        GameDataManager.prototype.postUserStats = function (username, data, callback, context) {
            //Get the main users stats,
            this.leaderboard.getData(function (error, info) {
                //Increment if there, otherwise add
                if (info.err) {
                    this.leaderboard.setData(callback, context, username, data);
                } else if (typeof info.data == "string") {
                    //Merge the datas
                    var finalData = {};
                    var type = null;
                    var index = null;

                    try  {
                        info.data = JSON.parse(info.data);
                    } catch (e) {
                        //Failed to parse the json. Skip this step
                        callback.call(context);
                        return;
                    }

                    for (index in info.data) {
                        finalData[index] = info.data[index];
                    }

                    for (index in data) {
                        type = typeof finalData[index];
                        if (type == "undefined") {
                            finalData[index] = data[index];
                        } else if (type == "number") {
                            finalData[index] += data[index];
                        }
                    }

                    //Calculate what the users score should be
                    var score = 0;
                    var wins = finalData.wins;
                    var losses = finalData.losses;

                    if (losses == 0)
                        losses = 0.001;
                    if (wins == 0)
                        wins = 0.001;

                    score = (wins / losses) * 1000 + (wins + losses) * 100;

                    this.leaderboard.updateData(callback, context, username, finalData, score);
                }
            }, this, username);
        };

        GameDataManager.prototype.postMainUserStats = function (data, callback, context) {
            if (this.userManager.currentMainUser.isValid) {
                this.postUserStats(this.userManager.currentMainUser.name, data, callback, context);
            } else {
                callback.call(context);
            }
        };

        GameDataManager.prototype.postSecondaryUserStats = function (data, callback, context) {
            if (this.userManager.secondaryUser.isValid) {
                this.postUserStats(this.userManager.secondaryUser.name, data, callback, context);
            } else {
                callback.call(context);
            }
        };
        return GameDataManager;
    })();
    Managers.GameDataManager = GameDataManager;
})(Managers || (Managers = {}));
var Managers;
(function (Managers) {
    var PurchaseManager = (function () {
        function PurchaseManager(game) {
            this.sandbox = true;
            this.managedMode = true;
            this.game = game;

            this.inAppPurchase = this.game.inAppPurchase;

            //Add Events
            this.game.inAppPurchase.onFetchFailed.add(this.fetchFailed, this);
            this.game.inAppPurchase.onFetchComplete.add(this.fetchComplete, this);
            this.game.inAppPurchase.onPurchaseFailed.add(this.purchaseFailed, this);
            this.game.inAppPurchase.onPurchaseComplete.add(this.purchaseComplete, this);
            this.game.inAppPurchase.onConsumeComplete.add(this.consumeComplete, this);

            this.productIds = [
                'io.gamelab.standoff.raider',
                'io.gamelab.standoff.invader',
                'io.gamelab.standoff.conqueror'
            ];

            this.productValues = [
                1200,
                3000,
                7000
            ];

            this.game.inAppPurchase.addProducts = true;
            this.game.inAppPurchase.autoConsume = true;

            this.game.inAppPurchase.init(this.managedMode, this.sandbox);
        }
        PurchaseManager.prototype.getValidProducts = function (fetchCallback, fetchContext) {
            this.fetchCallback = fetchCallback;
            this.fetchContext = fetchContext;

            this.game.inAppPurchase.fetchProductsFromStore(this.productIds);
        };

        PurchaseManager.prototype.purchase = function (product, purchaseCallback, purchaseContext) {
            this.purchaseCallback = purchaseCallback;
            this.purchaseContext = purchaseContext;

            this.game.inAppPurchase.purchaseProduct(product.productId);
        };

        PurchaseManager.prototype.fetchFailed = function () {
            this.fetchCallback.call(this.fetchContext, false);
        };

        PurchaseManager.prototype.fetchComplete = function (products) {
            this.validProducts = products;
            this.fetchCallback.call(this.fetchContext, true, this.validProducts);
        };

        PurchaseManager.prototype.purchaseFailed = function (productId, error) {
            this.purchaseCallback.call(this.purchaseContext, false);
        };

        PurchaseManager.prototype.purchaseComplete = function (purchase) {
            if (purchase.purchaseState == CocoonJS.Store.PurchaseState.PURCHASED) {
                this.game.commodityManager.unlockElitePurchaseable();

                switch (purchase.productId) {
                    case this.productIds[0]:
                        this.game.commodityManager.increaseCredits(this.productValues[0] * purchase.quantity);
                        break;
                    case this.productIds[1]:
                        this.game.commodityManager.increaseCredits(this.productValues[1] * purchase.quantity);
                        break;
                    case this.productIds[2]:
                        this.game.commodityManager.increaseCredits(this.productValues[2] * purchase.quantity);
                        break;
                    default:
                        this.game.commodityManager.increaseCredits(1500);
                        break;
                }
            }

            this.purchaseCallback.call(this.purchaseContext, true, purchase);
        };

        PurchaseManager.prototype.consumeComplete = function () {
            //Can buy it again!!
        };
        return PurchaseManager;
    })();
    Managers.PurchaseManager = PurchaseManager;
})(Managers || (Managers = {}));
var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var MenuEntities;
(function (MenuEntities) {
    var LeaderboardStat = (function (_super) {
        __extends(LeaderboardStat, _super);
        function LeaderboardStat(state, num, userData, x, y, currentPlayer) {
            _super.call(this, state);
            this.x = x;
            this.y = y;

            this.userData = userData;

            var texture = this.state.textures.leaderboardPlayerPanel;
            if (currentPlayer) {
                texture = this.state.textures.leaderboardCurrentPlayerPanel;
            }

            this.background = new Kiwi.GameObjects.StaticImage(this.state, texture, 0, 0);

            this.nameText = new Kiwi.GameObjects.Textfield(this.state, this.userData.user.toUpperCase(), 15, 5, '#000', 18);
            this.winText = new Kiwi.GameObjects.Textfield(this.state, this.userData.data.wins, 530, 5, '#000', 18);
            this.winText.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;
            this.loseText = new Kiwi.GameObjects.Textfield(this.state, this.userData.data.losses, 625, 5, '#000', 18);
            this.loseText.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;

            this.addChild(this.background);
            this.addChild(this.winText);
            this.addChild(this.loseText);
            this.addChild(this.nameText);
        }
        return LeaderboardStat;
    })(Kiwi.Group);
    MenuEntities.LeaderboardStat = LeaderboardStat;
})(MenuEntities || (MenuEntities = {}));
var CocoonJS;
(function (CocoonJS) {
    var Product = (function () {
        function Product() {
        }
        return Product;
    })();
    CocoonJS.Product = Product;
})(CocoonJS || (CocoonJS = {}));
var CocoonJS;
(function (CocoonJS) {
    var Purchase = (function () {
        function Purchase() {
        }
        return Purchase;
    })();
    CocoonJS.Purchase = Purchase;
})(CocoonJS || (CocoonJS = {}));
var MenuEntities;
(function (MenuEntities) {
    var StoreProduct = (function (_super) {
        __extends(StoreProduct, _super);
        function StoreProduct(state, imageTexture, productId, x, y, purchaseCallback, purchaseContext) {
            _super.call(this, state);
            this.x = x;
            this.y = y;

            this.visible = false;

            this.productId = productId;

            this.buyButton = new MenuEntities.BuyCreditsButton(this.state, 2, 255);
            this.productImage = new Kiwi.GameObjects.Sprite(this.state, imageTexture, 0, 0);
            this.priceText = new Kiwi.GameObjects.Textfield(this.state, '$1.99', 70, 206, '#000', 25, 'normal', 'venusRisingFont');
            this.priceText.textAlign = 'center';

            this.input = this.buyButton.input;
            this.input.onUp.add(purchaseCallback, purchaseContext);
            this.input.enabled = false;

            this.addChild(this.productImage);
            this.addChild(this.buyButton);
            this.addChild(this.priceText);
        }
        Object.defineProperty(StoreProduct.prototype, "isValid", {
            get: function () {
                return (typeof this.product !== "undefined");
            },
            enumerable: true,
            configurable: true
        });

        StoreProduct.prototype.assign = function (product) {
            this.product = product;
            this.visible = true;
            this.input.enabled = true;

            var text = String(product.localizedPrice);

            /*
            if (text.indexOf('$') == -1) {
            text = '$' + text;
            }
            */
            this.priceText.text = text;
        };
        return StoreProduct;
    })(Kiwi.Group);
    MenuEntities.StoreProduct = StoreProduct;
})(MenuEntities || (MenuEntities = {}));
var Tiles;
(function (Tiles) {
    var Tile = (function (_super) {
        __extends(Tile, _super);
        function Tile(state, cacheID, x, y, num) {
            _super.call(this, state, cacheID, x * state.parameters.TILE_WIDTH, Math.floor(y * state.parameters.TILE_HEIGHT));
            this.friction = 1;
            this.solid = false;
            this.death = false;
            this.trench = false;
            this.occupied = false;
            this.my_x = x;
            this.my_y = y;
            this.name = 't' + y + '_' + x;
            this.id = this.name;
        }
        return Tile;
    })(Kiwi.GameObjects.Sprite);
    Tiles.Tile = Tile;
})(Tiles || (Tiles = {}));
var Managers;
(function (Managers) {
    var WebviewManager = (function () {
        function WebviewManager(game) {
            this.game = game;
            this.available = false;

            this.wv = this.game.wvmessager;
            this.wv.onMessage(this.messageRecieved, this);

            this.attempts = 0;
            this.maxAttempts = 2;

            this.userManager = this.game.userManager;

            this.load();
        }
        WebviewManager.prototype.load = function () {
            this.attempts++;

            console.log('Loading Attempt');

            this.wv.loadWebview('./WebViewStandOff.html', function () {
                this.available = true;
            }, function () {
                if (this.attempts >= this.maxAttempts) {
                    this.available = false;
                } else {
                    //Try again
                    this.load();
                }
            }, this);
        };

        WebviewManager.prototype.showLogin = function (callback, context, title, username) {
            if (typeof title === "undefined") { title = 'Login'; }
            if (typeof username === "undefined") { username = ''; }
            this.callback = callback;
            this.context = context;
            this.game.wvmessager.show();
            this.send('login', { title: title, username: username });
        };

        WebviewManager.prototype.showRegister = function (callback, context, title) {
            if (typeof title === "undefined") { title = 'Create an Account'; }
            this.callback = callback;
            this.context = context;
            this.game.wvmessager.show();
            this.send('register', { title: title });
        };

        WebviewManager.prototype.send = function (message, data) {
            if (typeof data === "undefined") { data = null; }
            this.wv.sendMessage(message, data);
        };

        WebviewManager.prototype.messageRecieved = function (message, data) {
            switch (message) {
                case 'login':
                    this.userManager.login(data.username, data.password, function (loggedIn, user) {
                        if (loggedIn == false) {
                            //Send error to main screen.
                            this.send('error-login', 'You were not logged in. Please ensure you have an internet connection and that the details you entered are correct.');
                        } else {
                            this.callback.call(this.context, 'login', true, user);
                            this.send('hideAll');
                        }
                    }, this);

                    break;

                case 'register':
                    this.userManager.registerUser(data.username, data.email, data.password, data.confpass, data.terms, function (registered, details, user) {
                        if (registered) {
                            this.callback.call(this.context, 'register', true, user);
                            this.send('hideAll');
                        } else {
                            //Send error to main screen.
                            this.send('error-reg', details.getFirstMessage());
                        }
                    }, this);

                    break;

                case 'closed':
                    this.callback.call(this.context, 'closed');
                    break;
            }
        };
        return WebviewManager;
    })();
    Managers.WebviewManager = WebviewManager;
})(Managers || (Managers = {}));
var StandOff;
(function (StandOff) {
    var MessageHandler = (function () {
        function MessageHandler() {
            this.activeMessages = [];
            this.archivedMessages = [];
        }
        MessageHandler.prototype.clearActiveMessages = function () {
            //Moves to the archived messages
            this.archivedMessages.push(this.activeMessages);

            //Clears the active messages
            this.activeMessages = {};
        };

        MessageHandler.prototype.leaveMessage = function (key, message) {
            this.activeMessages[key] = message;
        };

        MessageHandler.prototype.anyActiveMessages = function () {
            for (var index in this.activeMessages) {
                return true;
            }
            return false;
        };

        MessageHandler.prototype.getFirstMessage = function () {
            for (var index in this.activeMessages) {
                return this.activeMessages[index];
            }

            return null;
        };

        MessageHandler.prototype.getMessage = function (key) {
            if (this.messageExists(key)) {
                return this.activeMessages[key];
            } else {
                return '';
            }
        };

        MessageHandler.prototype.messageExists = function (key) {
            if (Kiwi.Utils.Common.isUndefined(this.activeMessages[key]) == false) {
                return true;
            } else {
                return false;
            }
        };
        return MessageHandler;
    })();
    StandOff.MessageHandler = MessageHandler;
})(StandOff || (StandOff = {}));
/**
* User
**/
var StandOff;
(function (StandOff) {
    var User = (function () {
        function User(name, email, guest, id) {
            if (typeof id === "undefined") { id = '0'; }
            this.name = name || '';
            this.email = email;
            this.guest = guest;
            this.id = id;
            this.validated = false;
        }
        Object.defineProperty(User.prototype, "isValid", {
            get: function () {
                return (this.guest == true) ? false : this.validated;
            },
            enumerable: true,
            configurable: true
        });
        return User;
    })();
    StandOff.User = User;
})(StandOff || (StandOff = {}));
var Managers;
(function (Managers) {
    var UserManager = (function () {
        function UserManager(game) {
            this.guestAccount = new StandOff.User('Guest', null, true);

            this.game = game;
            this.users = [this.guestAccount];

            //Get all saved users
            this.getUsers();

            this.currentMainUser = this.guestAccount;

            this.secondaryUser = this.guestAccount;

            this.errors = new StandOff.MessageHandler();
        }
        UserManager.prototype.addUser = function (userData, save) {
            var name = userData.name || userData.username;

            var user = new StandOff.User(name, userData.email, false, userData.id);
            this.users.push(user);

            if (save) {
                this.saveUsers();
            }

            return user;
        };

        UserManager.prototype.saveUsers = function () {
            var rawUserData = [];
            var len = this.users.length;
            var user = null;

            while (len--) {
                var user = this.users[len];
                if (!user.guest) {
                    rawUserData.push({ id: user.id, email: user.email, name: user.name });
                }
            }

            this.game.saveManager.add('UserData', rawUserData, true);
        };

        UserManager.prototype.getUsers = function () {
            this.users = [this.guestAccount];
            if (this.game.saveManager.exists('UserData') == false)
                return;

            var userData = this.game.saveManager.getData('UserData');
            var len = userData.length;
            var user = null;

            while (len--) {
                var user = userData[len];
                this.addUser({ name: user.name, email: user.email, id: user.id }, false);
            }
        };

        UserManager.prototype.userExists = function (username) {
            for (var i = 0; i < this.users.length; i++) {
                if (this.users[i].name == username) {
                    return this.users[i];
                }
            }

            return null;
        };

        UserManager.prototype.login = function (username, password, callback, context) {
            //Create URL
            var data = { username: username, password: password };
            var loginAttempt = this.game.gf.login(data, function (trans, data) {
                if (trans) {
                    callback.call(context, false);
                } else if (data.result && data.result == 'fail') {
                    callback.call(context, false);
                } else {
                    //Does that user already exist?
                    var existingUser = this.userExists(data.name);

                    if (existingUser !== null) {
                        var user = existingUser;
                        existingUser.validated = true;
                    } else {
                        var user = this.addUser(data, true);
                        user.validated = true;
                    }

                    callback.call(context, true, user);
                }
            }, this);

            if (loginAttempt == false) {
                callback.call(context, false);
            }
        };

        UserManager.prototype.registerUser = function (userName, email, pass, confPass, terms, callback, context) {
            this.errors.clearActiveMessages();

            //Username
            if (Kiwi.Utils.Common.isUndefined(userName) || !userName) {
                this.errors.leaveMessage('username', 'You need to enter a username.');
            } else {
                userName = userName;
            }

            //Email
            if (Kiwi.Utils.Common.isUndefined(email) || !email) {
                this.errors.leaveMessage('email', 'Please enter a email.');
            } else {
                //Validate email
                email = email;
            }

            //Confirm Password
            if (Kiwi.Utils.Common.isUndefined(confPass)) {
                this.errors.leaveMessage('confPass', 'You need to confirm your password.');
            }

            //Password
            if (Kiwi.Utils.Common.isUndefined(pass) || !pass) {
                this.errors.leaveMessage('pass', 'You need to supply a password.');
            } else {
                if (pass !== confPass) {
                    this.errors.leaveMessage('pass', 'The password and confirmation fields do not match.');
                }
            }

            //Terms and Conditions
            if (Kiwi.Utils.Common.isUndefined(terms) || terms == false) {
                this.errors.leaveMessage('terms', 'You need to accept the Terms and Conditions.');
            }

            if (this.errors.anyActiveMessages()) {
                //Error out
                callback.call(context, false, this.errors);
            } else {
                //Register the user
                var data = {
                    username: userName,
                    password: pass,
                    email: email,
                    passwordrepeat: confPass
                };

                var registerAttempt = this.game.gf.register(data, function (transerror, info) {
                    if (transerror) {
                        this.errors.leaveMessage('final', 'You cannot register right now. Please try again soon.');
                        callback.call(context, false, this.errors);
                        return;
                    }

                    if (info.result == "success") {
                        //Add the user here...
                        var user = this.addUser(data, true);
                        user.validated = true;
                        callback.call(context, true, 'You have successfully registered', user);
                        return;
                    }

                    switch (info.reason) {
                        case 'email':
                        case 'emai':
                            this.errors.leaveMessage('email', 'That email has already been used.');
                            break;

                        case 'confirm':
                            this.errors.leaveMessage('pass', 'Your passwords do not match.');
                            break;

                        case 'username':
                        case 'user':
                            this.errors.leaveMessage('pass', 'A user with this username already exists.');
                            break;
                    }

                    callback.call(context, false, this.errors);
                }, this);

                if (registerAttempt == false) {
                    this.errors.leaveMessage('fail', 'Please ensure all the fields have values entered.');
                    callback.call(context, false, this.errors);
                }
            }
        };
        return UserManager;
    })();
    Managers.UserManager = UserManager;
})(Managers || (Managers = {}));
var Managers;
(function (Managers) {
    var StatManager = (function () {
        function StatManager() {
            this.playerMain = new StandOffEntities.player();
            this.playerSecondary = new StandOffEntities.player();
        }
        StatManager.prototype.doAction = function () {
        };

        StatManager.prototype.updateStat = function (type, amount, side) {
            if (side == 1) {
                this.playerMain[type] += amount;
            } else {
                this.playerSecondary[type] += amount;
            }
        };

        StatManager.prototype.endWave = function () {
        };
        return StatManager;
    })();
    Managers.StatManager = StatManager;
})(Managers || (Managers = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var movingContent = (function (_super) {
        __extends(movingContent, _super);
        //this['mouseStartX' + num], this['mouseStartY' + num], line.angle, num, type, level, formBool
        function movingContent(state, textureID, angle, x, y, side, nodeType, type) {
            _super.call(this, state, textureID);
            //static
            this.contentType = 0;
            this.type = 0;
            this.level = 0;
            this.side = 0;
            this.col = 0;
            //changed during gameplay
            this.angle = 0;
            this.baseHealth = 50;
            this.health = 50;
            this.alive = true;
            this.formation = false;
            //decrementing variable counting down when on fire
            this.fireVar = 0;
            this.shootDelay = 5;
            this.shootVar = 0;
            this.baseVelocity = 0.5;
            this.baseFriction = 1;
            this.friction = 1;
            this.xVelocity = 0;
            this.yVelocity = 0;
            this.myWidth = 50;
            this.hitWidth = 50;
            this.myHeight = 75;
            this.my_x = 0;
            this.my_y = 0;
            this.tx = 0;
            this.ty = 0;
            this.x_offset = 0;
            this.y_offset = 20;
            this.circling = false;
            //moving toward flare
            this.flaring = false;
            this.flareXVelocity = 0;
            this.flareYVelocity = 0;
            this.moving = true;
            this.walkRotation = 0;
            //shooting the shit
            this.range1 = 100;
            this.range2 = 200;
            this.range3 = 300;
            //accuracy
            this.acc1 = 0.9;
            this.acc2 = 0.7;
            this.acc3 = 0.5;
            this.riflemanAtt = 10;
            this.bazookaAtt = 10;
            this.flamerAtt = 10;
            this.tankAtt = 10;
            this.sniperAtt = 10;
            this.apcAtt = 10;
            this.riflemanSplash = 10;
            this.bazookaSplash = 10;
            this.flamerSplash = 10;
            this.tankSplash = 10;
            this.sniperSplash = 10;
            this.apcSplash = 10;
            this.fireHurt = 1;
            this.name = '';
            this.play = state;

            //infantry
            if (nodeType == 0) {
                switch (type) {
                    case 0:
                        this.name = 'rifleman';
                        break;
                    case 1:
                        this.name = 'bazooka';
                        break;
                    case 2:
                        this.name = 'flamer';
                        break;
                }
                this.animation.play('walk_' + this.name + '_' + this.play['colour' + side]);
                this.myWidth = this.box.bounds.width;
                this.hitWidth = this.play.parameters.INFANTRY_HIT_WIDTH;
            } else {
                switch (type) {
                    case 0:
                        //apc
                        this.animation.play('turret_apc_' + this.play['colour' + side]);
                        break;
                    case 1:
                        //sniper
                        this.animation.play('digDown_' + this.play['colour' + side]);
                        break;
                    case 2:
                        //tank
                        this.animation.play('turret_walk_tank_' + this.play['colour' + side]);
                        break;
                }
                this.myWidth = this.box.bounds.width;
                this.hitWidth = this.myWidth;
            }

            //update dynamic width var
            this.myHeight = this.box.bounds.height;
            this.transform.rotPointX = this.myWidth / 2;
            this.transform.rotPointY = this.myHeight / 2;

            this.x = x - (this.myWidth / 2);
            this.y = y - (this.myHeight / 2);
            this.side = side;
            this.type = type;
            this.angle = this.returnAngle();
            this.rotation = angle;
            this.walkRotation = this.rotation;
            this.setBaseVelocity(nodeType);
            this.setVelocity();
        }
        movingContent.prototype.setBaseVelocity = function (nodeType) {
            //infantry
            if (nodeType == 0) {
                if (this.type == 0) {
                    this.baseVelocity = this.play.parameters.RIFLE_VELOCITY;
                } else if (this.type == 1) {
                    this.baseVelocity = this.play.parameters.BAZOOKA_VELOCITY;
                } else if (this.type == 2) {
                    this.baseVelocity = this.play.parameters.FLAMER_VELOCITY;
                }
            } else if (nodeType == 1) {
                if (this.type == 0) {
                    this.baseVelocity = this.play.parameters.TANK_VELOCITY;
                } else if (this.type == 1) {
                    this.baseVelocity = this.play.parameters.SNIPER_VELOCITY;
                } else if (this.type == 2) {
                    this.baseVelocity = this.play.parameters.APC_VELOCITY;
                }
            }
        };

        movingContent.prototype.setBox = function () {
            //this.myWidth = this.box.bounds.width;
            //this.myHeight = this.box.bounds.height;
        };

        movingContent.prototype.setVelocity = function () {
            this.xVelocity = -this.play.getSin(this.walkRotation) * this.baseVelocity * this.friction;
            this.yVelocity = this.play.getCos(this.walkRotation) * this.baseVelocity * this.friction;
        };

        movingContent.prototype.setX = function (x) {
            this.x = x - (this.myWidth / 2);
        };

        movingContent.prototype.setY = function (y) {
            this.y = y - (this.myHeight / 2);
        };

        movingContent.prototype.returnX = function () {
            var x = this.x + (this.myWidth / 2);
            if (isNaN(x)) {
                console.log('NANNY:', this, x, this.myWidth, this.x);
                return 0;
            }
            return x;
        };

        movingContent.prototype.returnY = function () {
            var y = this.y + (this.myHeight / 2);
            if (isNaN(y)) {
                console.log('NANNY:', this, y, this.myHeight, this.y);
                return 0;
            }
            return y;
        };

        movingContent.prototype.returnAngle = function () {
            this.setWalkRotation();
            var ang = this.walkRotation;
            if (ang < 0)
                ang += Math.PI * 2;
            return ang;
        };

        movingContent.prototype.flip = function () {
            this.xVelocity *= -1;
            this.setWalkRotation();
        };

        movingContent.prototype.gotoAndPlay = function (frame) {
            this.animation.play(frame);
        };

        movingContent.prototype.rotateByCentre = function (ang) {
            this.rotation = ang;
        };

        movingContent.prototype.setWalkRotation = function () {
            var line = new Kiwi.Geom.Line(0, 0, this.xVelocity, this.yVelocity);
            var ang = line.angle;
            if (ang < 0)
                ang += Math.PI * 2;
            this.walkRotation = -ang;
            this.angle = this.walkRotation;
            //this.rotation = this.walkRotation;
        };

        movingContent.prototype.updateSoldier = function () {
            this.my_x = this.returnX();
            this.my_y = this.returnY();
        };
        return movingContent;
    })(Kiwi.GameObjects.Sprite);
    StandOffEntities.movingContent = movingContent;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var vehicle = (function (_super) {
        __extends(vehicle, _super);
        function vehicle(state, angle, x, y, side, type) {
            _super.call(this, state, state.textures.vehicles, angle, x, y, side, 1, type);
            this.baseHealth = 80;
            this.health = 80;
            this.nodeAtt = 30;
            this.jam = [];
            this.contentType = 1;
        }
        return vehicle;
    })(StandOffEntities.movingContent);
    StandOffEntities.vehicle = vehicle;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var infantry = (function (_super) {
        __extends(infantry, _super);
        //this['mouseStartX' + num], this['mouseStartY' + num], line.angle, num, type, level
        function infantry(state, angle, x, y, side, type) {
            _super.call(this, state, state.textures.infantry, angle, x, y, side, 0, type);
            this.formation = false;
            this.trench = false;
        }
        infantry.prototype.updateSoldier = function () {
            this.my_x = this.returnX();
            this.my_y = this.returnY();
        };
        return infantry;
    })(StandOffEntities.movingContent);
    StandOffEntities.infantry = infantry;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var apc = (function (_super) {
        __extends(apc, _super);
        //this['mouseStartX' + num], this['mouseStartY' + num], line.angle, num, type, level, formBool
        function apc(state, angle, x, y, side, type, level) {
            _super.call(this, state, angle, x, y, side, type);
            //gameplay variables
            this.shots = 10;
            this.shootDelay = 0.1;
            this.reloadDelay = 5;
            this.releaseDelay = 400;
            this.releaseVar = 0;
            this.baseVelocity = 0.1;
            this.range1 = 200;
            this.range2 = 250;
            this.range3 = 275;
            this.acc1 = 1;
            this.acc2 = 1;
            this.acc3 = 1;
            this.name = 'apc';
            this.riflemanAtt = 200;
            this.bazookaAtt = 100;
            this.flamerAtt = 100;
            this.tankAtt = 0;
            this.sniperAtt = 100;
            this.apcAtt = 20;
            this.walkVar = 0;
            this.walkCount = 0;
            this.buildingAtt = 2;
            this.spawned = false;

            //console.log(x, y, " ATV POS");
            this.setVelocity();
            this.health = state.parameters.APC_HEALTH;
            this.baseHealth = state.parameters.APC_HEALTH;
            this.walkVar = state.parameters.APC_WALK_VAR;
            this.baseVelocity = state.parameters.APC_VELOCITY;
        }
        apc.prototype.setVelocity = function () {
            this.xVelocity = -Math.sin(this.rotation) * this.baseVelocity * this.friction;
            this.yVelocity = Math.cos(this.rotation) * this.baseVelocity * this.friction;
        };
        return apc;
    })(StandOffEntities.vehicle);
    StandOffEntities.apc = apc;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var bazooka = (function (_super) {
        __extends(bazooka, _super);
        //this['mouseStartX' + num], this['mouseStartY' + num], line.angle, num, type, level, formBool
        function bazooka(state, angle, x, y, side, type, level) {
            _super.call(this, state, angle, x, y, side, type);
            //gameplay variables
            this.shots = 5;
            this.shotDelay = 5;
            this.reloadDelay = 30;
            this.damage = 20;
            this.range1 = 150;
            this.range2 = 200;
            this.range3 = 225;
            this.acc1 = 1;
            this.acc2 = 0.6;
            this.acc3 = 0.4;
            this.riflemanAtt = 7;
            this.bazookaAtt = 5;
            this.flamerAtt = 7;
            this.tankAtt = 15;
            this.sniperAtt = 15;
            this.apcAtt = 15;
            this.riflemanSplash = 2;
            this.bazookaSplash = 2;
            this.flamerSplash = 2;
            this.tankSplash = 10;
            this.sniperSplash = 10;
            this.apcSplash = 10;
            this.buildingAtt = 15;
            this.baseVelocity = 0.5;

            /*
            this.animation.add('walk', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], 0.1, true);
            this.animation.add('shoot', [12, 13, 14, 15, 16, 17], 0.1, false);
            this.animation.play('walk');
            */
            this.health = state.parameters.BAZOOKA_HEALTH;
            this.baseHealth = state.parameters.BAZOOKA_HEALTH;
            this.baseVelocity = state.parameters.BAZOOKA_VELOCITY;
        }
        return bazooka;
    })(StandOffEntities.infantry);
    StandOffEntities.bazooka = bazooka;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var buildNode = (function (_super) {
        __extends(buildNode, _super);
        function buildNode(state, textures, col, x, y, side, pos) {
            _super.call(this, state);
            this.side = 0;
            this.pos = 0;
            this.alive = true;
            this.attackers = 0;
            this.isDown = false;
            this.isClicked = false;
            this.auto = false;
            this.clickType = 'buildNode';
            this.col = 0;
            //type: personnel, vehicle
            this.type = 0;
            this.level0 = 0;
            this.level1 = 0;
            this.level2 = 0;
            this.selected = 0;
            this.updating = -1;
            this.buttonState = 0;
            //auto
            this.leeway = 0;
            this.frequency = 100;
            this.frequencyVar = -1;
            this.myAngle = 0;
            this.autoAngle = 0;
            this.angleMax = 1.25;
            this.currProgress = 0;
            this.maxProgress = 100000;
            this.startingProgress = 0;
            this.startTime = 0;
            this.width = 85;
            this.height = 85;
            this.myWidth = 80;
            this.myHeight = 80;
            this.haltVar = 0;
            this.def1 = 0.9;
            this.def2 = 0.7;
            this.def3 = 0.5;
            //splash damage
            this.def4 = 0.7;
            this.ready = false;
            this.arrowing = false;
            this.currentlySelected = false;
            this.play = state;
            this.myWidth = this.width;
            this.myHeight = this.height;
            this.transform.x = x;
            this.transform.y = y;
            this.name = 'node' + side + '_' + pos;
            this.side = side;
            this.pos = pos;
            this.col = col;
            this.textures = textures;
        }
        buildNode.prototype.build = function () {
            this.myBase = new Kiwi.GameObjects.Sprite(this.state, this.textures['nodeButtons' + this.col], -3, -178); //-56);

            //this.myBase.animation.add('blink_deselected', [4, 2], 0.7, true, true);
            //this.myBase.animation.add('blink_selected', [5, 3], 0.7, true, true);
            this.myBase.animation.switchTo('fbBase');
            this.addChild(this.myBase);

            this.myProgress = new Kiwi.GameObjects.Sprite(this.state, this.textures.fbProg, 73, -4);
            this.addChild(this.myProgress);

            this.myType = new Kiwi.GameObjects.Sprite(this.state, this.textures.fbType, 18, 67);
            this.addChild(this.myType);

            this.myFactoryIcon = new Kiwi.GameObjects.Sprite(this.state, this.textures.fbFactoryType, 4, 60);
            this.addChild(this.myFactoryIcon);

            this.myFactoryType = new Kiwi.GameObjects.Sprite(this.state, this.textures.fbFactoryNone, 20, 12);
            this.addChild(this.myFactoryType);

            this.myBarracks = new Kiwi.GameObjects.Sprite(this.state, this.textures.fbBarracks, 18, 18);
            this.addChild(this.myBarracks);

            this.myMech = new Kiwi.GameObjects.Sprite(this.state, this.textures.fbMech, 18, 18);
            this.addChild(this.myMech);

            this.myProgress.alpha = 0;
            this.myType.alpha = 0;
            this.myBarracks.alpha = 0;
            this.myMech.alpha = 0;
            this.myFactoryType.visible = false;
            this.myFactoryIcon.alpha = 0;
        };

        buildNode.prototype.rotateNode = function () {
            var pi = Math.PI;

            //this.mySelection.rotation = pi;
            this.myBase.transform.rotPointX = this.myBase.box.bounds.width / 2;
            this.myBase.transform.rotPointY = this.myBase.box.bounds.height / 2;
            this.myBase.rotation = pi;

            this.myProgress.transform.rotPointX = this.myProgress.box.bounds.width / 2;
            this.myProgress.transform.rotPointY = this.myProgress.box.bounds.height / 2;
            this.myProgress.rotation = pi;

            this.myType.transform.rotPointX = this.myType.box.bounds.width / 2;
            this.myType.transform.rotPointY = this.myType.box.bounds.height / 2;
            this.myType.rotation = pi;

            this.myBarracks.transform.rotPointX = this.myBarracks.box.bounds.width / 2;
            this.myBarracks.transform.rotPointY = this.myBarracks.box.bounds.height / 2;
            this.myBarracks.rotation = pi;

            this.myMech.transform.rotPointX = this.myMech.box.bounds.width / 2;
            this.myMech.transform.rotPointY = this.myMech.box.bounds.height / 2;
            this.myMech.rotation = pi;

            this.myFactoryType.transform.rotPointX = this.myFactoryType.box.bounds.width / 2;
            this.myFactoryType.transform.rotPointY = this.myFactoryType.box.bounds.height / 2;
            this.myFactoryType.rotation = pi;

            this.myFactoryIcon.transform.rotPointX = this.myFactoryIcon.box.bounds.width / 2;
            this.myFactoryIcon.transform.rotPointY = this.myFactoryIcon.box.bounds.height / 2;
            this.myFactoryIcon.rotation = pi;

            this.myBase.transform.x = -3;
            this.myBase.transform.y = -10;

            this.myProgress.transform.x = -1;
            this.myProgress.transform.y = -8;

            this.myType.transform.x = 21;
            this.myType.transform.y = -6;

            this.myBarracks.transform.x = 20;
            this.myBarracks.transform.y = 20;

            this.myMech.transform.x = 20;
            this.myMech.transform.y = 20;

            this.myFactoryType.transform.y = 24;

            this.myFactoryIcon.transform.x = 64;
            this.myFactoryIcon.transform.y = -10;
            //offset positions for rotated items
            //this.myType.y += this.play.processVar(170);
        };

        buildNode.prototype.hide = function () {
            this.myBase.alpha = 0;
            this.myProgress.alpha = 0;
            this.myType.alpha = 0;
            this.myBarracks.alpha = 0;
            this.myMech.alpha = 0;
            this.myBase.alpha = 0;
            this.myFactoryIcon.alpha = 0;
            this.myFactoryType.visible = false;
        };

        buildNode.prototype.show = function () {
            this.myBase.alpha = 1;
            this.myProgress.alpha = 1;
            this.myType.alpha = 1;
            this.myBarracks.alpha = 1;
            this.myMech.alpha = 1;
            this.myBase.alpha = 1;
            this.myFactoryIcon.alpha = 1;
            this.myFactoryType.visible = true;
        };

        buildNode.prototype.updateNode = function () {
            var prog_string = '';

            //update main img
            this.myFactoryIcon.alpha = 1;
            var f = this.returnTypeFrame();
            if (this.type == 1) {
                prog_string += 'BARRACK_TIME_';
                if (f == -1) {
                    this.myBarracks.visible = false;
                    this.myFactoryType.visible = true;
                } else {
                    this.myBarracks.visible = true;
                    this.myBarracks.animation.switchTo(f);
                    this.myFactoryType.visible = false;
                }
            } else if (this.type == 2) {
                this.myFactoryIcon.animation.switchTo(1);
                if (f == -1) {
                    this.myMech.visible = false;
                    this.myFactoryType.visible = true;
                    this.myFactoryType.animation.switchTo(1);
                } else {
                    this.myMech.visible = true;
                    this.myMech.animation.switchTo(f);
                    this.myFactoryType.visible = false;
                }
                prog_string += 'MECH_TIME_';
            }

            //update myType
            /*var myTypeFrame = 0;
            if (this.level1 > 0) {
            if (this.level2 > 0) {
            myTypeFrame = 3;
            } else {
            myTypeFrame = 1;
            }
            } else if (this.level2 > 0) {
            myTypeFrame = 2;
            }
            this.myType.animation.switchTo(myTypeFrame);*/
            //update max progress via parameters
            prog_string += this.selected + '_' + this['level' + this.selected];
            this.maxProgress = this.play.parameters[prog_string];

            //update progress info
            if (this.maxProgress == undefined) {
                this.startTime = this.play.game.time.now();
            } else {
                this.startTime = this.play.game.time.now() - (this.maxProgress * this.startingProgress);
            }

            this.myProgress.alpha = 1;
            this.myProgress.animation.switchTo(0);
            this.ready = false;

            this.displayTypes();
        };

        buildNode.prototype.selectNode = function () {
            this.currentlySelected = true;
            if (this.type == 0) {
                this.myBase.animation.switchTo(1);
            }
        };

        buildNode.prototype.deselectNode = function () {
            this.currentlySelected = false;
            if (this.type == 0) {
                this.myBase.animation.switchTo(0);
            }
        };

        buildNode.prototype.tryFrame = function (clip, name) {
            if (clip.animation.currentAnimation.name == name) {
                //console.log('already frame:',name)
                return;
            }
            clip.animation.play(name);
        };

        buildNode.prototype.blink = function () {
            //check dragging arrow
            var a = this.play['arrow' + this.side];
            if (a != null) {
                this.unblink();
                return;
            }
            if (this.currentlySelected) {
                this.tryFrame(this.myBase, 'fbBaseBlinkSelected');
            } else {
                this.tryFrame(this.myBase, 'fbBaseBlinkDeselected');
            }
        };

        buildNode.prototype.unblink = function () {
            this.tryFrame(this.myBase, 'fbBase');
            if (this.currentlySelected) {
                this.myBase.animation.switchTo(3);
            } else {
                this.myBase.animation.switchTo(2);
            }
        };

        buildNode.prototype.death = function () {
            /*if (this.type == 1) {
            this.myDoor.animation.switchTo(8);
            } else if (this.type == 2) {
            this.myDoor.animation.switchTo(15);
            } else {
            this.myDoor.animation.switchTo(1);
            }*/
        };

        //display the level of node
        buildNode.prototype.displayTypes = function () {
            this.myType.visible = true;
            var f = -1;

            //new version displays what level you are again
            if (this['level' + this.selected] == 1)
                f = 0;
            if (this['level' + this.selected] == 2)
                f = 3;
            if (this['level' + this.selected] == 3)
                f = 6;

            if (f == -1) {
                this.myType.visible = false;
            } else {
                this.myType.animation.switchTo(f);
            }
        };

        //show correct leveled type icon
        buildNode.prototype.returnTypeFrame = function () {
            if (this.level0 == 0 && this.level1 == 0 && this.level2 == 0)
                return -1;
            var num = 0;
            if (this['level' + this.selected] == 2) {
                num++;
            } else if (this['level' + this.selected] == 3) {
                num += 2;
            }
            num += this.selected * 3;
            return num;
        };

        buildNode.prototype.returnX = function () {
            return this.x + (this.myWidth / 2);
        };

        buildNode.prototype.returnY = function () {
            return this.y + (this.myHeight / 2);
        };

        buildNode.prototype.update = function () {
            _super.prototype.update.call(this);
            if (this.play.paused)
                return;

            //var timer = buildNode.play.playTimer;
            if (this.alive) {
                if (!this.ready) {
                    if (this.haltVar > 0) {
                        this.haltVar--;
                    } else if (this.startTime > 0) {
                        //time elapsed in milliseconds
                        var diff = this.play.game.time.now() - this.startTime;
                        if (diff >= this.maxProgress || this.play.parameters.CHEATING) {
                            this.myProgress.animation.switchTo(17);
                            this.play.audioManager.playSFX(this.play.arrowSFX);
                            this.ready = true;
                        } else {
                            //progress frames = 15
                            var pc = (diff / this.maxProgress) * 100;

                            //frame
                            var f = (pc / 100) * 15;
                            f = Math.floor(f);
                            this.ready = false;
                            this.myProgress.animation.switchTo(f);
                            this.unblink();
                        }
                    }
                } else {
                    var canBlink = true;

                    for (var i = 2; i >= 0; i--) {
                        if (this.play["callIn_" + this.side + "_" + i].animation.frameIndex == 1) {
                            canBlink = false;
                        }
                    }
                    if (canBlink) {
                        this.blink();
                    } else {
                        this.unblink();
                    }
                }
            }
        };

        buildNode.prototype.reset = function () {
            this.ready = false;
            this.startingProgress = 0;
            this.updateNode();
        };
        return buildNode;
    })(Kiwi.Group);
    StandOffEntities.buildNode = buildNode;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var buildNodeBase = (function (_super) {
        __extends(buildNodeBase, _super);
        function buildNodeBase(state, textureID, x, y, side, pos) {
            _super.call(this, state, textureID, x, y);
            //static
            this.pos = 0;
            this.side = 0;
            this.isDown = false;
            this.isClicked = false;
            this.clickType = 'buildNodeBase';
            this.auto = false;
            this.pos = pos;
            this.side = side;
            this.play = state;
            this.name = 'node' + side + '_' + pos + '_base';
            if (!this.auto) {
                this.input.onDown.add(this.setDown, this);
                this.input.onUp.add(this.clickNode, this);
            }

            this.animation.switchTo('fbDoor');
            this.animation.stop();
            if (side == 1) {
                this.transform.rotPointX = this.box.bounds.width / 2;
                this.transform.rotPointY = this.box.bounds.height / 2;
                this.transform.rotation = Math.PI;
            }
            /*new atlas
            this.animation.add('barrack', [2, 3, 4, 5, 6, 7], 0.05, false, true);
            this.animation.add('mech', [9, 10, 11, 12, 13, 14], 0.05, false, true);
            this.animation.add('static', [0], 0.05, false, true);
            this.animation.switchTo(0);
            */
        }
        buildNodeBase.prototype.setDown = function (target, pointer) {
            //console.log('SET DOWN:', target, ':::', pointer)
            if (this.side == 1) {
                //check to see if y is right
                if (pointer.y < this.y + 80) {
                    var buildNode = this.play['node' + this.side + '_' + this.pos];
                    if (buildNode.myBase.animation.currentAnimation.name == 'fbBase')
                        return;
                }
            } else {
                if (pointer.y > this.y + 68) {
                    var buildNode = this.play['node' + this.side + '_' + this.pos];

                    //148h - 80 = 68
                    if (buildNode.myBase.animation.currentAnimation.name == 'fbBase')
                        return;
                }
            }
            this.isDown = true;
            this.isClicked = false;
        };

        buildNodeBase.prototype.clickNode = function () {
            this.isClicked = true;
            this.isDown = false;
        };

        buildNodeBase.prototype.returnX = function () {
            if (!this.play.parameters.SCALE_IMG) {
                return this.x;
            }
            return this.x + (this.width / 4);
        };

        buildNodeBase.prototype.returnY = function () {
            if (!this.play.parameters.SCALE_IMG) {
                return this.y;
            }
            return this.y + (this.height / 4);
        };

        buildNodeBase.prototype.objType = function () {
            return 'buildNodeBase';
        };
        return buildNodeBase;
    })(Kiwi.GameObjects.Sprite);
    StandOffEntities.buildNodeBase = buildNodeBase;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var bullet = (function (_super) {
        __extends(bullet, _super);
        function bullet(state, textureID, x, y, side, type) {
            _super.call(this, state, textureID, x, y);
            this.type = 'bullet';
            this.count = 40;
            this.xVelocity = 0;
            this.yVelocity = 0;
            this.side = 0;
            this.bx = 0;
            this.by = 0;
            this.type = type;
            this.side = side;
            this.bx = (this.box.bounds.width / 2);
            this.by = (this.box.bounds.height / 2);
        }
        bullet.prototype.setBox = function () {
            this.bx = this.box.bounds.width / 2;
            this.by = this.box.bounds.height / 2;
        };

        bullet.prototype.update = function () {
            _super.prototype.update.call(this);
        };

        bullet.prototype.returnX = function () {
            return this.x + this.bx;
        };

        bullet.prototype.returnY = function () {
            return this.y + this.by;
        };
        return bullet;
    })(Kiwi.GameObjects.Sprite);
    StandOffEntities.bullet = bullet;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var bazookaShell = (function (_super) {
        __extends(bazookaShell, _super);
        function bazookaShell(state, textureID, x, y, side) {
            _super.call(this, state, textureID, x, y, side, 'bazooka');
            this.tankAtt = 50;
            this.sniperAtt = 125;
            this.apcAtt = 125;
            this.riflemanSplash = 4;
            this.bazookaSplash = 2;
            this.flamerSplash = 4;
            this.tankSplash = 150;
            this.sniperSplash = 125;
            this.apcSplash = 125;
            this.buildingAtt = 15;
            this.type = 'bazooka';
            this.side = side;
        }
        return bazookaShell;
    })(StandOffEntities.bullet);
    StandOffEntities.bazookaShell = bazookaShell;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var cannonShell = (function (_super) {
        __extends(cannonShell, _super);
        function cannonShell(state, textureID, x, y, side) {
            _super.call(this, state, textureID, x, y, side, 'shell');
            this.riflemanSplash = 350;
            this.bazookaSplash = 350;
            this.flamerSplash = 350;
            this.tankSplash = 500;
            this.sniperSplash = 400;
            this.apcSplash = 300;
            this.buildingAtt = 0;
            this.type = 'shell';
            this.side = side;
        }
        return cannonShell;
    })(StandOffEntities.bullet);
    StandOffEntities.cannonShell = cannonShell;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var machineGunBullet = (function (_super) {
        __extends(machineGunBullet, _super);
        function machineGunBullet(state, textureID, x, y, side) {
            _super.call(this, state, textureID, x, y, side, 'machineGun');
            this.riflemanAtt = 10;
            this.bazookaAtt = 10;
            this.flamerAtt = 10;
            this.tankAtt = 1;
            this.sniperAtt = 3;
            this.apcAtt = 2;
            this.type = 'machineGun';
            this.side = side;
        }
        return machineGunBullet;
    })(StandOffEntities.bullet);
    StandOffEntities.machineGunBullet = machineGunBullet;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var callInButton = (function (_super) {
        __extends(callInButton, _super);
        function callInButton(state, textureID, x, y, side, pos) {
            _super.call(this, state, textureID, x, y);
            //static
            this.pos = 0;
            this.side = 0;
            this.isDown = false;
            this.isClicked = false;
            this.clickType = 'callInButton';
            this.auto = false;
            this.pos = pos;
            this.side = side;
            this.name = 'callIn_' + side + '_' + pos;
            this.animation.switchTo(pos);
            if (!this.auto) {
                this.input.onDown.add(this.setDown, this);
                this.input.onUp.add(this.clickNode, this);
            }
        }
        callInButton.prototype.setDown = function () {
            if (this.visible) {
                this.isDown = true;
                this.isClicked = false;
                this.animation.switchTo(4);
            }
        };

        callInButton.prototype.clickNode = function () {
            this.isClicked = true;
            this.isDown = false;
            this.animation.switchTo(0);
        };

        callInButton.prototype.objType = function () {
            return 'callInButton';
        };
        return callInButton;
    })(Kiwi.GameObjects.Sprite);
    StandOffEntities.callInButton = callInButton;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var cannon = (function (_super) {
        __extends(cannon, _super);
        function cannon(state, textures, side, num, auto) {
            _super.call(this, state);
            this.type = 0;
            this.side = 0;
            this.col = 0;
            this.count = 63;
            this.barCount = 29;
            this.distMax = 140;
            this.auto = false;
            this.clickType = 'cannon';
            this.ready = false;
            this.isDown = false;
            this.isClicked = false;
            this.cooling = false;
            this.warming = false;
            this.active = true;
            this.charge = 0;
            //public chargeVar: number = 1;
            this.leeway = Math.PI / 2;
            this.frequency = 100;
            this.frequencyVar = 100;
            this.range3 = 1024;
            this.machineGunCost = 10;
            this.machineGunVar = 25;
            this.machineGunCount = 0;
            this.coolVar = 1;
            this.distance = 0;
            this.hitVar = 50;
            this.firing = false;
            //toggle between left and right turret
            this.turret = false;
            this.returnVar = Math.PI / 128;
            this.play = state;
            this.textures = textures;
            this.col = state['colour' + side];
            this.name = 'cannon' + side;
            this.side = side;
            this.type = num;
            if (num == 1) {
                this.total = state.parameters.CANNON_MG_WARM_TIME;
            } else if (num == 2) {
                this.total = state.parameters.CANNON_SHELL_WARM_TIME;
            } else {
                this.total = state.parameters.CANNON_FLARE_WARM_TIME;
            }
            //if (this.charge > this.total) this.charge = this.total;
            //find out if auto firing
            //this.updateProgress((this.charge / this.total)*100);
        }
        cannon.prototype.build = function () {
            //cannon centered position
            var cx = -37;
            var cy = -82;
            if (this.type == 2)
                cy = -105;

            this.cannonClip = new Kiwi.GameObjects.Sprite(this.play, this.textures['nodeButtons' + this.col], cx, cy);
            this.cannonClip.animation.switchTo('cannon_warmup_' + this.type);
            this.addChild(this.cannonClip);
            this.cannonClip.animation.stop();
            this.cannonClip.transform.rotPointX = 0;
            this.cannonClip.transform.rotPointY = 0;
            if (this.auto) {
            } else {
                this.cannonClip.input.onDown.add(this.setDown, this);
                this.cannonClip.input.onRelease.add(this.clickNode, this);
            }

            //new cannon progress bars
            this.charge1 = new Kiwi.GameObjects.Sprite(this.play, this.textures['cpl' + this.col], 38, 32);
            this.addChild(this.charge1);
            this.charge1.transform.rotPointX = 0;
            this.charge1.transform.rotPointY = 0;
            this.charge1.transform.rotation += Math.PI;

            this.charge2 = new Kiwi.GameObjects.Sprite(this.play, this.textures['cpr' + this.col], -22, 32);
            this.addChild(this.charge2);
            this.charge2.transform.rotPointX = 0;
            this.charge2.transform.rotPointY = 0;
            this.charge2.transform.rotation += Math.PI;

            //pullback overlay
            this.pullback = new Kiwi.GameObjects.Sprite(this.play, this.textures['nodeButtons' + this.col], 40, 40);
            this.pullback.animation.play('cannonOverlayInactive');
            this.addChild(this.pullback);
            this.pullback.transform.rotPointX = 0;
            this.pullback.transform.rotPointY = 0;
            this.pullback.transform.rotation += Math.PI;
            this.cannonClip.name = 'cannonClip';
            this.charge1.name = 'charge1';
            this.charge2.name = 'charge2';
            this.pullback.name = 'pullback';

            this.symbol = new Kiwi.GameObjects.Sprite(this.play, this.textures.cannonSymbol, -12, -16);
            this.addChild(this.symbol);
            this.symbol.transform.rotPointX = 12;
            this.symbol.transform.rotPointY = 16;
            this.symbol.transform.rotation += Math.PI;
        };

        cannon.prototype.updateProgress = function (perc) {
            //this.play['circle' + this.side].animationconsole.log('prec:',perc)
            if (perc >= 100) {
                perc = 100;
                this.symbol.animation.switchTo((this.type - 1) + 3);
            } else {
                this.symbol.animation.switchTo(this.type - 1);
            }
            if (this.rotation == 0 || this.rotation == Math.PI) {
                this.symbol.visible = true;
            }
            var cellVar = Math.floor((perc / 100) * this.count);
            var circle = this.play.nodeButtons.getChildByName('circle' + this.side);
            circle.animation.switchTo(cellVar);
            //this.charge1.animation.switchTo(cellVar);
            //this.charge2.animation.switchTo(cellVar);
        };

        cannon.prototype.returnProgress = function () {
            //if (this.charge > 100) return 100;
            return Math.ceil((this.charge / this.total) * 100);
        };

        //press, down, released
        cannon.prototype.setDown = function () {
            if (this.device == undefined)
                this.device = this.play['finger' + this.side];
            var pX = this.device.x;
            var pY = this.device.y;
            var cX = this.returnX();
            var cY = this.returnY();

            //console.log(pX, pY, cX, cY, this.hitVar);
            var hitBool = false;
            if (pX > cX - this.hitVar && pX < cX + this.hitVar) {
                if (pY > cY - this.hitVar && pY < cY + this.hitVar) {
                    hitBool = true;
                }
            }
            this.isDown = hitBool;
            this.isClicked = false;
        };

        cannon.prototype.clickNode = function () {
            this.isClicked = true;
            this.isDown = false;
        };

        cannon.prototype.returnX = function () {
            return this.x;
        };

        cannon.prototype.returnY = function () {
            return this.y;
        };

        cannon.prototype.returnAutoAngle = function (ang) {
            //alter leeway
            var randLeeway = Math.random() * this.play.parameters.CANNON_LEEWAY;
            var rand = Math.floor(Math.random() * 2);
            if (rand == 1)
                randLeeway *= -1;
            ang += randLeeway;
            return ang;
        };

        cannon.prototype.returnAutoDist = function (dist) {
            var randDistLeeway = Math.random() * this.play.parameters.CANNON_DIST_LEEWAY;
            var rand = Math.floor(Math.random() * 2);
            if (rand == 1)
                randDistLeeway *= -1;
            dist += randDistLeeway;
            dist /= this.play.parameters.CANNON_DIST_VAR;
            return dist;
        };

        cannon.prototype.updatePullback = function (mx, my) {
            if (this.play.players == 1 && this.side == 2)
                return;
            var line = new Kiwi.Geom.Line(this.returnX(), this.returnY(), mx, my);

            //console.log('update cannon pull:', this.returnX(), this.returnY(), mx, my);
            var r = line.angle;
            if (r < 0)
                r += Math.PI * 2;
            if (this.side == 1) {
                if (r > Math.PI / 2 && r < Math.PI * 1.5)
                    return;
            } else {
                if (r < Math.PI / 2 || r > Math.PI * 1.5)
                    return;
            }

            this.symbol.visible = false;

            //add to the distance to reduce distance required to pull back
            this.distance = line.length * 1.2;

            if (this.distance > this.distMax)
                this.distance = this.distMax;

            var d = this.distance;

            //cannon dist frames 6-11
            var step = 20;
            var myFrame = Math.floor(d / step);

            //max
            if (myFrame > 5)
                myFrame = 5;

            //starting anim cell
            myFrame += 6;
            this.cannonClip.animation.switchTo(myFrame, false);

            var pullFrame = Math.floor(d / this.play.parameters.CANNON_STRETCH);
            if (pullFrame > 13)
                pullFrame = 13;

            //starting anim cell
            pullFrame += 2;

            //console.log('pullback frame:', pullFrame)
            this.pullback.animation.switchTo('cannonOverlay', false);
            this.pullback.animation.switchTo(pullFrame, false);

            this.charge1.animation.switchTo(Math.floor((d * 6) / this.barCount));
            this.charge2.animation.switchTo(Math.floor((d * 6) / this.barCount));
        };

        cannon.prototype.returnToCentre = function () {
            if (this.rotation < 0)
                this.rotation += Math.PI * 2;
            if (this.side == 1) {
                if (this.rotation > Math.PI) {
                    this.rotation -= this.returnVar;
                    if (this.rotation < Math.PI)
                        this.rotation = Math.PI;
                } else if (this.rotation < Math.PI) {
                    this.rotation += this.returnVar;
                    if (this.rotation > Math.PI)
                        this.rotation = Math.PI;
                } else {
                    this.symbol.visible = true;
                }
            } else {
                if (this.rotation > Math.PI) {
                    this.rotation += this.returnVar;
                    if (this.rotation > Math.PI * 2)
                        this.rotation = 0;
                } else if (this.rotation < Math.PI && this.rotation > 0) {
                    this.rotation -= this.returnVar;
                    if (this.rotation < 0)
                        this.rotation = 0;
                } else {
                    this.symbol.visible = true;
                }
            }
        };

        cannon.prototype.update = function () {
            _super.prototype.update.call(this);
        };
        return cannon;
    })(Kiwi.Group);
    StandOffEntities.cannon = cannon;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var cannonButton = (function (_super) {
        __extends(cannonButton, _super);
        function cannonButton(state, textureID, col, x, y, side, num) {
            _super.call(this, state, textureID, x, y);
            this.type = 0;
            this.side = 0;
            this.num = 0;
            this.auto = false;
            this.col = 0;
            this.clickType = 'cannonButton';
            this.isDown = false;

            //super(cacheID, x, y);
            this.transform.x = x;
            this.transform.y = y;
            this.col = col;
            this.name = 'cb_' + side + '_' + num;
            this.side = side;
            this.num = num;
            this.play = state;
        }
        cannonButton.prototype.build = function () {
            /*this.myImg = <Kiwi.GameObjects.Sprite>new Kiwi.GameObjects.Sprite(this.state, this.textures['cb_ammo_' + this.col]);
            //this.play.processImage(this.myImg, true);
            this.addChild(this.myImg);
            this.myImg.animation.switchTo(this.num * 3);
            var sx = -10;
            var sy = -8;
            if (this.side == 2) {
            sx = 10;
            sy = 8;
            }
            this.mySel = new Kiwi.GameObjects.Sprite(this.state, this.textures['cb_select_' + this.col], this.play.processVar(sx), this.play.processVar(sy));
            this.play.processImage(this.mySel, true);
            this.addChild(this.mySel);
            this.mySel.alpha = 0;*/
        };

        cannonButton.prototype.update = function () {
            _super.prototype.update.call(this);
        };
        return cannonButton;
    })(Kiwi.GameObjects.Sprite);
    StandOffEntities.cannonButton = cannonButton;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var cannonButtonBase = (function (_super) {
        __extends(cannonButtonBase, _super);
        function cannonButtonBase(state, textureID, x, y, side, pos) {
            _super.call(this, state, textureID, x, y);
            //static
            this.pos = 0;
            this.side = 0;
            this.isDown = false;
            this.isClicked = false;
            this.clickType = 'cannonButtonBase';
            this.auto = false;
            this.pos = pos;
            this.side = side;
            this.name = 'cbb_' + side + '_' + pos;
            if (!this.auto) {
                this.input.onDown.add(this.setDown, this);
                this.input.onUp.add(this.clickNode, this);
            }
        }
        cannonButtonBase.prototype.setDown = function () {
            this.isDown = true;
            this.isClicked = false;
        };

        cannonButtonBase.prototype.clickNode = function () {
            this.isClicked = true;
            this.isDown = false;
        };

        cannonButtonBase.prototype.objType = function () {
            return 'cannonButtonBase';
        };
        return cannonButtonBase;
    })(Kiwi.GameObjects.Sprite);
    StandOffEntities.cannonButtonBase = cannonButtonBase;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var cannonProgress = (function (_super) {
        __extends(cannonProgress, _super);
        function cannonProgress(state, textures, col, x, y, side) {
            _super.call(this, state);
            this.side = 0;
            this.curr = 0;
            this.auto = false;
            this.col = 0;
            this.clickType = 'cannonButton';
            this.isDown = false;
            this.count = 30;
            this.prev = 0;
            this.play = state;

            //super(cacheID, x, y);
            this.x = x;
            this.y = y;
            this.col = col;
            this.name = 'cbp_' + side;
            this.side = side;
            this.textures = textures;
            this.cells = [];
            this.myImg = new Kiwi.GameObjects.Sprite(this.play, this.textures['cp' + this.col]);
            this.addChild(this.myImg);

            this.updateProgress(100);
        }
        cannonProgress.prototype.updateProgress = function (perc) {
            var cellVar = Math.floor((perc / 100) * this.count);
            this.myImg.animation.switchTo(cellVar);
        };

        cannonProgress.prototype.returnProgress = function () {
            return Math.floor((this.myImg.animation.frameIndex / this.count) * 100);
        };
        return cannonProgress;
    })(Kiwi.Group);
    StandOffEntities.cannonProgress = cannonProgress;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var effect = (function (_super) {
        __extends(effect, _super);
        function effect(state, textureID, angle, x, y) {
            _super.call(this, state, textureID, x, y);
            this.rotation = angle;
            //this.animation.add('effect', [0, 1, 2], 0.05, false, true);
            // this.animation.switchTo('effect', true);
            //this.animation.play('effect');
        }
        effect.prototype.update = function () {
            _super.prototype.update.call(this);
            if (this.animation.frameIndex >= this.animation.length - 1) {
                this.exists = false;
                this.destroy();
            }
        };
        return effect;
    })(Kiwi.GameObjects.Sprite);
    StandOffEntities.effect = effect;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var followingEffect = (function (_super) {
        __extends(followingEffect, _super);
        function followingEffect(state, textureID, char, perc, angle, x, y) {
            _super.call(this, state, textureID, angle, x, y);
            this.diffX = 0;
            this.diffY = 0;
            this.newWidth = 0;
            this.rotation = angle;

            //this.animation.add('effect', [0, 1, 2], 0.05, false, true);
            //this.animation.switchTo('effect', true);
            this.animation.play();
            this.diffX = x - char.returnX();
            this.diffY = y - char.returnY();
            this.char = char;
            this.transform.scaleX = perc;
        }
        followingEffect.prototype.update = function () {
            _super.prototype.update.call(this);
            this.width = this.newWidth;
            if (this.char.exists) {
                this.x = this.char.returnX() + this.diffX;
                this.y = this.char.returnY() + this.diffY;
            }
            if (this.animation.frameIndex >= this.animation.length - 1) {
                this.destroy();
            }
        };
        return followingEffect;
    })(StandOffEntities.effect);
    StandOffEntities.followingEffect = followingEffect;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var bomber = (function (_super) {
        __extends(bomber, _super);
        function bomber(state, x, y, angle) {
            _super.call(this, state, state.textures.callIns, x, y);
            this.count = 0;
            this.countMax = 100;
            this.speedX = 0;
            this.speedY = 0;
            this.speed = 25;
            this.play = state;
            angle *= -1;
            var sx = this.play.returnHOffsetX(-1000, angle + Math.PI);
            var sy = this.play.returnHOffsetY(-1000, angle + Math.PI);
            this.speedX = -this.play.returnHOffsetX(this.speed, angle);
            this.speedY = -this.play.returnHOffsetY(this.speed, angle);
            this.x += sx;
            this.y += sy;
        }
        bomber.prototype.update = function () {
            _super.prototype.update.call(this);
            if (this.play.paused)
                return;
            if (this.count >= this.countMax) {
                this.destroy();
            }
            this.x += this.speedX;
            this.y += this.speedY;
            this.count++;
        };
        return bomber;
    })(Kiwi.GameObjects.Sprite);
    StandOffEntities.bomber = bomber;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var bomb = (function (_super) {
        __extends(bomb, _super);
        function bomb(state, textureID, r, delay, x, y, side) {
            _super.call(this, state, textureID, r, x, y);
            this.count = 0;
            this.delay = 0;
            this.side = 0;
            this.riflemanSplash = 300;
            this.bazookaSplash = 300;
            this.flamerSplash = 300;
            this.tankSplash = 800;
            this.sniperSplash = 800;
            this.apcSplash = 800;
            this.buildingAtt = 0;
            this.delay = delay;
            this.play = state;
            this.side = side;
            this.visible = false;
            this.animation.stop();
        }
        bomb.prototype.update = function () {
            _super.prototype.update.call(this);
            if (!this.visible) {
                this.delay--;
                if (this.delay <= 0) {
                    this.visible = true;
                    this.animation.play();
                }
            } else {
                if (this.animation.frameIndex == 8) {
                    this.play.callInManager.bombHurt(this);

                    //if (this.play.explosionBigSFX.isPlaying == undefined) {
                    this.play.audioManager.playSFX(this.play.explosionBigSFX);
                    //}
                }
            }
        };
        return bomb;
    })(StandOffEntities.effect);
    StandOffEntities.bomb = bomb;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var flamer = (function (_super) {
        __extends(flamer, _super);
        //this['mouseStartX' + num], this['mouseStartY' + num], line.angle, num, type, level
        function flamer(state, angle, x, y, side, type, level) {
            _super.call(this, state, angle, x, y, side, type);
            //gameplay variables
            this.range1 = 100;
            this.range2 = 100;
            this.range3 = 100;
            this.shots = 3;
            this.shotDelay = 5;
            this.reloadDelay = 30;
            this.fireDamage = 100;
            this.acc1 = 1.0;
            this.acc2 = 1.0;
            this.acc3 = 1.0;
            this.riflemanAtt = 50;
            this.bazookaAtt = 120;
            this.flamerAtt = 75;
            this.tankAtt = 1;
            this.sniperAtt = 2;
            this.apcAtt = 2;
            this.buildingAtt = 20;
            this.baseVelocity = 0.6;
            this.health = state.parameters.FLAMER_HEALTH;
            this.baseHealth = state.parameters.FLAMER_HEALTH;
            this.baseVelocity = state.parameters.FLAMER_VELOCITY;
            //this.animation.add('walk', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0.1, true);
            //this.animation.add('shoot', [12, 13, 14, 15, 16, 17], 0.1, false);
            //this.animation.play('walk');
        }
        return flamer;
    })(StandOffEntities.infantry);
    StandOffEntities.flamer = flamer;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var flare = (function (_super) {
        __extends(flare, _super);
        function flare(state, textureID, x, y) {
            _super.call(this, state, textureID, x, y);
            this.count = 180;
            this.side = 0;
        }
        flare.prototype.update = function () {
            _super.prototype.update.call(this);
        };
        return flare;
    })(Kiwi.GameObjects.Sprite);
    StandOffEntities.flare = flare;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var helicopter = (function (_super) {
        __extends(helicopter, _super);
        function helicopter(state, side, x, y, r, step) {
            _super.call(this, state, state.textures.callIns, x, y);
            this.moveType = 0;
            this.hoverCount = 0;
            this.side = 0;
            this.side = side;
            this.play = state;
            if (step === 0) {
                this.animation.play('heli_' + this.play['colour' + side] + '_anim_in');

                //this.animation.add('anim_in', [1, 2, 3, 4, 5], 0.05, false, false);
                //this.animation.add('open_doors', [6, 7, 8], 0.15, false, false);
                this.destX = x;
                this.destY = y;
                this.speedY = this.play.parameters.HELI_SPEED;
                if (side == 1) {
                    this.y = this.game.stage.height;
                    this.rotation = Math.PI;
                } else {
                    this.y = -this.height;
                }
                this.moveType = step;
                this.x -= this.width / 2;
                this.play.audioManager.playSFX(this.play.AlphaTeamSFX);
            } else {
                if (step == 3) {
                    this.moveType = 2;
                    this.stepType();
                }
                this.animation.play('heli_' + this.play['colour' + this.side] + '_close_doors');
                this.x = x - this.width / 2;
                this.y = y - this.height / 2;
                this.rotation = r;
            }
        }
        helicopter.prototype.stepType = function () {
            //initiate next step
            this.moveType++;

            switch (this.moveType) {
                case 1:
                    this.wait = 0;
                    this.animation.play('heli_' + this.play['colour' + this.side] + '_open_doors');

                    this.play.audioManager.playSFX(this.play.DeployTroopsSFX);
                    break;
                case 2:
                    //let game drop, then progress
                    this.play.callInManager.heliDrop(this.side, this.destX, this.destY, this.rotation);
                    this.wait = 0;
                    this.destroy();
                    break;
                case 3:
                    //post wait
                    this.wait = 0;

                    break;
                case 4:
                    break;
                case 5:
                    this.animation.play('heli_' + this.play['colour' + this.side] + '_anim_out');
                    this.speedY = this.play.parameters.HELI_SPEED * 2;

                    this.play.audioManager.playSFX(this.play.AlphaTeamSFX);
                    break;
            }
        };

        helicopter.prototype.setHover = function () {
            this.destX = this.x + (Math.random() * this.play.parameters.HELI_HOVER_DIST) - (this.play.parameters.HELI_HOVER_DIST / 2);
            this.destY = this.y + (Math.random() * this.play.parameters.HELI_HOVER_DIST) - (this.play.parameters.HELI_HOVER_DIST / 2);
            this.rotSpeed = (Math.random() * this.play.parameters.HELI_ROT_SPEED) - (this.play.parameters.HELI_ROT_SPEED);
            var line = new Kiwi.Geom.Line(this.x, this.y, this.destX, this.destY);
            this.speedX = this.play.getSin(line.angle) * (this.play.parameters.HELI_HOVER_SPEED);
            this.speedY = this.play.getCos(line.angle) * (this.play.parameters.HELI_HOVER_SPEED);
        };

        helicopter.prototype.shoot = function () {
            //console.log('shoot');
        };

        helicopter.prototype.update = function () {
            _super.prototype.update.call(this);
            if (this.play.paused)
                return;
            switch (this.moveType) {
                case 0:
                    //heading toward point
                    if (this.side == 1) {
                        if (this.y - this.speedY <= this.destY - this.height / 2) {
                            this.y = this.destY - this.height / 2;
                            this.stepType();
                        } else {
                            this.y -= this.speedY;
                            if (this.y - (this.speedY * 3) <= this.destY - this.height / 2) {
                                this.animation.play('heli_' + this.play['colour' + this.side] + '_anim_in');
                            }
                        }
                    } else {
                        if (this.y + this.speedY >= this.destY - this.height / 2) {
                            this.y = this.destY - this.height / 2;
                            this.stepType();
                        } else {
                            this.y += this.speedY;
                            if (this.y + (this.speedY * 3) >= this.destY - this.height / 2) {
                                this.animation.play('heli_' + this.play['colour' + this.side] + '_anim_in');
                            }
                        }
                    }
                    break;
                case 1:
                    //waiting to drop
                    this.wait++;
                    if (this.wait >= this.play.parameters.HELI_DROP_WAIT) {
                        this.stepType();
                    }
                    break;
                case 2:
                    //post drop
                    this.wait++;
                    if (this.wait >= this.play.parameters.HELI_POST_WAIT) {
                        this.stepType();
                    }
                    break;
                case 3:
                    this.wait++;
                    if (this.wait >= this.play.parameters.HELI_POST_WAIT) {
                        this.stepType();
                    }

                    break;

                case 4:
                    this.wait++;
                    if (this.wait >= this.play.parameters.HELI_POST_WAIT) {
                        this.stepType();
                    }
                    break;
                case 5:
                    //fuck off
                    if (this.side == 1) {
                        if (this.y + this.height <= 0) {
                            this.destroy();
                        } else {
                            this.y -= this.speedY;
                        }
                    } else {
                        if (this.y >= this.game.stage.height) {
                            this.destroy();
                        } else {
                            this.y += this.speedY;
                        }
                    }
                    break;
            }
        };
        return helicopter;
    })(Kiwi.GameObjects.Sprite);
    StandOffEntities.helicopter = helicopter;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var dropper = (function (_super) {
        __extends(dropper, _super);
        function dropper(state, x, y, angle) {
            _super.call(this, state, state.textures.callIns, x, y);
            this.count = 0;
            this.countMax = 100;
            this.speedX = 0;
            this.speedY = 0;
            this.speed = 25;
            this.animation.play('dropper');
            this.transform.rotPointX = this.box.bounds.width / 2;
            this.transform.rotPointY = this.box.bounds.height / 2;
            this.play = state;
            angle *= -1;

            //position/speed
            var sx = this.play.returnHOffsetX(1000, angle + Math.PI);
            var sy = this.play.returnHOffsetY(1000, angle + Math.PI);
            this.x = x + sx - this.box.bounds.width / 2;
            this.y = y + sy - this.box.bounds.height / 2;
            this.rotation = -angle;
            this.speedX = this.play.returnHOffsetX(this.speed, angle);
            this.speedY = this.play.returnHOffsetY(this.speed, angle);
        }
        dropper.prototype.update = function () {
            _super.prototype.update.call(this);
            if (this.count >= this.countMax) {
                this.destroy();
            }
            this.x += this.speedX;
            this.y += this.speedY;
            this.count++;
        };
        return dropper;
    })(Kiwi.GameObjects.Sprite);
    StandOffEntities.dropper = dropper;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var crateDrop = (function (_super) {
        __extends(crateDrop, _super);
        function crateDrop(state, textureID, r, delay, x, y, dropType) {
            _super.call(this, state, textureID, r, x, y);
            this.count = 0;
            this.delay = 0;
            this.side = 0;
            this.dropType = 0;
            this.x -= this.width / 2;
            this.y -= this.height / 2;
            this.delay = delay;
            this.play = state;
            this.visible = false;
            this.dropType = dropType;

            //console.log(textureID);
            this.animation.add('anim', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16], 0.05, false);
            //this.animation.stop('anim');
        }
        crateDrop.prototype.update = function () {
            _super.prototype.update.call(this);
            if (!this.visible) {
                this.delay--;
                if (this.delay <= 0) {
                    this.visible = true;
                    this.animation.play('anim');
                }
            } else {
                if (this.animation.frameIndex == 8) {
                    this.play.callInManager.placeCrate(this.x, this.y, this.dropType);
                    this.destroy();
                }
            }
        };
        return crateDrop;
    })(StandOffEntities.effect);
    StandOffEntities.crateDrop = crateDrop;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var crate = (function (_super) {
        __extends(crate, _super);
        function crate(state, textureID, x, y) {
            _super.call(this, state, textureID, x, y);
            this.reward = 1;
            this.my_x = x;
            this.my_y = y;
            this.animation.add('static', [11, 12, 13, 14, 15, 16, 16, 16], 0.15, true, true);
            this.animation.switchTo('static');
            this.animation.play();
        }
        crate.prototype.update = function () {
            _super.prototype.update.call(this);
        };
        return crate;
    })(Kiwi.GameObjects.Sprite);
    StandOffEntities.crate = crate;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var rifleman = (function (_super) {
        __extends(rifleman, _super);
        //this['mouseStartX' + num], this['mouseStartY' + num], line.angle, num, type, level, formBool
        function rifleman(state, angle, x, y, side, type) {
            _super.call(this, state, angle, x, y, side, type);
            //gameplay variables
            this.shots = 3;
            this.shootDelay = 5;
            this.reloadDelay = 30;
            this.range1 = 200;
            this.range2 = 260;
            this.range3 = 300;
            this.acc1 = 0.9;
            this.acc2 = 0.7;
            this.acc3 = 0.5;
            this.riflemanAtt = 10;
            this.bazookaAtt = 10;
            this.flamerAtt = 6;
            this.tankAtt = 2;
            this.sniperAtt = 10;
            this.apcAtt = 10;
            this.buildingAtt = 5;
            this.baseVelocity = 0.2;

            /*this.animation.add('walk', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], 0.1, true);
            this.animation.add('shoot', [12, 13, 14, 15, 16, 17], 0.1, false);
            this.animation.play('walk');*/
            this.health = state.parameters.RIFLE_HEALTH;
            this.baseHealth = state.parameters.RIFLE_HEALTH;
            this.baseVelocity = state.parameters.RIFLE_VELOCITY;
        }
        return rifleman;
    })(StandOffEntities.infantry);
    StandOffEntities.rifleman = rifleman;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var selectButton = (function (_super) {
        __extends(selectButton, _super);
        function selectButton(state, textureID, x, y, side, pos) {
            _super.call(this, state, textureID, x, y);
            //static
            this.pos = 0;
            this.side = 0;
            this.isDown = false;
            this.isClicked = false;
            this.clickType = 'selectButton';
            this.auto = false;
            this.pos = pos;
            this.side = side;
            this.input.onDown.add(this.setDown, this);
            this.input.onUp.add(this.clickNode, this);
        }
        selectButton.prototype.setDown = function () {
            this.isDown = true;
            this.isClicked = false;
        };

        selectButton.prototype.clickNode = function () {
            this.isClicked = true;
            this.isDown = false;
        };
        return selectButton;
    })(Kiwi.GameObjects.Sprite);
    StandOffEntities.selectButton = selectButton;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var sniper = (function (_super) {
        __extends(sniper, _super);
        //this['mouseStartX' + num], this['mouseStartY' + num], line.angle, num, type, level, formBool
        function sniper(state, angle, x, y, side, type, level) {
            _super.call(this, state, angle, x, y, side, type);
            //gameplay variables
            this.range1 = 180;
            this.range2 = 260;
            this.range3 = 3000;
            this.shots = 1;
            this.shotDelay = 25;
            this.reloadDelay = 30;
            this.leeway = Math.PI * 2;
            this.acc1 = 1;
            this.acc2 = 1;
            this.acc3 = 1;
            this.riflemanAtt = 500;
            this.bazookaAtt = 500;
            this.flamerAtt = 500;
            this.tankAtt = 2;
            this.sniperAtt = 3;
            this.apcAtt = 3;
            this.nodeAtt = 50;
            this.name = 'sniper';
            this.buildingAtt = 2;
            this.baseVelocity = 0.2;
            this.digCount = 0;
            this.preCount = 0;
            this.shotCount = 0;
            this.postCount = 0;
            this.digMax = 100;
            this.digProximity = 150;
            this.preVar = 100;
            this.postVar = 100;
            this.nodeVar = 2000;
            this.nodeCount = 0;
            this.priorityArray = [2, 1, 0];
            this.health = state.parameters.SNIPER_HEALTH;
            this.baseHealth = state.parameters.SNIPER_HEALTH;
            this.baseVelocity = state.parameters.SNIPER_VELOCITY;
            this.digMax = state.parameters.SNIPER_DIG_VAR;
            this.digProximity = state.parameters.SNIPER_DIG_PROXIMITY;
            this.preVar = state.parameters.SNIPER_PRE_VAR;
            this.postVar = state.parameters.SNIPER_POST_VAR;
            this.nodeCount = 0;
            this.nodeVar = state.parameters.SNIPER_NODE_VAR;
        }
        return sniper;
    })(StandOffEntities.vehicle);
    StandOffEntities.sniper = sniper;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var tank = (function (_super) {
        __extends(tank, _super);
        //this['mouseStartX' + num], this['mouseStartY' + num], line.angle, num, type, level, formBool
        function tank(state, angle, x, y, side, type, level) {
            _super.call(this, state, angle, x, y, side, type);
            //gameplay variables
            this.shots = 1;
            this.shotDelay = 10;
            this.reloadDelay = 10;
            this.range1 = 50;
            this.range2 = 75;
            this.range3 = 200;
            this.acc1 = 0.9;
            this.acc2 = 0.7;
            this.acc3 = 0.5;
            this.riflemanAtt = 200;
            this.bazookaAtt = 200;
            this.flamerAtt = 200;
            this.tankAtt = 250;
            this.sniperAtt = 400;
            this.apcAtt = 300;
            this.name = 'tank';
            this.riflemanSplash = 200;
            this.bazookaSplash = 200;
            this.flamerSplash = 20;
            this.tankSplash = 250;
            this.sniperSplash = 300;
            this.apcSplash = 300;
            this.buildingAtt = 22;
            this.baseVelocity = 0.25;
            this.walkCount = 0;
            this.preCount = 0;
            this.shotCount = 0;
            this.postCount = 0;
            this.preVar = 100;
            this.postVar = 100;
            this.walkVar = 100;
            //catch last close shot
            this.lastRange = 3;
            this.targetRotation = 0;
            this.rotatedDir = 1;
            this.rotatedSpeed = 0.1;
            this.priorityArray = [5, 4, 3, 2, 1, 0];
            this.health = state.parameters.TANK_HEALTH;
            this.baseHealth = state.parameters.TANK_HEALTH;
            this.walkVar = state.parameters.TANK_WALK_VAR;
            this.preVar = state.parameters.TANK_PRE_VAR_1;
            this.postVar = state.parameters.TANK_POST_VAR;
            this.rotatedSpeed = state.parameters.TANK_ROTATE_SPEED;
            this.baseVelocity = state.parameters.TANK_VELOCITY;
            this.play = state;
        }
        tank.prototype.updateTankVars = function () {
            this.preVar = this.play.parameters['TANK_PRE_VAR_' + this.level];
            console.log('prev var tank:', this.preVar, this.level);
        };
        return tank;
    })(StandOffEntities.vehicle);
    StandOffEntities.tank = tank;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var tutorial = (function (_super) {
        __extends(tutorial, _super);
        function tutorial(state, color) {
            _super.call(this, state);
            this.shipAmount = 2;
            this.currentFrame = 0;
            this.state = state;
            this.color = color;

            this.topPanel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures['tutTopPanel' + (this.color - 1)], 18, 521);
            this.botPanel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures['tutBottomPanel' + (this.color - 1)], 0, 756);
            this.callinPanel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures['tutCallin' + (this.color - 1)], 672, 527);

            this.topPanel.animation.add('ani', [0, 2, 4, 6, 8, 10, 12, 1, 3, 5, 7, 9, 11, 13], 1, false);
            this.topPanel.animation.switchTo('ani', false);
            this.botPanel.animation.add('ani', [0, 2, 4, 6, 8, 10, 12, 1, 3, 5, 7, 9, 11, 13], 1, false);
            this.botPanel.animation.switchTo('ani', false);
            this.callinPanel.animation.add('ani', [0, 2, 4, 6, 8, 10, 12, 1, 3, 5, 7, 9, 11, 13], 1, false);
            this.callinPanel.animation.switchTo('ani', false);

            this.topPanel.alpha = 0;
            this.botPanel.alpha = 0;

            var tweenTopAlpha = this.game.tweens.create(this.topPanel);
            tweenTopAlpha.to({ alpha: 1 }, 500, Kiwi.Animations.Tweens.Easing.Linear.None, false);
            tweenTopAlpha.start();
            var tweenBotAlpha = this.game.tweens.create(this.botPanel);
            tweenBotAlpha.to({ alpha: 1 }, 500, Kiwi.Animations.Tweens.Easing.Linear.None, false);
            tweenBotAlpha.start();

            this.addChild(this.topPanel);
            this.addChild(this.botPanel);
            this.addChild(this.callinPanel);
            this.topPanel.input.onUp.add(this.nextFrane, this);
        }
        tutorial.prototype.update = function () {
            _super.prototype.update.call(this);
        };

        tutorial.prototype.nextFrane = function () {
            this.currentFrame++;
            if (this.currentFrame == 14) {
                this.exists = false;
                var cannon = this.state.nodeButtons.getChildByName('cannon' + 1);
                cannon.active = false;
                this.state.actionManager.receiveCallback('endTutorial');
                return;
            }

            //o 11, c 13
            if (this.currentFrame == 10) {
                this.state.showCallIns(1);
            }

            if (this.currentFrame == 13) {
                this.state.hideCallIns(1, false);
            }

            this.topPanel.animation.switchTo(this.currentFrame);
            this.botPanel.animation.switchTo(this.currentFrame);
            this.callinPanel.animation.switchTo(this.currentFrame);
        };
        return tutorial;
    })(Kiwi.Group);
    StandOffEntities.tutorial = tutorial;
})(StandOffEntities || (StandOffEntities = {}));
var StandOffEntities;
(function (StandOffEntities) {
    var player = (function () {
        function player() {
            //Win/Lose
            this.win = 0;
            this.lose = 0;
            //////////////////
            //Units General
            this.spawnUnit = 0;
            this.spawnInfantry = 0;
            this.spawnVehicle = 0;
            ///////////////
            //Units Infantry
            this.spawnRifleman = 0;
            this.spawnFlamer = 0;
            this.spawnBazooka = 0;
            //////////////////
            //Units Vehicles
            this.spawnApc = 0;
            this.spawnSniper = 0;
            this.spawnTank = 0;
            ////////////////
            //Cannon Uses
            this.machineGunBullet = 0;
            this.cannonShell = 0;
            this.cannonFlare = 0;
            /////////////////
            //Node Information
            this.nodeLost = 0;
            this.nodeBuilt = 0;
            this.nodeUpgrade = 0;
            /////////////////////
            //Callin
            this.callIns = 0;
            this.alphaTeam = 0;
            this.bomber = 0;
            this.healBeam = 0;
        }
        player.prototype.setAll = function () {
        };

        player.prototype.getAll = function () {
            //maybe this?
            var data = {
                wins: this.win,
                losses: this.lose,
                units: this.spawnUnit,
                infantry: this.spawnInfantry,
                vehicle: this.spawnVehicle,
                rifle: this.spawnRifleman,
                flamer: this.spawnFlamer,
                bazooka: this.spawnBazooka,
                apc: this.spawnApc,
                sniper: this.spawnSniper,
                tank: this.spawnTank,
                cannonMachineGun: this.machineGunBullet,
                cannonShell: this.cannonShell,
                cannonFlare: this.cannonFlare,
                nodesLost: this.nodeLost,
                nodesBuilt: this.nodeBuilt,
                nodeUpgrade: this.nodeUpgrade,
                callIns: this.callIns,
                alphaTeam: this.alphaTeam,
                bomber: this.bomber,
                healBeam: this.healBeam
            };

            return data;
        };
        return player;
    })();
    StandOffEntities.player = player;
})(StandOffEntities || (StandOffEntities = {}));
var StandOff;
(function (StandOff) {
    var Parameters = (function () {
        function Parameters() {
            this.CHEATING = false;
            this.MAP_NAMES = ["Che's last stand", "Clare's sanction", "Zach's ascent", "Sven's burden", "Judith's bluff", "Tim's pact"];
            this.AUDIO_ON = true;
            this.SFX_ON = true;
            //Starting Credits for each player
            this.P1_CREDITS = 150;
            this.P2_CREDITS = 150;
            //starting tokens
            this.P1_TOKENS = 50;
            this.P2_TOKENS = 50;
            //starting health
            this.RIFLE_HEALTH = 50;
            this.BAZOOKA_HEALTH = 120;
            this.FLAMER_HEALTH = 300;
            this.TANK_HEALTH = 1500;
            this.SNIPER_HEALTH = 400;
            this.APC_HEALTH = 800;
            //speed
            this.RIFLE_VELOCITY = 0.6;
            this.BAZOOKA_VELOCITY = 0.4;
            this.FLAMER_VELOCITY = 0.3;
            this.TANK_VELOCITY = 0.15;
            this.SNIPER_VELOCITY = 0.3;
            this.APC_VELOCITY = 0.2;
            this.DASH_BONUS = 1;
            this.INFANTRY_HIT_WIDTH = 40;
            //how much health team gets from heal ray call in
            this.HEAL_SHOT = 5000;
            //how many tokens a callin costs
            this.CALL_IN_MAXIMUM = 10;
            this.HEAL_AMOUNT = 3;
            this.HELI_AMOUNT = 3;
            this.BOMB_AMOUNT = 3;
            this.HEAL_MAXIMUM = 10;
            this.HELI_MAXIMUM = 10;
            this.BOMB_MAXIMUM = 10;
            this.HEAL_COST = 3;
            this.BOMB_COST = 5;
            this.HELI_COST = 7;
            //time between call and relase
            this.BOMB_WAIT = 75;
            this.HELI_WAIT = 7;
            this.CRATE_WAIT = 20;
            this.BUBBLE_VAR = 100;
            this.LAVA_BUBBLE_VAR = 50;
            this.MUD_BUBBLE_VAR = 50;
            this.MUD_MIN_TIME = 20;
            this.MUD_MAX_TIME = 50;
            this.LAVA_MIN_TIME = 20;
            this.LAVA_MAX_TIME = 50;
            this.BOMB_RADIUS = 125;
            this.BOMB_RANGE = 250;
            this.CANNON_MG_TIME = 250;
            this.CANNON_MG_WARM_TIME = 400;
            this.CANNON_SHELL_WARM_TIME = 800;
            this.CANNON_FLARE_WARM_TIME = 1;
            this.CANNON_MG_DELAY = 3;
            //when infantry have past the halfway mark by this much, they pick a node to aim.
            this.INFANTRY_BOUNDARY = 150;
            //when vehicle is this close, stop advancing, and shoot at nearest target in range.
            this.VEHICLE_BOUNDARY = 125;
            //distance from attacked node where the infantry then kills a build node
            this.KILL_DIST = 25;
            //cost to select factory type
            this.INFANTRY_COST = 30;
            this.VEHICLE_COST = 50;
            //COST TO UNLOCK/UPGRADE FACTORY BUTTONS
            //infantry/ mech(1 or 2), type (0-2), level (0-2)
            //rifleman
            this.COST_1_0_0 = 10;
            this.COST_1_0_1 = 40;
            this.COST_1_0_2 = 50;
            //bazooka
            this.COST_1_1_0 = 10;
            this.COST_1_1_1 = 40;
            this.COST_1_1_2 = 50;
            //flamer
            this.COST_1_2_0 = 40;
            this.COST_1_2_1 = 40;
            this.COST_1_2_2 = 50;
            //mech cost
            //apc
            this.COST_2_0_0 = 40;
            this.COST_2_0_1 = 50;
            this.COST_2_0_2 = 50;
            //sniper
            this.COST_2_1_0 = 30;
            this.COST_2_1_1 = 40;
            this.COST_2_1_2 = 50;
            //tank
            this.COST_2_2_0 = 50;
            this.COST_2_2_1 = 50;
            this.COST_2_2_2 = 50;
            //Maximum upgrade limit for node
            this.NODE_UPGRADE_LIMIT = 4;
            //Set AUTO_SELECT_NODE to true to enable the base to be selected when it is ready to launch a unit or 'has an arrow'
            this.AUTO_SELECT_NODE = true;
            //money received for shanking a snitch
            this.REWARD_0_0 = 1;
            this.REWARD_0_1 = 3;
            this.REWARD_0_2 = 5;
            this.REWARD_1_0 = 10;
            this.REWARD_1_1 = 15;
            this.REWARD_1_2 = 20;
            //build times type_level
            this.BARRACK_TIME_0_1 = 8000;
            this.BARRACK_TIME_0_2 = 10000;
            this.BARRACK_TIME_0_3 = 12000;
            this.BARRACK_TIME_1_1 = 10000;
            this.BARRACK_TIME_1_2 = 15000;
            this.BARRACK_TIME_1_3 = 20000;
            this.BARRACK_TIME_2_1 = 20000;
            this.BARRACK_TIME_2_2 = 25000;
            this.BARRACK_TIME_2_3 = 30000;
            this.MECH_TIME_0_1 = 80000;
            this.MECH_TIME_0_2 = 100000;
            this.MECH_TIME_0_3 = 120000;
            this.MECH_TIME_1_1 = 50000;
            this.MECH_TIME_1_2 = 60000;
            this.MECH_TIME_1_3 = 80000;
            this.MECH_TIME_2_1 = 100000;
            this.MECH_TIME_2_2 = 104000;
            this.MECH_TIME_2_3 = 108000;
            //system
            this.GAME_Y = 205;
            this.HALFWAY = 512;
            //stretching arrow
            this.STRETCH_STEP = 20;
            this.DRAG_MIN = 0;
            this.RANGE = 0.2;
            //number the distance is divided by
            this.CANNON_STRETCH = 10;
            this.CANNON_X = 384;
            this.CANNON_Y_1 = 824;
            this.CANNON_Y_2 = 202;
            this.CANNON_TYPE = 0;
            this.CANNON_FREQUENCY = 100;
            this.CANNON_LEEWAY = 10;
            this.CANNON_DIST_LEEWAY = 10;
            this.CANNON_DIST_VAR = 10;
            //delay between bullets fired
            this.SCALE_IMG = true;
            this.OFFSET_IMG = false;
            this.PLAYERS = 2;
            this.LEVEL = 0;
            this.TILE_WIDTH = 48;
            this.TILE_HEIGHT = 48.761948;
            //tick var regulates how often shooting is called
            this.TICK_VAR = 5;
            this.TILE_FRICTION = 0.5;
            //time variables are set in milliseconds
            this.CALL_IN_START_TIME = 50000;
            this.CALL_IN_RETRACT_TIME = 8000;
            //boolean if call ins are timed out
            this.CALL_IN_CLEAR = true;
            this.TICK_DURATION = 2000;
            this.TICK_MONEY = 1;
            //helicopter
            this.HELI_SPEED = 3.5;
            this.HELI_DROP_WAIT = 48;
            this.HELI_POST_WAIT = 24;
            this.HELI_HOVER_DIST = 200;
            this.HELI_HOVER_SPEED = 1;
            this.HELI_ROT_SPEED = 0.0015;
            this.HELI_HOVER_COUNT = 3;
            this.HELI_BOUNDS = 100;
            //maximum distance the bombing run can travel
            this.RUN_MAX = 400;
            this.FLARE_DIST = 5000;
            //how long apc walks before firing independent of movement
            this.APC_WALK_VAR = 200;
            //how far out from body it checks traffic
            this.APC_TRAFFIC_DISTANCE = 50;
            //raidus of circular checking traffic
            this.APC_TRAFFIC_RADIUS = 120;
            this.SNIPER_DIG_VAR = 200;
            this.SNIPER_DIG_PROXIMITY = 50;
            this.SNIPER_PRE_VAR = 100;
            this.SNIPER_POST_VAR = 30;
            //time in between shots when reached node
            this.SNIPER_NODE_VAR = 200;
            this.TANK_WALK_VAR = 200;
            this.TANK_PRE_VAR_1 = 25;
            this.TANK_PRE_VAR_2 = 30;
            this.TANK_PRE_VAR_3 = 35;
            this.TANK_POST_VAR = 75;
            this.TANK_SPLASH = 100;
            this.TANK_ROTATE_SPEED = 0.05;
            //how far out from body it checks traffic
            this.TANK_TRAFFIC_DISTANCE = 50;
            //raidus of circular checking traffic
            this.TANK_TRAFFIC_RADIUS = 120;
            //Pnc.ActionManager.myParameters = this;
            if (this.CHEATING) {
                this.CANNON_MG_TIME = 250000;
                this.CALL_IN_START_TIME = 1;
            }
        }
        return Parameters;
    })();
    StandOff.Parameters = Parameters;
})(StandOff || (StandOff = {}));
var MyStates;
(function (MyStates) {
    var Loader = (function (_super) {
        __extends(Loader, _super);
        function Loader() {
            _super.call(this, 'Loader', 'Splash1', { width: 768, height: 1024 }, './assets/');
            console.log("Create Loader");
        }
        /*
        init() {
        this.bg = new Kiwi.GameObjects.Sprite(this, this.textures.loadBG, 0, 0);
        this.addChild(this.bg);
        this.bg.x = 384 - this.bg.width / 2;
        this.bg.y = 512 - this.bg.height / 2;
        this.bar = new Kiwi.GameObjects.Sprite(this, this.textures.bar, 240, 291);
        this.addChild(this.bar);
        this.overlay = new Kiwi.GameObjects.Sprite(this, this.textures.loadOverlay, 206, 245);
        this.addChild(this.overlay);
        }*/
        //var LoadingState = new KiwiLoadingScreen('Loader', 'IntroState', { width: 600, height: 800 }, 'assets/img/loading/');
        Loader.prototype.preload = function () {
            _super.prototype.preload.call(this);

            for (var i = this.game.fileStore.keys.length - 1; i >= 0; i--) {
                //console.log("Removing ", game.fileStore.keys[i]);
                this.game.fileStore.removeFile(this.game.fileStore.keys[i]);
                //console.log("Removed ", game.fileStore.keys[i]);// should be undefined
            }
            this.game.fileStore._size = 0;

            this.game.stage.canvas.style.cssText = "idtkscale:ScaleAspectFit";
            var colours = 4;

            for (var i = 0; i <= this.game.colorsSelected.length - 1; i++) {
                //effects
                //if (i == (<any>this.game).side1Colour + 1 || i == (<any>this.game).side2Colour + 1) {
                this.addTextureAtlas('effects' + (this.game.colorsSelected[i] + 1), 'assets/Atlases/effects' + (this.game.colorsSelected[i] + 1) + '.png', 'effectJSON', 'assets/Atlases/effects.json');
                this.addTextureAtlas('nodeButtons' + (this.game.colorsSelected[i] + 1), 'assets/Atlases/nodeButtons' + (this.game.colorsSelected[i] + 1) + '.png', 'nodeButtonsJSON', 'assets/Atlases/nodeButtons.json');

                this.addSpriteSheet('chevron' + (this.game.colorsSelected[i] + 1), 'assets/overlayBomber_' + (this.game.colorsSelected[i] + 1) + '.png', 225, 75);

                //progress
                this.addSpriteSheet('cpl' + (this.game.colorsSelected[i] + 1), 'assets/overlayGunCannon_Lcharge.png', 16, 64);
                this.addSpriteSheet('cpr' + (this.game.colorsSelected[i] + 1), 'assets/overlayGunCannon_Rcharge.png', 16, 64);

                //call in buttons
                this.addSpriteSheet('callIn0_' + (this.game.colorsSelected[i] + 1), 'assets/btnCallin_HELO_' + (this.game.colorsSelected[i] + 1) + '.png', 68, 68);
                this.addSpriteSheet('callIn1_' + (this.game.colorsSelected[i] + 1), 'assets/btnCallin_BOMBER_' + (this.game.colorsSelected[i] + 1) + '.png', 68, 68);
                this.addSpriteSheet('callIn2_' + (this.game.colorsSelected[i] + 1), 'assets/btnCallin_HEAL_' + (this.game.colorsSelected[i] + 1) + '.png', 68, 68);

                this.addSpriteSheet('hex', 'assets/call-in-hexes.png', 60, 527);
                this.addSpriteSheet('bottomHex', 'assets/bottom-hexes.png', 60, 108);
                this.addSpriteSheet('hexBorder', 'assets/top-colours-call-in-border.png', 60, 22);

                //countdown stuffs
                this.addSpriteSheet('countdown', 'assets/countdown.png', 36, 28);
                this.addImage('countdownBase', 'assets/countdown-boxes.png');
                this.addImage('countdownText', 'assets/countdown-images.png');
                this.addImage('countdownEngage', 'assets/engage.png');

                //}
                // ============== Tutorial ====================
                this.addSpriteSheet('tutBottomPanel' + (this.game.colorsSelected[i]), 'assets/Tutorial/tutorial-bottom-panel-atlas-' + (this.game.colorsSelected[i] + 1) + '.png', 768, 268);

                this.addSpriteSheet('tutCallin' + (this.game.colorsSelected[i]), 'assets/Tutorial/tutorial-callin-panel-atlas-' + (this.game.colorsSelected[i] + 1) + '.png', 96, 296);

                this.addSpriteSheet('tutTopPanel' + (this.game.colorsSelected[i]), 'assets/Tutorial/tutorial-top-panel-atlas-' + (this.game.colorsSelected[i] + 1) + '.png', 639, 237);
                this.addSpriteSheet('messagePanel', 'assets/Tutorial/chat-panel.png', 639, 237);
            }

            this.addSpriteSheet('cannonSymbol', 'assets/overlayGunCannon_middleSymbols.png', 24, 32);

            //infantry
            this.addTextureAtlas('infantry', 'assets/Atlases/infantry.png', 'infantryJSON', 'assets/Atlases/infantry.json');
            this.addTextureAtlas('infantryDeaths', 'assets/Atlases/infantryDeaths.png', 'infantryDeathsJSON', 'assets/Atlases/infantryDeaths.json');
            this.addTextureAtlas('vehicles', 'assets/Atlases/vehicles.png', 'vehiclesJSON', 'assets/Atlases/vehicles.json');
            this.addTextureAtlas('vehicleDeaths', 'assets/Atlases/vehicleDeaths.png', 'vehicleDeathsJSON', 'assets/Atlases/vehicleDeaths.json');
            this.addTextureAtlas('consoleButtons', 'assets/Atlases/consoleButtons.png', 'consoleButtonsJSON', 'assets/Atlases/consoleButtons.json');
            this.addTextureAtlas('callIns', 'assets/Atlases/callIns.png', 'callInsJSON', 'assets/Atlases/callIns.json');

            //win game
            this.addImage('winOverlay', 'assets/Menu/animatedBackground/spaceBlack.png');
            this.addImage('defeatText', 'assets/defeat-message.png');
            this.addImage('winText', 'assets/victory-message.png');
            this.addImage('winBase', 'assets/message-container.png');
            this.addSpriteSheet('winRematch', 'assets/rematch-button-sprite-sheet.png', 220, 50);
            this.addSpriteSheet('winQuit', 'assets/quit-button-sprite-sheet.png', 220, 50);
            this.addSpriteSheet('winBG', 'assets/Victory.png', 678, 263);
            this.addSpriteSheet('defeatBG', 'assets/Defeat.png', 678, 263);
            this.addSpriteSheet('singleWinQuit', 'assets/Button_Quit.png', 359, 83);
            this.addSpriteSheet('singleWinRematch', 'assets/Button_PlayAgain.png', 359, 83);
            this.addSpriteSheet('winDefeat', 'assets/VictoryDefeat.png', 344, 54);
            this.addImage('creditsEarnedImage', 'assets/TokenEarned_half.png');

            //pause menu stuff
            this.addImage('startScreenbg', 'assets/start-screen.png');

            this.addSpriteSheet('pauseSFXButton', 'assets/sfx-on-off-buttons.png', 175, 84);
            this.addSpriteSheet('pauseMusicButton', 'assets/music-on-off-buttons.png', 175, 84);

            this.addImage('pauseResume', 'assets/pause_menu_resume_button.png');
            this.addImage('pauseQuit', 'assets/pause_menu_quit_button.png');
            this.addImage('pauseBG', 'assets/pause-bg.jpg');

            this.addSpriteSheet('crate', 'assets/CratehalfRes.png', 64, 64);
            this.addSpriteSheet('pog', 'assets/PogFlash_half.png', 64, 64);
            this.addSpriteSheet('reward1', 'assets/Reward_Credit_25_half.png', 64, 64);
            this.addSpriteSheet('reward2', 'assets/Reward_Credit_50_half.png', 64, 64);
            this.addSpriteSheet('rewardX', 'assets/Reward_Credit_100_half.png', 64, 64);
            this.addSpriteSheet('reward3', 'assets/Reward_Credit_Heli_half.png', 64, 64);
            this.addSpriteSheet('reward4', 'assets/Reward_Credit_AirStrike_half.png', 64, 64);
            this.addSpriteSheet('reward5', 'assets/Reward_Credit_Heal_half.png', 64, 64);

            //neutral crate drop dude
            //this.addSpriteSheet('dropper', 'assets/vehBomber_base_5Half.png', 112, 300);
            //new factory buttons
            this.addSpriteSheet('fbBarracks', 'assets/btnFactory_FG_barr.png', 46, 46);
            this.addSpriteSheet('fbMech', 'assets/btnFactory_FG_mech.png', 46, 46);
            this.addSpriteSheet('fbProg', 'assets/btnFactory_PR.png', 12, 96);
            this.addSpriteSheet('fbType', 'assets/btnFactory_AVAIL.png', 44, 22);

            this.addSpriteSheet('fbFactoryNone', 'assets/btnFactory_FG_noUnit.png', 46, 46);
            this.addSpriteSheet('fbFactoryType', 'assets/btnFactory_TYPE.png', 16, 32);

            this.addSpriteSheet('supportBase', 'assets/btnSupport_BG.png', 78, 246);
            this.addSpriteSheet('supportButton', 'assets/btnSupport_main.png', 93, 43);
            this.addSpriteSheet('supportText', 'assets/btnSupport_text.png', 78, 15);

            this.addSpriteSheet('consolePauseBtn', 'assets/btnConsole_PAUSE.png', 22, 20);

            /*this.addSpriteSheet('consoleTextMisc', 'assets/btnConsole_unitText_misc.png', 200, 64);
            this.addSpriteSheet('consoleTextUnit', 'assets/btnConsole_unitText_unit.png', 200, 64);
            this.addSpriteSheet('consoleUpgradeBtn', 'assets/btnConsole_UPGRADE.png', 100, 50);
            this.addImage('consoleButtonHighlight', 'assets/btnTroopType_select.png');
            */
            this.addSpriteSheet('healthGreen', 'assets/overlayHealth_green.png', 16, 4);
            this.addSpriteSheet('healthRed', 'assets/overlayHealth_red.png', 16, 4);

            this.addImage('background' + (this.game.mapSelected + 1), 'assets/MAP0' + (this.game.mapSelected + 1) + '.png');

            this.addSpriteSheet('tokenNumbers', 'assets/tokensButton_numbers.png', 13, 13);

            //this.addSpriteSheet('creditNumbers', 'assets/sprite-font.png', 18, 12);
            this.addSpriteSheet('mudBubble', 'assets/MudBubble_01.png', 50, 50);
            this.addSpriteSheet('lavaBubble', 'assets/LAVABubble_02.png', 50, 50);

            this.addImage('tile0', 'assets/tile0.png');
            this.addImage('tile1', 'assets/tile1.png');
            this.addImage('tile2', 'assets/tile2.png');
            this.addSpriteSheet('tile3', 'assets/LAVATile_01.png', 50, 50);
            this.addImage('tile4', 'assets/tile4.png');

            //SFX
            //---------------------------------
            this.addAudio('selectFactorySFX', 'assets/Sounds/SelectFactory.mp3');
            this.addAudio('selectUnitSFX', 'assets/Sounds/SelectUnit.mp3');
            this.addAudio('factoryExplodeSFX', 'assets/Sounds/factory-explode.mp3');
            this.addAudio('bgSFX', 'assets/Sounds/loop.mp3');

            this.addAudio('bomberSFX', 'assets/Sounds/bomberRoar.mp3');
            this.addAudio('artillarySFX', 'assets/Sounds/Cannon_artillaryFire.mp3');
            this.addAudio('selectCannonSFX', 'assets/Sounds/Cannon_switchMode.mp3');
            this.addAudio('cannonMGSFX', 'assets/Sounds/Cannon_machineGunEnd.mp3');

            //add
            /*this.addAudio('footstepSFX', 'assets/Sounds/FootstepsSingle1.mp3');
            this.addAudio('bazookaHitSFX', 'assets/Sounds/BazookaHit.mp3');
            */
            //this.addAudio('tankRotateSFX', 'assets/Sounds/TankTurretRotateMiddle.mp3');
            this.addAudio('tankStepSFX', 'assets/Sounds/TankStep2.mp3');

            this.addAudio('infShotSFX1', 'assets/Sounds/rifleShot1.mp3');
            this.addAudio('infShotSFX2', 'assets/Sounds/BazookaShot.mp3');
            this.addAudio('infShotSFX3', 'assets/Sounds/FlamerShot2.mp3');
            this.addAudio('vehShotSFX1', 'assets/Sounds/APCShot.mp3');
            this.addAudio('vehShotSFX2', 'assets/Sounds/Sniper_Shot2.mp3');
            this.addAudio('vehShotSFX3', 'assets/Sounds/Tank_Shot2.mp3');

            //UI sfx
            this.addAudio('cannonErrorSFX', 'assets/Sounds/Cannon_ClickOnChargingCannon.mp3');
            this.addAudio('cannonEmptySFX', 'assets/Sounds/Cannon_outOfAmmo.mp3');
            this.addAudio('cannonChargedSFX', 'assets/Sounds/Cannon_fullyCharged.mp3');

            this.addAudio('creditTickSFX', 'assets/Sounds/CreditTicker.mp3');
            this.addAudio('buttonErrorSFX', 'assets/Sounds/ClickOnGreyButton.mp3');
            this.addAudio('launchUnitSFX', 'assets/Sounds/LaunchUnitRelease.mp3');
            this.addAudio('arrowSFX', 'assets/Sounds/LaunchUnitArrows.mp3');
            this.addAudio('readyClickSFX', 'assets/Sounds/LaunchUnitCircleClick.mp3');

            //vehicles
            //death
            this.addAudio('vehDieSFX1', 'assets/Sounds/APCBreak2.mp3');
            this.addAudio('vehDieSFX2', 'assets/Sounds/Sniper_Break2.mp3');
            this.addAudio('vehDieSFX3', 'assets/Sounds/Tank_Break.mp3');

            //PREV
            //------------------------
            //small
            //this.addAudio('infShotSFX1', 'assets/Sounds/rifleShot1.mp3');
            //medium
            //big
            this.addAudio('bombSFX', 'assets/Sounds/Bomblet2_9.mp3');

            //this.addAudio('vehShotSFX3', 'assets/Sounds/Tank_Shot.mp3');
            //SHARED
            //------------------------
            //this.addAudio('explosionBigSFX', 'assets/Sounds/Explosion_Big.mp3');
            this.addAudio('explosionMediumSFX', 'assets/Sounds/Explosion_Medium.mp3');
            this.addAudio('explosionSmallSFX', 'assets/Sounds/Explosion_small.mp3');

            //------------------------
            //movement
            this.addAudio('APCOpenSFX', 'assets/Sounds/APCOpenClose.mp3');
            this.addAudio('APCStartSFX', 'assets/Sounds/APCStart.mp3');
            this.addAudio('sniperDigDownSFX', 'assets/Sounds/SniperDiggingDown.mp3');
            this.addAudio('sniperDigUpSFX', 'assets/Sounds/SniperDiggingUp.mp3');

            //call in audio AlphaTeam.mp3
            this.addAudio('AlphaTeamSFX', 'assets/Sounds/AlphaTeam.mp3');
            this.addAudio('DeployTroopsSFX', 'assets/Sounds/DeployTroops.mp3');
            this.addAudio('HealSFX', 'assets/Sounds/Heal.mp3');
        };

        Loader.prototype.create = function (players, level, colour1, colour2, support) {
            //this.game.audio.stopAll();
            FlurryAgent.logEvent(players + " player game started");
            FlurryAgent.logEvent(support[0] + " alpha teams");
            FlurryAgent.logEvent(support[1] + " air strikes");
            FlurryAgent.logEvent(support[2] + " heal beams");

            if (players == 2) {
                var my1String = "Player 1 Guest " + (this.game.userManager.currentMainUser.name == 'Guest');
                var my2String = "Player 2 Guest " + (this.game.userManager.secondaryUser.name == 'Guest');
                FlurryAgent.logEvent(my1String);
                FlurryAgent.logEvent(my2String);

                FlurryAgent.logEvent("alpha teams two player " + support[0]);
                FlurryAgent.logEvent("air strikes two player " + support[1]);
                FlurryAgent.logEvent("heal beams two player " + support[2]);
            } else {
                var my1String = "Single Player Guest " + (this.game.userManager.currentMainUser.name == 'Guest');
                FlurryAgent.logEvent(my1String);
                FlurryAgent.logEvent("alpha teams single player " + support[0]);
                FlurryAgent.logEvent("air strikes single player " + support[1]);
                FlurryAgent.logEvent("heal beams single player " + support[2]);
            }

            this.game.states.switchState('Play', MyStates.Play, null, { players: players, level: this.game.mapSelected, colour1: colour1 + 1, colour2: colour2 + 1, support: support });
        };
        return Loader;
    })(KiwiLoadingScreen);
    MyStates.Loader = Loader;
})(MyStates || (MyStates = {}));
var MyStates;
(function (MyStates) {
    var MenuLoader = (function (_super) {
        __extends(MenuLoader, _super);
        function MenuLoader() {
            _super.call(this, 'MenuLoader', 'MainMenu', { width: 768, height: 1024 }, './assets/');
            console.log("Create Loader");
        }
        MenuLoader.prototype.init = function () {
            ///*
            var fullscreen1Params = {
                "fullscreenAdUnit-iPad": "agltb3B1Yi1pbmNyDQsSBFNpdGUYjf30Eww",
                "fullscreenAdUnit-iPhone": "agltb3B1Yi1pbmNyDQsSBFNpdGUYjf30Eww",
                "refresh": 20
            };

            if (!this.game.commodityManager.hasElite) {
                CocoonJS.Ad.createFullscreen(fullscreen1Params);
                CocoonJS.Ad.refreshFullScreen();
                CocoonJS.Ad.preloadFullScreen();
            }
        };

        MenuLoader.prototype.preload = function () {
            _super.prototype.preload.call(this);

            for (var i = this.game.fileStore.keys.length - 1; i >= 0; i--) {
                //console.log("Removing ", game.fileStore.keys[i]);
                this.game.fileStore.removeFile(this.game.fileStore.keys[i]);
                //console.log("Removed ", game.fileStore.keys[i]);// should be undefined
            }
            this.game.fileStore._size = 0;

            this.game.stage.canvas.style.cssText = "idtkscale:ScaleAspectFit";

            // ================ General Assets ======================
            this.addSpriteSheet('halfPanel', 'assets/Menu/twoPlayerSetup/setup-panel-sprite.png', 768, 516);
            this.addSpriteSheet('backButton', 'assets/Menu/accountSetup/back-button.png', 360, 85);
            this.addSpriteSheet('bottomSetupPanel', 'assets/Menu/twoPlayerSetup/bottom-setup-panel-sprite.png', 768, 157);
            this.addSpriteSheet('colorSelectButtonsRight', 'assets/Menu/twoPlayerSetup/colour-buttons-right-sprite.png', 100, 28);
            this.addSpriteSheet('colorSelectButtonsLeft', 'assets/Menu/twoPlayerSetup/colour-buttons-left-sprite.png', 100, 28);
            this.addSpriteSheet('readyButton', 'assets/Menu/twoPlayerSetup/ready-button-sprite.png', 360, 85);
            this.addImage('waitingForOpponent', 'assets/Menu/twoPlayerSetup/waiting-for-opponent.png');
            this.addSpriteSheet('muteSound', 'assets/soundOnOff.png', 52, 53);
            this.addSpriteSheet('muteMusic', 'assets/musicOnOff.png', 52, 53);

            /// ================= MAIN MENU ====================
            this.addImage('bottomPanel', 'assets/Menu/startMenu/bottom-panel.png');
            this.addImage('middlePanel', 'assets/Menu/startMenu/middle-panel.png');
            this.addImage('topPanel', 'assets/Menu/startMenu/top-panel.png');
            this.addImage('shadowGradBottom', 'assets/Menu/startMenu/shadow-gradient-bottom.png');
            this.addImage('shadowGradTop', 'assets/Menu/startMenu/shadow-gradient-top.png');
            this.addImage('standoffTitle', 'assets/Menu/startMenu/standoff-title.png');
            this.addImage('tubJumperLogo', 'assets/Menu/startMenu/tubJumpers-logo.png');
            this.addImage('GFSplash', 'assets/Menu/startMenu/gamefroot-logo.png');
            this.addImage('NNSplash', 'assets/Menu/startMenu/nyuknyuk-logo.png');

            this.addSpriteSheet('GFIcon', 'assets/Menu/startMenu/Gamefroot-icon.png', 80, 52);
            this.addSpriteSheet('NNIcon', 'assets/Menu/startMenu/nyuknyuk-icon.png', 87, 80);
            this.addSpriteSheet('statsBtn', 'assets/Menu/startMenu/stats-button.png', 360, 85);
            this.addSpriteSheet('storeBtn', 'assets/Menu/startMenu/store-button.png', 360, 85);
            this.addSpriteSheet('trainingBtn', 'assets/Menu/startMenu/training-button.png', 360, 85);
            this.addSpriteSheet('twoPlayerBtn', 'assets/Menu/startMenu/two-player-button.png', 360, 85);
            this.addImage('splashBackground', 'assets/SplashBackground.jpg');

            // =================Account Setup ================= \\
            this.addSpriteSheet('loginButton', 'assets/Menu/accountSetup/login-button.png', 359, 85);
            this.addSpriteSheet('signUpButton', 'assets/Menu/accountSetup/signup-button.png', 359, 85);
            this.addSpriteSheet('guestButton', 'assets/Menu/accountSetup/guest-button.png', 359, 85);

            // ============== Two Player Setup ================== \\
            this.addImage('colourButton', 'assets/Menu/twoPlayerSetup/colour-button.png');
            this.addSpriteSheet('selectedPlayerBlock', 'assets/Menu/twoPlayerSetup/selected-player-account-block-sprite.png', 716 / 2, 62 / 2);
            this.addSpriteSheet('accountNameBlock', 'assets/Menu/twoPlayerSetup/account-name-block-sprite.png', 392, 32);
            this.addSpriteSheet('scrollbar', 'assets/Menu/twoPlayerSetup/scrollbar-sprite.png', 8, 34);
            this.addSpriteSheet('selectAccountPanel', 'assets/Menu/twoPlayerSetup/select-account-panel-sprite.png', 410, 290);

            // =================Two Player Settings ======================
            this.addImage('callIns2Player', 'assets/Menu/twoPlayerSettings/call-ins-2-player.png');
            this.addImage('infoDisplayed', 'assets/Menu/twoPlayerSettings/info-displayed.png');
            this.addImage('mapIcon', 'assets/Menu/twoPlayerSettings/map-icon.png');
            this.addImage('tokensAndCallinsPanel', 'assets/Menu/twoPlayerSettings/tokens-and-callins-panel.png');
            this.addImage('tokenSymbol', 'assets/Menu/twoPlayerSettings/slot/token-symbol.png');

            this.addSpriteSheet('maps', 'assets/Menu/twoPlayerSettings/maps.png', 286, 230);
            this.addSpriteSheet('callinsSpriteSheet', 'assets/Menu/twoPlayerSettings/call-in-icons-sprite.png', 50, 50);
            this.addSpriteSheet('buyMore', 'assets/Menu/twoPlayerSettings/buy-more.png', 359, 84);
            this.addSpriteSheet('leftArrow', 'assets/Menu/twoPlayerSettings/left-arrow-sprite.png', 53, 53);
            this.addSpriteSheet('minus', 'assets/Menu/twoPlayerSettings/minus-sprite.png', 53, 53);
            this.addSpriteSheet('plus', 'assets/Menu/twoPlayerSettings/plus-sprite.png', 53, 53);
            this.addSpriteSheet('rightArrow', 'assets/Menu/twoPlayerSettings/right-arrow-sprite.png', 53, 53);
            this.addSpriteSheet('settingsPanel', 'assets/Menu/twoPlayerSettings/settings-panel-2-player.png', 768, 424);
            this.addSpriteSheet('tokensAndCallinsPanel', 'assets/Menu/twoPlayerSettings/tokens-and-callins-panel.png', 410, 290);
            this.addSpriteSheet('displayInfo', 'assets/Menu/twoPlayerSettings/slot/display-info.png', 46, 47);
            this.addSpriteSheet('intelligence', 'assets/Menu/twoPlayerSettings/info-displayed.png', 215, 204);

            // ===================Training Setup =======================
            this.addImage('price', 'assets/Menu/onePlayerSetup/price.png');
            this.addImage('productImage', 'assets/Menu/onePlayerSetup/product-image.png');
            this.addImage('productThanks', 'assets/Menu/onePlayerSetup/product-thanks.png');
            this.addImage('tokenSpecialsPanel', 'assets/Menu/onePlayerSetup/tokens-and-specials-panel.png');

            // ====================Training Settings ===================
            this.addSpriteSheet('trainingSettingsPanel', 'assets/Menu/onePlayerSettings/settings-panel-1-player.png', 768, 424);
            this.addSpriteSheet('tutorialOnOff', 'assets/Menu/onePlayerSettings/on-off-button-colours-sprite.png', 111, 43);

            // ==================== Store Menu =========================
            this.addImage('product1', 'assets/Menu/store/product-image-small-1.png');
            this.addImage('product2', 'assets/Menu/store/product-image-small-2.png');
            this.addImage('product3', 'assets/Menu/store/product-image-small-3.png');
            this.addImage('storeBottomPanel', 'assets/Menu/store/store-panel-bottom.png');
            this.addImage('storeTopPanel', 'assets/Menu/store/store-panel-top.png');

            this.addSpriteSheet('buyButton', 'assets/Menu/store/buy-button.png', 144, 54);

            // ===================== ANimated Backgounds ================
            this.addImage('spaceBlueNebula', 'assets/Menu/animatedBackground/spaceBlueNebula.png');
            this.addImage('spacePinkClouds', 'assets/Menu/animatedBackground/spacePinkClouds.png');
            this.addImage('spacePinkNebula', 'assets/Menu/animatedBackground/spacePinkNebula.png');
            this.addImage('spaceStar', 'assets/Menu/animatedBackground/spaceStar.png');
            this.addImage('spacePlanet', 'assets/Menu/animatedBackground/spacePlanet.png');
            this.addImage('spaceBlack', 'assets/Menu/animatedBackground/spaceBlack.png');

            this.addSpriteSheet('bomberClose', 'assets/Menu/animatedBackground/BomberClose.png', 175, 127);
            this.addSpriteSheet('bomberMedium', 'assets/Menu/animatedBackground/BomberMedium.png', 88, 64);
            this.addSpriteSheet('bomberDistant', 'assets/Menu/animatedBackground/BomberDistant.png', 87, 64);

            this.addSpriteSheet('destroyerClose', 'assets/Menu/animatedBackground/DestroyerClose.png', 512, 256);
            this.addSpriteSheet('destroyerMedium', 'assets/Menu/animatedBackground/DestroyerMedium.png', 256, 128);
            this.addSpriteSheet('destroyerDistant', 'assets/Menu/animatedBackground/DestroyerDistant.png', 128, 64);

            this.addSpriteSheet('helicopterDistant', 'assets/Menu/animatedBackground/HelicopterDistant.png', 36, 25);
            this.addSpriteSheet('helicopterClose', 'assets/Menu/animatedBackground/HelicopterClose.png', 96, 67);
            this.addSpriteSheet('helicopterMedium', 'assets/Menu/animatedBackground/HelicopterMedium.png', 72, 50);

            // ===========Stats Menu ===================
            this.addImage('leaderboardPanel', 'assets/Menu/stats/leaderboard-panels.png');
            this.addSpriteSheet('doneButton', 'assets/Menu/stats/done-button.png', 48, 34);
            this.addImage('leaderboardPlayerPanel', 'assets/Menu/stats/player-box.png');
            this.addImage('leaderboardCurrentPlayerPanel', 'assets/Menu/stats/current-player-box.png');

            //====================== AUDIO =============
            this.addAudio('backgroundMusic', 'assets/Sounds/Menu/TubJumpers_theme_01.09.14.mp3');
            this.addAudio('errorButton', 'assets/Sounds/ClickOnGreyButton.mp3');
            this.addAudio('successButton', 'assets/Sounds/SelectUnit.mp3');
        };

        MenuLoader.prototype.create = function () {
            this.game.states.switchState('MainMenu', MyStates.MainMenu);
        };
        return MenuLoader;
    })(KiwiLoadingScreen);
    MyStates.MenuLoader = MenuLoader;
})(MyStates || (MyStates = {}));
var MyStates;
(function (MyStates) {
    var MainMenu = (function (_super) {
        __extends(MainMenu, _super);
        function MainMenu() {
            _super.call(this, 'MainMenu');
            this.firstTime = false;
            this.fadeInBoo = true;
        }
        MainMenu.prototype.preload = function () {
            _super.prototype.preload.call(this);
        };
        MainMenu.prototype.init = function () {
            this.firstTime = true;
            this.backgroundMusic = new Kiwi.Sound.Audio(this.game, 'backgroundMusic', 0.75, true);

            if (this.game.saveManager.exists('musicMuted') == true) {
                this.game.muteMusic = this.game.saveManager.getData('musicMuted');
            }

            if (this.game.saveManager.exists('soundMuted') == true) {
                this.game.muteSFX = this.game.saveManager.getData('soundMuted');
            }

            if (this.game.saveManager.exists('playTutorial') == true) {
                this.game.playTutorial = this.game.saveManager.getData('playTutorial');
            }

            this.game.menuSFX = new Managers.AudioSoundFX(this.game);
        };

        MainMenu.prototype.create = function () {
            _super.prototype.create.call(this);

            this.background = new Kiwi.GameObjects.Sprite(this, this.textures.splashBackground, 0, 0);
            this.addChild(this.background);

            //ships here
            this.backgroundShips = new MenuEntities.backgroundAnimations(this);
            this.addChild(this.backgroundShips);

            this.standoffTitle = new Kiwi.GameObjects.Sprite(this, this.textures.standoffTitle, 70, 135);
            this.addChild(this.standoffTitle);
            this.tubJumperLogo = new Kiwi.GameObjects.Sprite(this, this.textures.tubJumperLogo, 263, -100);
            this.GFLogo = new Kiwi.GameObjects.Sprite(this, this.textures.GFIcon, 661, 1047);
            this.NNLogo = new Kiwi.GameObjects.Sprite(this, this.textures.NNIcon, 30, 1033);

            this.shadowGradTop = new Kiwi.GameObjects.Sprite(this, this.textures.shadowGradTop, 0, 0);
            this.shadowGradBot = new Kiwi.GameObjects.Sprite(this, this.textures.shadowGradBottom, 0, 956);

            //Splashes
            this.NNSplash = new Kiwi.GameObjects.Sprite(this, this.textures.NNSplash, 0, 0);
            this.GFSplash = new Kiwi.GameObjects.Sprite(this, this.textures.GFSplash, 0, 0);
            this.NNSplash.x = this.game.stage.width / 2 - this.NNSplash.width / 2;
            this.GFSplash.x = this.game.stage.width / 2 - this.GFSplash.width / 2;
            this.NNSplash.y = this.game.stage.height / 2 - this.NNSplash.height / 2;
            this.GFSplash.y = this.game.stage.height / 2 - this.GFSplash.height / 2;

            //Panels
            this.middlePanel = new Kiwi.GameObjects.Sprite(this, this.textures.middlePanel, 0, 286);

            // this.addChild(this.middlePanel);
            this.topPanel = new Kiwi.GameObjects.Sprite(this, this.textures.topPanel, 0, -501);
            this.bottomPanel = new Kiwi.GameObjects.Sprite(this, this.textures.bottomPanel, 0, 923);

            //Main Buttons
            this.trainingBtn = new MenuEntities.MenuButton(this, this.textures.trainingBtn, 205, 408);
            this.twoPlayerBtn = new MenuEntities.MenuButton(this, this.textures.twoPlayerBtn, 205, 309);
            this.statsBtn = new MenuEntities.MenuButton(this, this.textures.statsBtn, 205, 606);
            this.storeBtn = new MenuEntities.MenuButton(this, this.textures.storeBtn, 205, 509);
            this.muteSound = new Kiwi.GameObjects.Sprite(this, this.textures.muteSound, 14, 0);
            this.muteMusic = new Kiwi.GameObjects.Sprite(this, this.textures.muteMusic, 68, 0);

            this.twoPlayerBtn.alpha = 0;
            this.trainingBtn.alpha = 0;
            this.storeBtn.alpha = 0;
            this.statsBtn.alpha = 0;
            this.muteMusic.alpha = 0;
            this.muteSound.alpha = 0;

            this.addChild(this.trainingBtn);
            this.addChild(this.twoPlayerBtn);
            this.addChild(this.statsBtn);
            this.addChild(this.storeBtn);

            //Splash Tweens
            this.NNTweenIn = this.game.tweens.create(this.NNSplash);
            this.NNTweenOut = this.game.tweens.create(this.NNSplash);
            this.GFTweenIn = this.game.tweens.create(this.GFSplash);
            this.GFTweenOut = this.game.tweens.create(this.GFSplash);

            this.NNTweenIn.to({ alpha: 1 }, 2000, Kiwi.Animations.Tweens.Easing.Linear.None, false);
            this.NNTweenOut.to({ alpha: 0 }, 500, Kiwi.Animations.Tweens.Easing.Linear.None, false);
            this.GFTweenIn.to({ alpha: 1 }, 2000, Kiwi.Animations.Tweens.Easing.Linear.None, false);
            this.GFTweenOut.to({ alpha: 0 }, 500, Kiwi.Animations.Tweens.Easing.Linear.None, false);

            this.NNTweenIn.chain(this.NNTweenOut);
            this.NNTweenOut.chain(this.GFTweenIn);
            this.GFTweenIn.chain(this.GFTweenOut);
            this.GFTweenOut.onComplete(this.closePanels, this);
            this.NNTweenIn.onComplete(this.stopFade, this);

            // Panel Tweens
            //Close
            this.panelTopClose = this.game.tweens.create(this.topPanel);
            this.panelBottomClose = this.game.tweens.create(this.bottomPanel);
            this.tubJumperIn = this.game.tweens.create(this.tubJumperLogo);
            this.panelTopClose.to({ y: -63 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomClose.to({ y: 485 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelTopClose.onComplete(this.openPanels, this);

            //Open
            this.panelTopOpen = this.game.tweens.create(this.topPanel);
            this.panelBottomOpen = this.game.tweens.create(this.bottomPanel);
            this.tubJumperIn = this.game.tweens.create(this.tubJumperLogo);
            this.tubJumperOut = this.game.tweens.create(this.tubJumperLogo);
            this.GFLogoIn = this.game.tweens.create(this.GFLogo);
            this.NNLogoIn = this.game.tweens.create(this.NNLogo);
            this.panelTopOpen.to({ y: -501 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomOpen.to({ y: 923 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.tubJumperIn.to({ y: 11 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.GFLogoIn.to({ y: 947 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.NNLogoIn.to({ y: 933 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelTopOpen.chain(this.tubJumperIn);
            this.panelTopOpen.chain(this.GFLogoIn);
            this.panelTopOpen.chain(this.NNLogoIn);

            this.twoPlayerBtn.input.onUp.add(this.startMultiplayer, this);
            this.trainingBtn.input.onUp.add(this.startTraining, this);
            this.storeBtn.input.onUp.add(this.storeButtonHit, this);
            this.statsBtn.input.onUp.add(this.statButtonHit, this);
            this.muteMusic.input.onUp.add(this.muteMusicHit, this);
            this.muteSound.input.onUp.add(this.muteSoundHit, this);

            this.GFSplash.alpha = 0;
            this.NNSplash.alpha = 0;

            this.standoffTitle.alpha = 0;

            //Layering panels
            this.addChild(this.bottomPanel);
            this.addChild(this.topPanel);

            this.addChild(this.GFSplash);
            this.addChild(this.NNSplash);
            this.addChild(this.shadowGradBot);
            this.addChild(this.shadowGradTop);
            this.addChild(this.tubJumperLogo);
            this.addChild(this.NNLogo);
            this.addChild(this.GFLogo);
            this.addChild(this.muteMusic);
            this.addChild(this.muteSound);

            //Musics
            if (!this.game.muteSFX) {
                this.muteMusic.animation.switchTo(0);
            } else {
                this.muteMusic.animation.switchTo(1);
            }

            if (!this.game.muteMusic) {
                this.backgroundMusic.volume = 0.75;
                this.muteSound.animation.switchTo(0);
            } else {
                this.backgroundMusic.volume = 0;
                this.muteSound.animation.switchTo(1);
            }

            if (!this.backgroundMusic.isPlaying) {
                this.game.audio.stopAll();
                this.backgroundMusic.play();
            }

            if (this.firstTime) {
                this.NNTweenIn.start();
                this.firstTime = false;
                this.backgroundMusic.play('default', true);
                console.log('Audio Play', this.backgroundMusic.isPlaying, 'Please');
            } else {
                //(<any>CocoonJS.Ad).preloadFullScreen();
                //(<any>CocoonJS.Ad).showFullScreen();
                this.topPanel.y = -63;
                this.bottomPanel.y = 485;
                this.openPanels();
            }
        };

        MainMenu.prototype.update = function () {
            _super.prototype.update.call(this);

            if (this.fadeInBoo) {
                this.topPanel.alpha = this.NNSplash.alpha;
                this.bottomPanel.alpha = this.NNSplash.alpha;
                this.background.alpha = this.NNSplash.alpha;
            }
        };

        MainMenu.prototype.muteMusicHit = function () {
            if (!this.game.muteSFX) {
                this.muteMusic.animation.switchTo(1);
                this.game.muteSFX = true;
            } else {
                this.muteMusic.animation.switchTo(0);
                this.game.muteSFX = false;
            }

            this.game.saveManager.add('musicMuted', this.game.muteSFX, true);
        };

        MainMenu.prototype.muteSoundHit = function () {
            if (!this.game.muteMusic) {
                this.backgroundMusic.volume = 0;
                this.muteSound.animation.switchTo(1);
                this.game.muteMusic = true;
            } else {
                this.backgroundMusic.volume = 0.75;
                this.muteSound.animation.switchTo(0);
                this.game.muteMusic = false;
            }

            this.game.saveManager.add('soundMuted', this.game.muteMusic, true);
        };

        MainMenu.prototype.stopFade = function () {
            this.fadeInBoo = false;
        };

        MainMenu.prototype.openPanels = function () {
            this.twoPlayerBtn.alpha = 1;
            this.trainingBtn.alpha = 1;
            this.storeBtn.alpha = 1;
            this.statsBtn.alpha = 1;
            this.standoffTitle.alpha = 1;
            this.muteMusic.alpha = 1;
            this.muteSound.alpha = 1;
            this.panelTopOpen.start();
            this.panelBottomOpen.start();
        };
        MainMenu.prototype.closePanels = function () {
            this.panelTopClose.start();
            this.panelBottomClose.start();
        };
        MainMenu.prototype.startTraining = function () {
            if (!this.canHitButton())
                return;
            this.tubJumperOut = this.game.tweens.create(this.tubJumperLogo);
            this.GFLogoOut = this.game.tweens.create(this.GFLogo);
            this.NNLogoOut = this.game.tweens.create(this.NNLogo);
            this.tubJumperOut.to({ y: -100 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, true);
            this.GFLogoOut.to({ y: 1047 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, true);
            this.NNLogoOut.to({ y: 1033 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, true);

            this.panelTopClose.onComplete(this.switchTraining, this);
            this.game.menuSFX.playSuccess();
            this.closePanels();
        };
        MainMenu.prototype.switchTraining = function () {
            //this.exitState();
            this.game.states.switchState('TrainingSetup', MyStates.TrainingSetup, null);
        };
        MainMenu.prototype.startMultiplayer = function () {
            if (!this.canHitButton())
                return;

            this.tubJumperOut = this.game.tweens.create(this.tubJumperLogo);
            this.GFLogoOut = this.game.tweens.create(this.GFLogo);
            this.NNLogoOut = this.game.tweens.create(this.NNLogo);
            this.tubJumperOut.to({ y: -100 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, true);
            this.GFLogoOut.to({ y: 1047 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, true);
            this.NNLogoOut.to({ y: 1033 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, true);

            this.panelTopClose.onComplete(this.switchMultiplayer, this);
            this.game.menuSFX.playSuccess();
            this.closePanels();
        };
        MainMenu.prototype.switchMultiplayer = function () {
            //this.exitState();
            this.game.states.switchState('TwoPlayerSetup', MyStates.TwoPlayerSetup, null, { players: 2, level: 1, colour1: 1, colour2: 2, support: [5, 5, 10, 5, 5, 10] });
        };

        MainMenu.prototype.storeButtonHit = function () {
            if (!this.canHitButton())
                return;

            this.tubJumperOut = this.game.tweens.create(this.tubJumperLogo);
            this.GFLogoOut = this.game.tweens.create(this.GFLogo);
            this.NNLogoOut = this.game.tweens.create(this.NNLogo);
            this.tubJumperOut.to({ y: -100 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, true);
            this.GFLogoOut.to({ y: 1047 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, true);
            this.NNLogoOut.to({ y: 1033 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, true);

            this.game.menuSFX.playSuccess();
            this.panelTopClose.onComplete(this.switchStore, this);
            this.closePanels();
        };
        MainMenu.prototype.switchStore = function () {
            this.game.states.switchState('StoreMenu', MyStates.StoreMenu);
        };

        MainMenu.prototype.statButtonHit = function () {
            if (!this.canHitButton())
                return;

            this.tubJumperOut = this.game.tweens.create(this.tubJumperLogo);
            this.GFLogoOut = this.game.tweens.create(this.GFLogo);
            this.NNLogoOut = this.game.tweens.create(this.NNLogo);
            this.tubJumperOut.to({ y: -100 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, true);
            this.GFLogoOut.to({ y: 1047 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, true);
            this.NNLogoOut.to({ y: 1033 }, 200, Kiwi.Animations.Tweens.Easing.Cubic.Out, true);

            this.game.menuSFX.playSuccess();
            this.panelTopClose.onComplete(this.switchStats, this);
            this.closePanels();
        };
        MainMenu.prototype.switchStats = function () {
            this.game.states.switchState('StatsMenu', MyStates.StatsMenu);
        };

        MainMenu.prototype.exitState = function () {
            this.game.tweens.removeAll();
        };

        MainMenu.prototype.loadMap = function () {
            this.game.states.switchState('Play', MyStates.Play, null, { players: 2, level: 1, colour1: 1, colour2: 2, support: [5, 5, 10, 5, 5, 10] });
        };
        MainMenu.prototype.canHitButton = function () {
            var allTweens = this.game.tweens.getAll();
            for (var i = allTweens.length - 1; i >= 0; i--) {
                if (allTweens[i].isRunning) {
                    return false;
                }
            }
            return true;
        };
        return MainMenu;
    })(Kiwi.State);
    MyStates.MainMenu = MainMenu;
})(MyStates || (MyStates = {}));
var MyStates;
(function (MyStates) {
    var AccountSetup = (function (_super) {
        __extends(AccountSetup, _super);
        function AccountSetup() {
            _super.call(this, 'AccountSetup');
            this.fadeInBoo = true;
        }
        AccountSetup.prototype.preload = function () {
            _super.prototype.preload.call(this);
        };

        AccountSetup.prototype.create = function (players, level, colour1, colour2, support) {
            _super.prototype.create.call(this);
            this.players = players;
            this.colour1 = colour1;
            this.colour2 = colour2;
            this.support = support;

            this.background = new Kiwi.GameObjects.Sprite(this, this.textures.splashBackground, 0, 0);
            this.addChild(this.background);
            this.standoffTitle = new Kiwi.GameObjects.Sprite(this, this.textures.standoffTitle, 70, 135);
            this.addChild(this.standoffTitle);
            this.shadowGradTop = new Kiwi.GameObjects.Sprite(this, this.textures.shadowGradTop, 0, 0);
            this.shadowGradBot = new Kiwi.GameObjects.Sprite(this, this.textures.shadowGradBottom, 0, 956);

            //Panels
            this.middlePanel = new Kiwi.GameObjects.Sprite(this, this.textures.middlePanel, 0, 286);

            // this.addChild(this.middlePanel);
            this.topPanel = new Kiwi.GameObjects.Sprite(this, this.textures.topPanel, 0, -63);
            this.bottomPanel = new Kiwi.GameObjects.Sprite(this, this.textures.bottomPanel, 0, 485);

            //Main Buttons
            this.backButton = new Kiwi.GameObjects.Sprite(this, this.textures.backButton, 205, 408);
            this.loginButton = new Kiwi.GameObjects.Sprite(this, this.textures.loginButton, 205, 309);
            this.signUpButton = new Kiwi.GameObjects.Sprite(this, this.textures.signUpButton, 205, 606);
            this.guestButton = new Kiwi.GameObjects.Sprite(this, this.textures.guestButton, 205, 509);

            this.addChild(this.backButton);
            this.addChild(this.loginButton);
            this.addChild(this.signUpButton);
            this.addChild(this.guestButton);

            this.game.audio.stopAll();

            // Panel Tweens
            //Close
            this.panelTopClose = this.game.tweens.create(this.topPanel);
            this.panelBottomClose = this.game.tweens.create(this.bottomPanel);
            this.panelTopClose.to({ y: -63 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomClose.to({ y: 485 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelTopClose.onComplete(this.openPanels, this);

            //Open
            this.panelTopOpen = this.game.tweens.create(this.topPanel);
            this.panelBottomOpen = this.game.tweens.create(this.bottomPanel);
            this.panelTopOpen.to({ y: -501 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomOpen.to({ y: 923 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);

            this.backButton.input.onUp.add(this.backButtonHit, this);
            this.signUpButton.input.onUp.add(this.signUpButtonHit, this);
            this.loginButton.input.onUp.add(this.loginButtonHit, this);
            this.guestButton.input.onUp.add(this.guestButtonHit, this);

            this.standoffTitle.alpha = 0;

            //Layering panels
            this.addChild(this.bottomPanel);
            this.addChild(this.topPanel);

            this.addChild(this.shadowGradBot);
            this.addChild(this.shadowGradTop);

            this.openPanels();
        };

        AccountSetup.prototype.update = function () {
            _super.prototype.update.call(this);
        };

        AccountSetup.prototype.openPanels = function () {
            this.panelTopOpen.start();
            this.panelBottomOpen.start();
        };
        AccountSetup.prototype.closePanels = function () {
            this.panelTopClose.start();
            this.panelBottomClose.start();
        };
        AccountSetup.prototype.backButtonHit = function () {
            if (this.panelTopClose.isRunning || this.panelTopOpen.isRunning)
                return;
            this.panelTopClose.onComplete(this.backButtonStart, this);
            this.closePanels();
        };
        AccountSetup.prototype.backButtonStart = function () {
            this.game.states.switchState('MainMenu', MyStates.MainMenu, null);
        };

        AccountSetup.prototype.signUpButtonHit = function () {
            //this.game.states.switchState('Loader', MyStates.Loader, null, { players: 2, level: 1, colour1: 1, colour2: 2, support: [5, 5, 10, 5, 5, 10] });
        };

        AccountSetup.prototype.loginButtonHit = function () {
            // this.game.states.switchState('Loader', MyStates.Loader, null, { players: 2, level: 1, colour1: 1, colour2: 2, support: [5, 5, 10, 5, 5, 10] });
            //this.game.states.switchState('Play', MyStates.Play, null, { players: 2, level: 1, colour1: 1, colour2: 2, support: [5, 5, 10, 5, 5, 10] });
        };

        AccountSetup.prototype.guestButtonHit = function () {
            if (this.panelTopClose.isRunning || this.panelTopOpen.isRunning)
                return;
            this.panelTopClose.onComplete(this.guestButtonStart, this);
            this.closePanels(); //this.game.states.switchState('Play', MyStates.Play, null, { players: 2, level: 1, colour1: 1, colour2: 2, support: [5, 5, 10, 5, 5, 10] });
        };
        AccountSetup.prototype.guestButtonStart = function () {
            this.game.side1Colour = 1;
            this.game.side2Colour = 2;

            this.game.states.switchState('Loader', MyStates.Loader, null, { players: 1, level: 1, colour1: 0, colour2: 1, support: [5, 5, 10, 5, 5, 10] });
        };

        AccountSetup.prototype.loadMap = function () {
            this.game.states.switchState('Play', MyStates.Play, null, { players: this.players, level: 1, colour1: this.colour1, colour2: this.colour2, support: this.support });
        };
        return AccountSetup;
    })(Kiwi.State);
    MyStates.AccountSetup = AccountSetup;
})(MyStates || (MyStates = {}));
var MyStates;
(function (MyStates) {
    var Play = (function (_super) {
        __extends(Play, _super);
        function Play() {
            _super.call(this, 'Play');
            //call in shizzi
            this.callIn_1_x = 0;
            this.callIn_1_y = 0;
            //bomb end
            this.bomb_1_x = 0;
            this.bomb_1_y = 0;
            this.bomb_2_x = 0;
            this.bomb_2_y = 0;
            //currently selected
            this.callIn_1_var = -1;
            this.callIn_2_x = 0;
            this.callIn_2_y = 0;
            this.callIn_2_var = -1;
            this.callIn_1_count = -1;
            this.callIn_2_count = -1;
            this.cannonTime1 = 0;
            this.cannonTime2 = 0;
            this.lockedSoldiers = false;
            this.lockedVehicles = false;
            this.lockedRifleman = false;
            this.lockedBazooka = false;
            this.lockedFlamer = false;
            this.lockedTank = false;
            this.lockedSniper = false;
            this.lockedAPC = false;
            this.gameOver = false;
            this.pauseKeyPressed = false;
            this.halfTile = 25;
            this.nextBubble = 0;
            this.mw = 0;
            this.mh = 0;
            this.halfway = 512;
            this.finger1 = null;
            this.finger2 = null;
            this.finger1Down = false;
            this.finger2Down = false;
            this.updateTouchUp = null;
            this.updateTouchDown = null;
            this.players = 2;
            this.level = 0;
            this.clickTarget1 = '';
            this.clickTarget2 = '';
            this.mouseStartX1 = 0;
            this.mouseStartY1 = 0;
            this.mouseStartX2 = 0;
            this.mouseStartY2 = 0;
            this.dragVar1 = 0;
            this.dragVar2 = 0;
            this.bubbleVar = 0;
            this.trigCount = 64;
            this.colour1 = 1;
            this.colour2 = 2;
            this.support = [];
            this.tutorialOn = false;
            //update ticker
            this.tickVar = 0;
            this.tickDelay = 1;
            this.p1Credits = -1;
            this.p2Credits = -1;
            this.p1TickCredits = 0;
            this.p2TickCredits = 0;
            this.p1Tokens0 = -1;
            this.p1Tokens1 = -1;
            this.p1Tokens2 = -1;
            this.p2Tokens0 = -1;
            this.p2Tokens1 = -1;
            this.p2Tokens2 = -1;
            this.waitingWave = false;
            this.callinsActive = true;
            this.GAME_ACTIVE = true;
            this.paused = false;
            this.startTime = 0;
            this.pauseTime = 0;
            this.tickStart = 0;
            this.retractTime1 = 0;
            this.retractTime2 = 0;
            this.elapsedTime = 0;
            this.callInsStarted = false;
            Managers.ActionManager.play = this;
        }
        //BUILD
        Play.prototype.create = function (players, level, colour1, colour2, support, tutorialOn) {
            if (typeof tutorialOn === "undefined") { tutorialOn = false; }
            _super.prototype.create.call(this);

            //this.game.audio.stopAll();
            this.players = players;
            this.gameOver = false;

            //level = 6;
            this.creditsEarned = 0;

            //menu selected variables
            this.p1Tokens0 = support[0];
            this.p1Tokens1 = support[1];
            this.p1Tokens2 = support[2];
            this.p2Tokens0 = support[3];
            this.p2Tokens1 = support[4];
            this.p2Tokens2 = support[5];
            this.colour1 = colour1;
            this.colour2 = colour2;
            this.support = support;

            this.clickTarget1 = '';
            this.clickTarget2 = '';
            this.propArray = [];
            this.callIns = [];
            this.actionData = [];
            this.clickables1 = [];
            this.clickables2 = [];
            this.soldiers1 = [];
            this.soldiers2 = [];
            this.vehicles1 = [];
            this.vehicles2 = [];
            this.movingContent = [];
            this.bullets = [];
            this.crates = [];
            this.bubbles = [];

            this.mapData = [];
            this.deathArray = [];
            this.removeArray = [];

            this.players = players;

            //level == the map selceted therefore + 1 because phil did not start at 0
            this.level = level + 1;
            this.tutorialOn = tutorialOn;

            this.propArray.length = 0;
            this.actionData.length = 0;
            this.lockedSoldiers = false;
            this.lockedVehicles = false;
            this.lockedRifleman = false;
            this.lockedBazooka = false;
            this.lockedFlamer = false;
            this.lockedTank = false;
            this.lockedSniper = false;
            this.lockedAPC = false;
            this.callInsStarted = false;
            this.callIn_1_var = -1;
            this.callIn_2_var = -1;

            this.playTimer = this.game.time.clock;
            this.startTime = this.tickStart = this.retractTime1 = this.retractTime2 = this.game.time.now();

            this.GAME_ACTIVE = true;
            try  {
                //management
                this.parameters = new StandOff.Parameters();
                this.actionManager = new Managers.ActionManager();

                //grouping
                this.background = new Kiwi.GameObjects.Sprite(this, this.textures['background' + (this.game.mapSelected + 1)], 0, 0);

                //this.background.transform.rotPointX = this.background.transform.rotPointY = 0;
                //this.background.transform.scaleX = this.background.transform.scaleY = 0.5;
                this.addChild(this.background);
                this.tileGroup = new Kiwi.Group(this);
                this.addChild(this.tileGroup);

                //call to place down hex/warning first
                this.UIManager = new Managers.UIManager(this);
                this.vehicles = new Kiwi.Group(this);
                this.units = new Kiwi.Group(this);
                this.tanks = new Kiwi.Group(this);
                this.vehicleDeaths = new Kiwi.Group(this);
                this.infantryDeaths = new Kiwi.Group(this);
                this.nodeButtons = new Kiwi.Group(this);
                this.consoleButtons = new Kiwi.Group(this);

                if (this.players == 1) {
                    var l = new Levels['Level' + this.level](this.actionData);
                    this.level = l.myLevelData[0][0];
                    this.colour2 = l.myLevelData[0][1];
                    this.actionData = l.myLevelData[1];
                    this.actionManager.doAction();
                }

                this.addChild(this.vehicles);
                this.addChild(this.units);
                this.addChild(this.tanks);
                this.addChild(this.vehicleDeaths);
                this.addChild(this.infantryDeaths);
                this.addChild(this.nodeButtons);
                this.addChild(this.consoleButtons);

                this.startEvents();

                this.paused = false;

                this.initializeWorld();

                this.sinArr = [];
                this.cosArr = [];
                for (var i = 0; i < this.trigCount; i++) {
                    var ang = i * ((Math.PI * 2) / this.trigCount);
                    this.sinArr.push(Math.sin(ang));
                    this.cosArr.push(Math.cos(ang));
                }
                //this.pauseKey = this.game.input.keyboard.addKey(Kiwi.Input.Keycodes.X);
            } catch (e) {
                this.GAME_ACTIVE = false;
                this.sendMessage('zachary.freiberg@gmail.com', e);
            }
        };

        Play.prototype.initializeWorld = function () {
            var m = new Maps['Map' + this.level](this.mapData);
            this.mapData = m.myMapData;
            this.generateTerrain();

            this.statManager = new Managers.StatManager();

            this.cannonManager = new Managers.CannonManager(this, this.game);
            this.UIManager.createUI();
            this.callInManager = new Managers.CallInManager(this);
            this.unitManager = new Managers.UnitManager(this);
            this.audioManager = new Managers.AudioManager(this);

            this.effects1 = new Kiwi.Group(this);
            this.addChild(this.effects1);
            this.effects2 = new Kiwi.Group(this);
            this.addChild(this.effects2);

            this.audioManager.init();

            // var a = Pnc.ActionManager.getAction('initLevel' + this.sceneNumber);
            //if (a !== -1) Pnc.ActionManager.doAction(a);
            if (!this.parameters.CHEATING)
                this.setCountdown();
        };

        Play.prototype.setCountdown = function () {
            this.countdownBase1 = new Kiwi.GameObjects.StaticImage(this, this.textures.countdownBase, 81, 611);
            this.addChild(this.countdownBase1);

            this.countdownEngage1 = new Kiwi.GameObjects.StaticImage(this, this.textures.countdownEngage, 104, 631);
            this.addChild(this.countdownEngage1);
            this.countdownEngage1.visible = false;

            this.messageMurk = new Kiwi.GameObjects.Sprite(this, this.textures.messagePanel, 18, 521);
            this.messageMurk.animation.switchTo(this.colour1 - 1);
            this.messageMurk.visible = false;
            this.addChild(this.messageMurk);

            //font size for message TF
            var tempFontSize = 24;
            this.messageText1 = new Kiwi.GameObjects.Textfield(this, "TEST STRING TEST STRING TWO", 315, 545, '#ffffff', tempFontSize, 'normal', 'playFont');
            this.messageText1.visible = false;
            this.addChild(this.messageText1);

            this.messageText2 = new Kiwi.GameObjects.Textfield(this, "TEST STRING TEST STRING TWO", 315, 565, '#ffffff', tempFontSize, 'normal', 'playFont');
            this.messageText2.visible = false;
            this.addChild(this.messageText2);

            this.messageText3 = new Kiwi.GameObjects.Textfield(this, "TEST STRING TEST STRING TWO", 315, 585, '#ffffff', tempFontSize, 'normal', 'playFont');
            this.messageText3.visible = false;
            this.addChild(this.messageText3);

            this.messageText4 = new Kiwi.GameObjects.Textfield(this, "TEST STRING TEST STRING TWO", 315, 605, '#ffffff', tempFontSize, 'normal', 'playFont');
            this.messageText4.visible = false;
            this.addChild(this.messageText4);

            this.messageText5 = new Kiwi.GameObjects.Textfield(this, "TEST STRING TEST STRING TWO", 315, 625, '#ffffff', tempFontSize, 'normal', 'playFont');
            this.messageText5.visible = false;
            this.addChild(this.messageText5);

            this.countdownText1 = new Kiwi.GameObjects.StaticImage(this, this.textures.countdownText, 44, 542);
            this.addChild(this.countdownText1);

            this.countdown1 = new Kiwi.GameObjects.Sprite(this, this.textures.countdown, 368, 648);
            this.addChild(this.countdown1);

            this.countdown1.animation.add('count', [0, 1, 2, 3, 4, 4, 4], 1, true, true);
            this.countdown1.animation.play('count');

            if (this.players == 2) {
                this.countdownBase2 = new Kiwi.GameObjects.StaticImage(this, this.textures.countdownBase, 80, 310);
                this.countdownBase2.rotation = Math.PI;
                this.addChild(this.countdownBase2);

                this.countdownEngage2 = new Kiwi.GameObjects.StaticImage(this, this.textures.countdownEngage, 103, 343);
                this.countdownEngage2.rotation = Math.PI;
                this.addChild(this.countdownEngage2);
                this.countdownEngage2.visible = false;

                this.countdownText2 = new Kiwi.GameObjects.StaticImage(this, this.textures.countdownText, 44, 206);
                this.countdownText2.rotation = Math.PI;
                this.addChild(this.countdownText2);

                this.countdown2 = new Kiwi.GameObjects.Sprite(this, this.textures.countdown, 364, 348);
                this.countdown2.rotation = Math.PI;
                this.addChild(this.countdown2);
                this.countdown2.animation.add('count', [0, 1, 2, 3, 4, 4, 4], 1, true, true);
                this.countdown2.animation.play('count');
            }
            this.GAME_ACTIVE = false;
        };

        Play.prototype.removeCountdown = function () {
            this.countdownBase1.destroy();
            this.countdownEngage1.destroy();
            this.countdownText1.destroy();
            if (this.players == 2) {
                this.countdownBase2.destroy();
                this.countdownEngage2.destroy();
                this.countdownText2.destroy();
            }
        };

        Play.prototype.writeMessage = function (message, timeToRemove) {
            if (typeof timeToRemove === "undefined") { timeToRemove = 5; }
            this.messageMurk.visible = true;
            var words = message.split(" ");

            //wordTF array is the array the string that will go into the textfield will be stored.
            var wordTF = ["", "", "", "", ""];
            var activeTextfield = 0;

            //Character limit per line (changeable because we are not using a monospace font.
            var charLimit = 30;
            for (var i = 0; i < words.length; i++) {
                if (words[i] == "@") {
                    activeTextfield++;
                } else {
                    if (wordTF[activeTextfield].length + words[i].length <= charLimit) {
                        wordTF[activeTextfield] = wordTF[activeTextfield] + " " + words[i];
                    } else {
                        wordTF[activeTextfield + 1] = wordTF[activeTextfield + 1] + " " + words[i];
                        activeTextfield++;
                    }
                }
            }
            this.messageText1.text = wordTF[0];
            this.messageText2.text = wordTF[1];
            this.messageText3.text = wordTF[2];
            this.messageText4.text = wordTF[3];
            this.messageText5.text = wordTF[4];

            this.messageText1.visible = true;
            this.messageText2.visible = true;
            this.messageText3.visible = true;
            this.messageText4.visible = true;
            this.messageText5.visible = true;

            var timer = this.game.time.clock.createTimer('text', timeToRemove, 0, false);
            timer.createTimerEvent(Kiwi.Time.TimerEvent.TIMER_STOP, this.removeMessage, this);

            timer.start();
        };

        Play.prototype.removeMessage = function () {
            this.messageMurk.visible = false;
            this.messageText1.visible = false;
            this.messageText2.visible = false;
            this.messageText3.visible = false;
            this.messageText4.visible = false;
            this.messageText5.visible = false;
        };

        Play.prototype.processImage = function (img, offset) {
            /*if (img == undefined) {
            console.log('no image to process');
            return;
            }
            if(this.parameters.SCALE_IMG) img.scaleX = img.scaleY = 0.5;*/
            if (this.parameters.OFFSET_IMG && offset) {
                img.x -= img.width / 4;
                img.y -= img.height / 4;
            }
        };

        Play.prototype.processVar = function (num) {
            return num * 0.5;
            return num;
        };

        Play.prototype.unprocessVar = function (num) {
            if (this.parameters.SCALE_IMG)
                return num * 2;
            return num;
        };

        Play.prototype.generateTerrain = function () {
            this.mw = this.mapData[0].length;
            this.mh = this.mapData.length;

            for (var i = 0; i < this.mh; i++) {
                for (var j = 0; j < this.mw; j++) {
                    var myVar = this.mapData[i][j];
                    if (myVar !== 0) {
                        var t = new Tiles['Tile' + myVar](this, this.textures['tile' + myVar], j, i, myVar);
                        t.name = 't' + i + '_' + j;

                        //t.visible = false;
                        this.tileGroup.addChild(t);
                        switch (myVar) {
                            case 2:
                                //slow
                                t.visible = false;
                                var bubble = new Kiwi.GameObjects.Sprite(this, this.textures.mudBubble, t.x, t.y);
                                bubble.animation.add('pop', [0, 1, 2, 3, 4, 5, 6, 6], 0.1, false, false);
                                bubble.visible = false;
                                this.tileGroup.addChild(bubble);
                                this.bubbles.push(bubble);
                                break;
                            case 3:
                                //lava
                                t.animation.add('glow', [0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 1], 0.4, true, true);
                                t.animation.switchTo('glow');
                                t.visible = false; // Make this true to see lava glow again
                                var bubble = new Kiwi.GameObjects.Sprite(this, this.textures.lavaBubble, t.x, t.y);
                                bubble.animation.add('pop1', [0, 1, 2, 3, 4, 5, 6, 6], 0.1, false, false);
                                bubble.animation.add('pop2', [7, 8, 9, 10, 11, 12, 13, 13], 0.1, false, false);
                                bubble.animation.add('pop3', [14, 15, 16, 17, 18, 19, 20, 20], 0.1, false, false);
                                bubble.visible = false;
                                this.tileGroup.addChild(bubble);
                                this.bubbles.push(bubble);
                                break;
                            default:
                                t.visible = false;
                                break;
                        }
                    }
                }
            }
            //console.log('Terrain Complete');
        };

        Play.prototype.addProp = function (img, x, y) {
            var p = new Kiwi.GameObjects.StaticImage(this, this.textures[img]);

            //this.processImage(p,true);
            p.x = x;
            p.y = y;
            this.addChild(p);
            this.propArray.push(p);
        };

        Play.prototype.removeProps = function () {
            for (var i = this.propArray.length - 1; i <= 0; i--) {
                var p = this.propArray[i];
                this.removeChild(p);
            }
            this.propArray = [];
        };

        Play.prototype.startCallIns = function () {
            console.log('start call ins!', this.callinsActive);
            if (this.callinsActive) {
                this.callInsStarted = true;

                //white blink is 0/2
                //this.supportButton1.animation.add('blink', [0, 2], 0.5, true, true);
                //this.supportButton2.animation.add('blink', [0, 2], 0.5, true, true);
                //this.supportButton1.animation.switchTo('blink');
                //this.supportButton2.animation.switchTo('blink');
                this.supportText1.animation.switchTo('default');
                this.supportText1.animation.switchTo(4);
                this.supportText2.animation.switchTo('default');
                this.supportText2.animation.switchTo(4);

                if (this['p' + 1 + 'Tokens0'] == 0 && this['p' + 1 + 'Tokens1'] == 0 && this['p' + 1 + 'Tokens2'] == 0) {
                    this.supportText1.animation.switchTo(5);
                } else {
                    this.supportButton1.animation.switchTo('blink');
                    this.supportButton1.animation.add('blink', [0, 2], 0.5, true, true);
                }

                if (this['p' + 2 + 'Tokens0'] == 0 && this['p' + 2 + 'Tokens1'] == 0 && this['p' + 2 + 'Tokens2'] == 0) {
                    this.supportText2.animation.switchTo(5);
                } else {
                    this.supportButton2.animation.switchTo('blink');
                    this.supportButton2.animation.add('blink', [0, 2], 0.5, true, true);
                }
                //this.showCallIns(1);
                //this.showCallIns(2);
            }
        };

        Play.prototype.returnClosestByY = function (side) {
            //return closest by y
            var cy = 3000;
            var char = -1;
            if (side == 1) {
                for (var i = 0; i < this.soldiers1.length; i++) {
                    var s = this.soldiers1[i];
                    if (s.y < cy) {
                        char = s;
                        cy = s.y;
                    }
                }
                for (var i = 0; i < this.vehicles1.length; i++) {
                    var s = this.vehicles1[i];
                    if (s.y < cy) {
                        char = s;
                        cy = s.y;
                    }
                }
            } else {
                cy = 0;
                for (var i = 0; i < this.soldiers2.length; i++) {
                    var s = this.soldiers2[i];
                    if (s.y > cy) {
                        char = cy;
                        cy = s.y;
                    }
                }
                for (var i = 0; i < this.vehicles2.length; i++) {
                    var s = this.vehicles2[i];
                    if (s.y > cy) {
                        char = cy;
                        cy = s.y;
                    }
                }
            }
            return char;
        };

        Play.prototype.checkClickablesPressed = function (pointer) {
            //catch what side, and which clickable is pressed
            var my = pointer.y;
            if (my > this.halfway) {
                for (var i = 0; i < this.clickables1.length; i++) {
                    var c = this.clickables1[i];
                    if (c.isDown) {
                        this.clickTarget1 = c;
                    }
                }
            } else {
                for (var i = 0; i < this.clickables2.length; i++) {
                    var c = this.clickables2[i];
                    if (c.isDown) {
                        this.clickTarget2 = c;
                    }
                }
            }
        };

        ///             --------------- TOUCH INTERGRATION
        Play.prototype.initClickTarget = function (num) {
            var t = this['clickTarget' + num];
            if (t == null || t == undefined) {
                return;
            }
            this['dragVar' + num] = 0;

            this['mouseStartX' + num] = (t.x);
            this['mouseStartY' + num] = (t.y);

            if (t.clickType == 'buildNodeBase') {
                var buildNodeBase = this['clickTarget' + num];
                t = this['node' + buildNodeBase.side + '_' + buildNodeBase.pos];

                this['mouseStartX' + num] = t.returnX();
                this['mouseStartY' + num] = t.returnY();
            }
        };

        Play.prototype.updateBullets = function () {
            for (var i = this.bullets.length - 1; i >= 0; i--) {
                var bullet = this.bullets[i];
                switch (bullet.type) {
                    case 'machineGun':
                        bullet.x -= bullet.xVelocity;
                        bullet.y += bullet.yVelocity;

                        //max remove
                        //check collisions
                        if (bullet.side == 1) {
                            if (bullet.y < 300) {
                                this.bullets.splice(i, 1);
                                bullet.exists = false;
                                bullet.destroy();
                            } else if (this.checkBullet(bullet, 2)) {
                                this.bullets.splice(i, 1);
                                bullet.exists = false;
                                bullet.destroy();
                                this.audioManager.playSFX(this.explosionSmallSFX);
                            }
                        } else {
                            if (bullet.y > 684) {
                                this.bullets.splice(i, 1);
                                bullet.exists = false;
                                bullet.destroy();
                            } else if (this.checkBullet(bullet, 1)) {
                                this.bullets.splice(i, 1);
                                bullet.exists = false;
                                bullet.destroy();
                                this.audioManager.playSFX(this.explosionSmallSFX);
                            }
                        }
                        break;
                    default:
                        bullet.count--;
                        if (bullet.count <= 0) {
                            if (bullet.type == 'shell') {
                                this.explodeShell(bullet);
                            } else if (bullet.type == 'flare') {
                                //flare
                                this.setFlare(bullet);
                            } else {
                                this.unitManager.explodeBazooka(bullet);
                            }
                            this.bullets.splice(i, 1);
                            bullet.exists = false;
                            bullet.destroy();
                        } else {
                            bullet.x += bullet.xVelocity;
                            bullet.y -= bullet.yVelocity;
                        }
                        break;
                }
            }
        };

        Play.prototype.explodeShell = function (bullet) {
            var x = bullet.returnX();
            var y = bullet.returnY();
            var side = bullet.side;
            var bombEffect = new StandOffEntities.effect(this, this.textures['effects' + this['colour' + side]], 0, x - 125, y - 125);
            bombEffect.animation.play('cannonSHImpact');
            this['effects' + side].addChild(bombEffect);
            var oppSide = this.getOppSide(side);
            this.audioManager.playSFX(this.explosionBigSFX);
            var arr = this.getSideWithinRadius(x, y, oppSide, 125);
            for (var i = 0; i < arr.length; i++) {
                var char = arr[i];
                this.unitManager.hurtChar(char, bullet[char.constructor.name + 'Splash']);
            }
        };

        Play.prototype.checkBullet = function (bullet, oppSide) {
            var soldiers = this['soldiers' + oppSide];
            var vehiclesCollide = this['vehicles' + oppSide];

            for (var i = soldiers.length - 1; i >= 0; i--) {
                var e = soldiers[i];
                if (this.checkBulletCollide(bullet, e)) {
                    this.unitManager.hurtChar(e, bullet[e.constructor.name + 'Att']);
                    return true;
                }
            }
            for (var j = vehiclesCollide.length - 1; j >= 0; j--) {
                var e = vehiclesCollide[j];
                if (this.checkBulletCollide(bullet, e)) {
                    this.unitManager.hurtChar(e, bullet[e.constructor.name + 'Att']);
                    return true;
                }
            }
            return false;
        };

        Play.prototype.checkBulletCollide = function (b, e) {
            var dist = e.hitWidth;
            var ex = e.returnX();
            var ey = e.returnY();
            var bx = b.returnX();
            var by = b.returnY();
            if (bx > ex - dist) {
                if (bx < ex + dist) {
                    if (by > ey - dist) {
                        if (by < ey + dist) {
                            if (e.visible)
                                return true;
                        }
                    }
                }
            }
            return false;
        };

        Play.prototype.setFlare = function (bullet) {
            //check prev one
            var prev = this['effects' + bullet.side].getChildByName('flare' + bullet.side);
            if (prev != undefined) {
                prev.exists = false;
                prev.destroy();
            }
            var f = new StandOffEntities.flare(this, this.textures['effects' + this['colour' + bullet.side]], bullet.x - 64, bullet.y - 64);

            //this.processImage(this['flare' + bullet.side], true);
            f.animation.play('cannonTFImpact');
            f.name = 'flare' + bullet.side;
            f.side = bullet.side;
            this['effects' + bullet.side].addChild(f);

            this['flare' + bullet.side] = f;
            f.animation.play();
        };

        Play.prototype.withinOpponentHalf = function (t) {
            //note: halfway is re-calculated at the start ofthe game
            //console.log(t.side, t.y, this.HALFWAY);
            if (t.side == 1) {
                if (t.y < this.parameters.HALFWAY) {
                    return true;
                }
            } else {
                if (t.y > this.parameters.HALFWAY) {
                    return true;
                }
            }
            return false;
        };
        Play.prototype.startTutorial = function () {
            this.tutorial = new StandOffEntities.tutorial(this, this.colour1);
            this.addChild(this.tutorial);
        };

        //drag arrow create/update here
        Play.prototype.updateArrow = function (num, device) {
            //move aim arrow about
            var mx = device.x;
            var my = device.y;

            if ((num == 1 && my < this.parameters.HALFWAY) || (num == 2 && my > this.parameters.HALFWAY)) {
                this.releaseArrow(num);
                return;
            }

            var line = new Kiwi.Geom.Line(this['mouseStartX' + num], this['mouseStartY' + num], mx, my);
            var lineCheck = this.checkLine(num, device);

            if (lineCheck) {
                var supportDown = false;
                for (var i = 2; i >= 0; i--) {
                    if (this["callIn_" + num + "_" + i].animation.frameIndex == 1) {
                        supportDown = true;
                    }
                }

                if (!supportDown) {
                    if (this['arrow' + num] == null) {
                        this.generateArrow(num);
                    } else if (this['arrow' + num].parent == null) {
                        this['arrow' + num].destroy();
                        this.generateArrow(num);
                    } else {
                        this.updateStretchArrow(num, device);
                    }
                }
            } else {
                this.releaseArrow(num);
            }
            /*if (this['arrow' + num] != null) {
            this.removeChild(this['arrow' + num]);
            if (this['arrow' + num].parent != null) {
            this['arrow' + num].destroy();
            }
            }*/
        };

        Play.prototype.releaseArrow = function (num) {
            var curr = this['clickTarget' + num];
            var buildNode = this['node' + curr.side + '_' + curr.pos];
            if (this['arrow' + curr.side] != null) {
                if (this['arrow' + curr.side].parent != null) {
                    //console.log('ARROW:', this['arrow' + curr.side].animation.currentAnimation.frameIndex)
                    //release soldier and remove arrow
                    if (buildNode.ready && this['arrow' + curr.side].animation.currentAnimation.frameIndex) {
                        if (this['arrow' + curr.side].rotation == 0 && curr.side == 1) {
                            //just catch the error for a fast arrow w/ 0 rotation
                        } else {
                            this.UIManager.releaseNode(buildNode);
                        }
                    }
                    this['clickTarget' + num] = '';
                    this.removeChild(this['arrow' + curr.side]);
                }
                this['arrow' + curr.side] = null;
            }
        };

        ///             --------------- TOUCH INTERGRATION
        Play.prototype.checkLine = function (num, device) {
            var mx = device.x;
            var my = device.y;

            var line = new Kiwi.Geom.Line(this['mouseStartX' + num], this['mouseStartY' + num], mx, my);

            //if (line.length < this.processVar(100)) return false;
            var rads = line.angle;
            if (rads < 0)
                rads += Math.PI * 2;
            if (num == 1) {
                if (this['mouseStartY' + num] < my) {
                    return false;
                }
                if (rads < Math.PI / 2 + this.parameters.RANGE) {
                    return false;
                }
                if (rads > Math.PI * 1.5 - this.parameters.RANGE) {
                    return false;
                }
            } else {
                if (this['mouseStartY' + num] > my)
                    return false;
                if (rads > Math.PI / 2 - this.parameters.RANGE && rads < Math.PI * 1.5 + this.parameters.RANGE) {
                    return false;
                }
            }
            return true;
        };

        Play.prototype.generateArrow = function (num) {
            var buildNodeBase = this['clickTarget' + num];
            var t = this['node' + buildNodeBase.side + '_' + buildNodeBase.pos];

            //this['arrow' + num] = new Kiwi.GameObjects.Sprite(this, this.textures['fbArrow_' + this['colour' + num]], t.returnX() - 46, t.returnY() - 210);
            this['arrow' + num] = new Kiwi.GameObjects.Sprite(this, this.textures['nodeButtons' + this['colour' + num]], t.returnX() - 46, t.returnY() - 210);
            var arrow = this['arrow' + num];
            arrow.animation.switchTo('fbArrow');
            t.arrowing = true;
            if (num == 2) {
                arrow.y += 10;
            }
            arrow.transform.rotPointX = arrow.box.bounds.width / 2;
            arrow.transform.rotPointY = 203;
            if (buildNodeBase.side == 2) {
                arrow.transform.rotation = Math.PI;
            }
            this.addChild(arrow);
            this.audioManager.playSFX(this.readyClickSFX);
        };

        Play.prototype.updateStretchArrow = function (num, device) {
            //move aim arrow about, and also stretch arrow
            if (this['arrow' + num] == null || this['arrow' + num] == undefined) {
                return;
            }
            if (this['arrow' + num].transform == undefined) {
                return;
            }
            var mx = device.x;
            var my = device.y;
            var line = new Kiwi.Geom.Line(this['mouseStartX' + num], this['mouseStartY' + num], mx, my);
            var f = Math.floor(line.length / this.parameters.STRETCH_STEP);
            if (f > 4)
                f = 4;
            this['arrow' + num].animation.switchTo(f);
            this['arrow' + num].rotation = Math.PI - line.angle;
        };

        //release
        Play.prototype.releaseResponse = function (pointer) {
            //check y position of release
            var currSide = 1;
            if (pointer.y < this.halfway)
                currSide = 2;
            if (currSide > this.players)
                return;

            var curr = this['clickTarget' + currSide];
            if (curr === undefined)
                return;

            if (this.paused) {
                if (curr.clickType == 'pauseButton')
                    this.pauseGame(currSide);
                return;
            }

            var myType = curr.clickType;
            if ((myType == 'callInButton' || myType == 'supportButton') && !curr.visible) {
                //myType = 'hiddenCallIn';
                return;
                this['clickTarget' + currSide] = '';
                curr = this['clickTarget' + currSide];
                myType = undefined;
            }

            for (var i = 2; i >= 0; i--) {
                if (this["callIn_" + currSide + "_" + i].animation.frameIndex == 1) {
                    if (myType == 1) {
                        myType = undefined;
                    }
                }
            }

            switch (myType) {
                case 'cannon':
                    this.cannonManager.releaseCannon(currSide);
                    break;
                case 'buildNodeBase':
                    this.UIManager.selectNode(curr);

                    break;
                case 'selectButton':
                    this.UIManager.confirmSelection(curr);
                    break;
                case 'confirmYes':
                    this.UIManager.finishSelection(curr);
                    break;
                case 'selectBarrack':
                    this.UIManager.selectBarrack(curr);
                    break;
                case 'confirmUpgrade':
                    this.UIManager.upgradeNode(curr);
                    break;
                case 'confirmNo':
                    break;
                case 'cannonButton':
                    this.UIManager.selectCannonButton(curr.side, curr.pos);
                    break;
                case 'supportButton':
                    if (this.callInsStarted) {
                        var test = this['callIn_' + curr.side + '_0'];
                        var callInsVisible = true;
                        if (!test.visible)
                            callInsVisible = false;
                        if (callInsVisible) {
                            this.hideCallIns(curr.side, false);
                            this.cancelCallIn(curr.side);
                        } else {
                            this.showCallIns(curr.side);
                        }
                    }
                    break;
                case 'callInButton':
                    var deselectVar = false;
                    var base = this['callIn_' + curr.side + '_' + curr.pos];

                    this['retractTime' + curr.side] = this.game.time.now();

                    //this.deselectPrevCallIn(curr.side);
                    if (this['callIn_' + curr.side + '_var'] != -1) {
                        //if current, deselect
                        if (this['callIn_' + curr.side + '_var'] == curr.pos) {
                            deselectVar = true;
                            this.cancelCallIn(curr.side);
                        } else {
                            //deselect previously selected one
                            var prev = this['callIn_' + curr.side + '_' + (this['callIn_' + curr.side + '_var'])];
                            prev.animation.switchTo(0);
                        }
                    }
                    if (!deselectVar) {
                        //Select specific call in type
                        this['callIn_' + curr.side + '_var'] = curr.pos;
                        base.animation.switchTo(1);
                        this.UIManager.showHex(curr.side, true);
                    }
                    break;
                case 'pauseButton':
                    curr.animation.prevFrame();
                    this.pauseGame(currSide);
                    return;
                default:
                    this.callInDrop(curr, pointer);
                    break;
            }

            if (curr.clickType != 'callInButton') {
                //reset call in var
                var side = curr.side;
                if (curr.clickType == undefined) {
                    side = 1;
                    if (pointer.y < this.halfway) {
                        side = 2;
                    }
                }
                var base = this['callIn_' + side + '_' + this['callIn_' + side + '_var']];
                if (base != undefined)
                    base.animation.switchTo(1);
            }

            //console.log('release response:', this['clickTarget' + currSide])
            this['clickTarget' + currSide].isDown = false;
            this['clickTarget' + currSide].isClicked = false;
            this['clickTarget' + currSide] = '';
        };

        Play.prototype.callInDrop = function (curr, pointer) {
            var side = curr.side;
            if (curr.clickType == undefined) {
                side = 1;
                if (pointer.y < this.halfway) {
                    side = 2;
                }
            }
            if (this['callIn_' + side + '_var'] != -1) {
                switch (this['callIn_' + side + '_var']) {
                    case 0:
                        this.callInManager.heliCall(side, pointer);
                        this.actionManager.receiveCallback('callInUsed');
                        break;
                    case 1:
                        //bombers
                        this.callInManager.releaseChevron(side, pointer.x, pointer.y);
                        this.actionManager.receiveCallback('callInUsed');
                        break;
                    case 2:
                        //heal
                        this.callInManager.healCallIn(side, pointer.x, pointer.y);
                        this.actionManager.receiveCallback('callInUsed');
                        break;
                }
            }
            this.UIManager.showHex(side, false);
        };

        Play.prototype.cancelCallIn = function (side) {
            var base = this['callIn_' + side + '_' + (this['callIn_' + side + '_var'])];
            if (base != undefined)
                base.animation.switchTo(0);
            this['callIn_' + side + '_var'] = -1;
            this['callIn_' + side + '_count'] = -1;

            //remove chevron
            if (this['chevron' + side] != null) {
                if (this['chevron' + side].parent != null) {
                    this.removeChild(this['chevron' + side]);
                }
                this['chevron' + side] = null;
            }
            this.UIManager.showHex(side, false);
        };

        Play.prototype.unpauseGame = function () {
            this.pauseGame(1);
        };

        Play.prototype.pauseGame = function (side) {
            if (this.paused) {
                var pauseDiff = this.game.time.now() - this.pauseTime;
                this.startTime -= pauseDiff;
                this.tickStart -= pauseDiff;
                this.retractTime1 += pauseDiff;
                this.retractTime2 += pauseDiff;

                //draggables
                if (this.arrow1 != null) {
                    if (this.arrow1.parent != null) {
                        this.removeChild(this.arrow1);
                    }
                    this.arrow1 = null;
                }
                if (this.arrow2 != null) {
                    if (this.arrow2.parent != null) {
                        this.removeChild(this.arrow2);
                    }
                    this.arrow2 = null;
                }

                if (this.chevron1 != null) {
                    if (this.chevron1.parent != null) {
                        this.removeChild(this.chevron1);
                    }
                    this.chevron1 = null;
                }
                if (this.chevron2 != null) {
                    if (this.chevron2.parent != null) {
                        this.removeChild(this.chevron2);
                    }
                    this.chevron2 = null;
                }

                this.cannonManager.cancelCannon(1);
                this.cannonManager.cancelCannon(2);

                for (var i = 0; i < 6; i++) {
                    var node = this['node1_' + i];
                    if (node.startTime > 0)
                        node.startTime += pauseDiff;
                }

                for (i = 0; i < this.effects1.members.length; i++) {
                    var e = this.effects1.members[i];
                    e.animation.play();
                }

                for (i = 0; i < this.effects2.members.length; i++) {
                    var e = this.effects2.members[i];
                    e.animation.play();
                }

                for (i = 0; i < this.movingContent.length; i++) {
                    var clip = this.movingContent[i];
                    switch (clip.name) {
                        case 'apc':
                            clip.legs.animation.play();
                            break;
                        case 'sniper':
                            clip.animation.play();
                            break;
                        case 'tank':
                            clip.animation.play();
                            if (clip.moving) {
                                clip.legs.animation.play();
                            }
                            break;
                    }
                }

                this.clickTarget1 = '';
                this.clickTarget2 = '';
                this.updateTouchUp = null;
                this.updateTouchDown = null;
                this.finger1 = null;
                this.finger2 = null;

                this.callInManager.setAnimating(true);

                this.removeChild(this.pauseBG);
                this.pauseResume1.input.onUp.remove(this.pauseGame, this);
                this.pauseResume1.destroy();
                this.pauseResume2.input.onUp.remove(this.pauseGame, this);
                this.pauseResume2.destroy();

                this.pauseQuit1.input.onUp.remove(this.quitGame, this);
                this.pauseQuit1.destroy();

                this.pauseQuit2.input.onUp.remove(this.quitGame, this);
                this.pauseQuit2.destroy();

                this.pauseMusicButton1.input.onDown.remove(this.depress, this);
                this.pauseMusicButton1.input.onUp.remove(this.toggleMusic, this);
                this.pauseMusicButton1.destroy();
                this.pauseMusicButton2.input.onDown.remove(this.depress, this);
                this.pauseMusicButton2.input.onUp.remove(this.toggleMusic, this);
                this.pauseMusicButton2.destroy();

                //
                this.pauseSFXButton1.input.onDown.remove(this.depress, this);
                this.pauseSFXButton1.input.onUp.remove(this.toggleSFX, this);
                this.pauseSFXButton1.destroy();
                this.pauseSFXButton2.input.onDown.remove(this.depress, this);
                this.pauseSFXButton2.input.onUp.remove(this.toggleSFX, this);
                this.pauseSFXButton2.destroy();

                this.paused = false;
            } else {
                this.pauseTime = this.game.time.now();

                if ((this.pauseTime - this['cannonTime' + side]) < 1000) {
                    console.log('recent cannon activity', (this.pauseTime - this['cannonTime' + side]));
                    return;
                }
                this.paused = true;

                this.pauseBG = new Kiwi.GameObjects.StaticImage(this, this.textures.pauseBG);
                this.addChild(this.pauseBG);

                //PLAYER 1
                this.pauseResume1 = new Kiwi.GameObjects.Sprite(this, this.textures.pauseResume, 204, 265);
                this.pauseResume1.transform.rotation = Math.PI;
                this.addChild(this.pauseResume1);
                this.pauseResume1.input.onUp.add(this.unpauseGame, this);

                //
                this.pauseQuit1 = new Kiwi.GameObjects.Sprite(this, this.textures.pauseQuit, 204, 365);
                this.pauseQuit1.transform.rotation = Math.PI;
                this.addChild(this.pauseQuit1);
                this.pauseQuit1.input.onUp.add(this.quitGame, this);

                //
                this.pauseMusicButton1 = new Kiwi.GameObjects.Sprite(this, this.textures.pauseMusicButton, 204, 775);
                this.addChild(this.pauseMusicButton1);
                this.pauseMusicButton1.input.onDown.add(this.depress, this);
                this.pauseMusicButton1.input.onUp.add(this.toggleMusic, this);
                if (!this.parameters.AUDIO_ON)
                    this.pauseMusicButton1.animation.switchTo(2);

                //
                this.pauseSFXButton1 = new Kiwi.GameObjects.Sprite(this, this.textures.pauseSFXButton, 389, 775);
                this.addChild(this.pauseSFXButton1);
                this.pauseSFXButton1.input.onDown.add(this.depress, this);
                this.pauseSFXButton1.input.onUp.add(this.toggleSFX, this);
                if (!this.parameters.SFX_ON)
                    this.pauseSFXButton1.animation.switchTo(2);

                //PLAYER 2
                this.pauseQuit2 = new Kiwi.GameObjects.Sprite(this, this.textures.pauseQuit, 204, 575);
                this.addChild(this.pauseQuit2);
                this.pauseQuit2.input.onUp.add(this.quitGame, this);

                //
                this.pauseResume2 = new Kiwi.GameObjects.Sprite(this, this.textures.pauseResume, 204, 676);
                this.addChild(this.pauseResume2);
                this.pauseResume2.input.onUp.add(this.unpauseGame, this);

                //
                this.pauseMusicButton2 = new Kiwi.GameObjects.Sprite(this, this.textures.pauseMusicButton, 389, 165);
                this.addChild(this.pauseMusicButton2);
                this.pauseMusicButton2.rotation = Math.PI;
                this.pauseMusicButton2.input.onDown.add(this.depress, this);
                this.pauseMusicButton2.input.onUp.add(this.toggleMusic, this);
                if (!this.parameters.AUDIO_ON)
                    this.pauseMusicButton2.animation.switchTo(2);

                //
                this.pauseSFXButton2 = new Kiwi.GameObjects.Sprite(this, this.textures.pauseSFXButton, 204, 165);
                this.addChild(this.pauseSFXButton2);
                this.pauseSFXButton2.rotation = Math.PI;
                this.pauseSFXButton2.input.onDown.add(this.depress, this);
                this.pauseSFXButton2.input.onUp.add(this.toggleSFX, this);
                if (!this.parameters.SFX_ON)
                    this.pauseSFXButton2.animation.switchTo(2);

                for (var i = 0; i < this.effects1.members.length; i++) {
                    var e = this.effects1.members[i];
                    e.animation.stop();
                }
                for (var i = 0; i < this.effects2.members.length; i++) {
                    var e = this.effects2.members[i];
                    e.animation.stop();
                }

                for (i = 0; i < this.movingContent.length; i++) {
                    var clip = this.movingContent[i];
                    switch (clip.name) {
                        case 'apc':
                            clip.legs.animation.stop();
                            break;
                        case 'sniper':
                            clip.animation.stop();
                            break;
                        case 'tank':
                            clip.animation.stop();
                            if (clip.moving) {
                                clip.legs.animation.stop();
                            }
                            break;
                    }
                }

                this.callInManager.setAnimating(false);
            }
        };

        Play.prototype.depress = function (b) {
            console.log('depress:', b);
            b.animation.nextFrame();
        };

        Play.prototype.toggleMusic = function () {
            if (this.parameters.AUDIO_ON) {
                this.pauseMusicButton1.animation.switchTo(2);
                this.pauseMusicButton2.animation.switchTo(2);
                this.parameters.AUDIO_ON = false;
                this.bgSFX.mute = true;
                this.game.muteMusic = true;
            } else {
                this.pauseMusicButton1.animation.switchTo(0);
                this.pauseMusicButton2.animation.switchTo(0);
                this.parameters.AUDIO_ON = true;
                this.bgSFX.mute = false;
                this.game.muteMusic = false;
            }
            this.game.saveManager.add('musicMuted', this.game.muteSFX, true);
        };

        Play.prototype.toggleSFX = function () {
            if (this.parameters.SFX_ON) {
                this.pauseSFXButton1.animation.switchTo(2);
                this.pauseSFXButton2.animation.switchTo(2);
                this.parameters.SFX_ON = false;
                this.game.muteSFX = false;
            } else {
                this.pauseSFXButton1.animation.switchTo(0);
                this.pauseSFXButton2.animation.switchTo(0);
                this.parameters.SFX_ON = true;
                this.game.muteSFX = true;
            }
            this.game.saveManager.add('soundMuted', this.game.muteMusic, true);
        };

        Play.prototype.winGame1 = function () {
            this.winGame(1);
        };

        Play.prototype.winGame2 = function () {
            this.winGame(2);
        };

        Play.prototype.winGame = function (num) {
            if (this.players < 2 && num == 1) {
                return;
            }
            if (this.gameOver) {
                return;
            }
            if (num == 1) {
                this.statManager.updateStat('win', 1, 1);
                this.statManager.updateStat('lose', 1, 2);
            } else {
                this.statManager.updateStat('win', 1, 2);
                this.statManager.updateStat('lose', 1, 1);
            }

            this.game.audio.stopAll();
            this.winOverlay = new Kiwi.GameObjects.Sprite(this, this.textures.winOverlay, 0, 0);
            this.winOverlay.alpha = 0.3;
            this.addChild(this.winOverlay);

            if (this.players < 2 && num == 2) {
                console.log('player', num, 'wins!');
                this.winBase1 = new Kiwi.GameObjects.Sprite(this, this.textures.defeatBG, 48, 328); // 528); //48, 328);
                this.addChild(this.winBase1);
                this.winBase2 = new Kiwi.GameObjects.Sprite(this, this.textures.winDefeat, 225, 520); //550);//520
                this.addChild(this.winBase2);

                this.replayButton1 = new Kiwi.GameObjects.Sprite(this, this.textures.singleWinRematch, 400, 650); //380, 710); //400, 650);  y = 510 (+ 82) x =380

                this.addChild(this.replayButton1);
                this.quitButton1 = new Kiwi.GameObjects.Sprite(this, this.textures.singleWinQuit, 22, 650); //34, 710); //22, 650);

                this.addChild(this.quitButton1);
                this.replayButton1.input.onUp.add(this.replayGame, this);
                this.quitButton1.input.onUp.add(this.quitGame, this);

                this.creditImage = new Kiwi.GameObjects.Sprite(this, this.textures.creditsEarnedImage, 175, 210);
                this.addChild(this.creditImage);

                this.creditText = new Kiwi.GameObjects.Textfield(this, "You earned: ", 460, 253, "#edb61c", 30, 'normal', 'playFont');
                this.creditText.text = " " + this.creditsEarned;
                this.creditText.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_RIGHT;
                this.addChild(this.creditText);

                this.game.commodityManager.increaseCredits(this.creditsEarned);
                return;
            }

            //console.log('player', num, 'wins!');
            if (num == 1) {
                this.winBase1 = new Kiwi.GameObjects.Sprite(this, this.textures.winBG, 48, 532);
                this.addChild(this.winBase1);
                this.winBase1.animation.switchTo((this.colour1 - 1));
                this.winBase2 = new Kiwi.GameObjects.Sprite(this, this.textures.defeatBG, 48, 229);
                this.winBase2.animation.switchTo((this.colour2 - 1));
                this.addChild(this.winBase2);
            } else {
                this.winBase1 = new Kiwi.GameObjects.Sprite(this, this.textures.defeatBG, 48, 532);
                this.winBase1.animation.switchTo((this.colour1 - 1));
                this.addChild(this.winBase1);

                this.winBase2 = new Kiwi.GameObjects.Sprite(this, this.textures.winBG, 48, 229);
                this.winBase2.animation.switchTo((this.colour2 - 1));
                this.addChild(this.winBase2);
            }
            this.winBase1Text = new Kiwi.GameObjects.Sprite(this, this.textures.winDefeat, 100, 500);
            this.winBase1Text.x = this.game.stage.width * 0.5 - this.winBase1Text.width * 0.5;
            this.winBase1Text.y = this.game.stage.height * 0.5 + 40;
            this.winBase2Text = new Kiwi.GameObjects.Sprite(this, this.textures.winDefeat, 100, 300);
            this.winBase2Text.x = this.game.stage.width * 0.5 - this.winBase2Text.width * 0.5;
            this.winBase2Text.y = this.game.stage.height * 0.5 - 90;
            this.winBase2Text.rotation = Math.PI;

            if (num == 1) {
                this.winBase1Text.animation.switchTo((this.colour1 - 1) * 2 + 1);
                this.winBase2Text.animation.switchTo((this.colour2 - 1) * 2);
            } else {
                this.winBase1Text.animation.switchTo((this.colour1 - 1) * 2);
                this.winBase2Text.animation.switchTo((this.colour2 - 1) * 2 + 1);
            }
            ;
            this.addChild(this.winBase1Text);
            this.addChild(this.winBase2Text);

            this.winBase2.transform.rotation = Math.PI;

            //this.addWinButtons();
            var timer = this.game.time.clock.createTimer('addWinButtons', 2, 0, false);
            timer.createTimerEvent(Kiwi.Time.TimerEvent.TIMER_STOP, this.addWinButtons, this);
            timer.start();

            //this.game.states.switchState('MainMenu', MyStates.MainMenu);
            this.gameOver = true;
        };

        Play.prototype.addWinButtons = function () {
            if (!this.game.commodityManager.hasElite) {
                //Fadeout Tween
                this.game.audio.stopAll(); //Stop all sounds!

                CocoonJS.Ad.preloadFullScreen();
                CocoonJS.Ad.showFullScreen();
            }

            this.replayButton1 = new Kiwi.GameObjects.Sprite(this, this.textures.winRematch, 160, 708);
            this.addChild(this.replayButton1);
            this.quitButton1 = new Kiwi.GameObjects.Sprite(this, this.textures.winQuit, 395, 708);
            this.addChild(this.quitButton1);

            this.replayButton2 = new Kiwi.GameObjects.Sprite(this, this.textures.winRematch, 388, 266);
            this.addChild(this.replayButton2);
            this.replayButton2.rotation = Math.PI;
            this.quitButton2 = new Kiwi.GameObjects.Sprite(this, this.textures.winQuit, 153, 266);
            this.addChild(this.quitButton2);
            this.quitButton2.rotation = Math.PI;

            this.replayButton1.input.onUp.add(this.replayGame, this);
            this.replayButton2.input.onUp.add(this.replayGame, this);

            this.quitButton1.input.onUp.add(this.quitGame, this);
            this.quitButton2.input.onUp.add(this.quitGame, this);

            /**
            * LEADERBOARD / STATS HERE
            */
            this.game.gameDataManager.postStats(this.statManager.playerMain.getAll(), this.statManager.playerSecondary.getAll());
        };

        Play.prototype.replayGame = function () {
            this.game.states.switchState('Replay', MyStates.Replay, null, { players: this.players, level: this.game.mapSelected, colour1: this.colour1, colour2: this.colour2, support: this.support });
            //this.game.states.switchState('Replay', MyStates.Replay);
        };

        Play.prototype.quitGame = function () {
            this.game.tweens.removeAll();
            this.game.states.switchState('MenuLoader', MyStates.MenuLoader);
        };

        //CALL IN BUTTONS
        ///             --------------- TOUCH INTERGRATION
        Play.prototype.showCallIns = function (side) {
            if (this['p' + side + 'Tokens0'] == 0 && this['p' + side + 'Tokens1'] == 0 && this['p' + side + 'Tokens2'] == 0)
                return;

            //this.supportBase1.animation.add('transIn'
            var sButton = this['supportButton' + side];
            sButton.animation.switchTo(1);

            var sButton = this['supportButton' + side];
            sButton.animation.switchTo('default');
            sButton.animation.switchTo(1);

            var support = this['supportBase' + side];
            if (support.animation.currentAnimation.name == 'transOut') {
                var f = support.animation.frameIndex;
                support.animation.switchTo('transIn');
                support.animation.switchTo(f);
                support.animation.play();
            } else {
                support.animation.switchTo('transIn');
                support.animation.play();
            }
            for (var i = 0; i < 3; i++) {
                var base = this['callIn_' + side + '_' + i];
                base.visible = true;
                this['token' + side + 'Num' + i + '_1'].visible = true;
                this['token' + side + 'Num' + i + '_2'].visible = true;
            }
            this['retractTime' + side] = this.game.time.now();
        };

        Play.prototype.hideCallIns = function (side, removeBool) {
            if (removeBool && this.parameters.CALL_IN_CLEAR) {
                //console.log('hide call ins!')
                this.cancelCallIn(side);
            }

            if (this['callIn_' + side + '_1'].visible) {
                var sButton = this['supportButton' + side];
                sButton.animation.switchTo(0);

                var support = this['supportBase' + side];
                if (support.animation.currentAnimation.name == 'transIn') {
                    var f = support.animation.frameIndex;
                    support.animation.switchTo('transOut');
                    support.animation.switchTo(f);
                    support.animation.play();
                } else {
                    support.animation.switchTo(0);
                    //support.animation.play();
                }
                for (var i = 0; i < 3; i++) {
                    var base = this['callIn_' + side + '_' + i];
                    base.visible = false;
                    this['token' + side + 'Num' + i + '_1'].visible = false;
                    this['token' + side + 'Num' + i + '_2'].visible = false;
                }
            }
        };

        Play.prototype.initChevron = function (side, pointer) {
            var tokens = this['p' + side + 'Tokens1'];
            if (tokens <= 0)
                return;
            var mx = pointer.x;
            var my = pointer.y;
            if (!this.chevronInBounds(side, pointer))
                return;

            this['callIn_' + side + '_var'] = 1;

            //click own UI
            if ((side == 1 && my > this.game.stage.height - 205) || (side == 2 && my < 205)) {
                var base = this.getChildByName('callIn_' + side + '_1');
                if (base != undefined)
                    base.animation.switchTo(1);
                this['callIn_' + side + '_var'] = -1;
                return;
            }

            //check if its there already
            var chevron = this.getChildByName('chevron' + side);
            if (chevron != undefined)
                return;

            var chevronOffset = 37;
            this['chevron' + side] = new Kiwi.GameObjects.Sprite(this, this.textures['chevron' + this['colour' + side]], 0, 0);
            var chevron = this['chevron' + side];
            chevron.name = 'chevron' + side;
            chevron.x = mx - chevronOffset;
            chevron.y = my - chevronOffset;

            //chevron.animation.currentAnimation.loop = false;
            //chevron.animation.play();
            this.addChildBefore(chevron, this.supportBase1);
            chevron.animation.add('chevron_in', [0, 1, 2, 3], 0.1, false, true);
            chevron.animation.switchTo('chevron_in');
            chevron.transform.rotPointX = chevronOffset;
            chevron.transform.rotPointY = chevronOffset;
            chevron.rotation -= Math.PI / 2;

            //console.log('init chev', chevron.animation, this['mouseStartX' + side], this['mouseStartY' + side])
            //deselect button
            var base = this.getChildByName('callIn_' + side + '_1');
            if (base != undefined)
                base.animation.switchTo(1);
        };

        Play.prototype.chevronInBounds = function (side, pointer) {
            var mx = pointer.x;
            var my = pointer.y;
            if ((side == 1 && my < this.parameters.HALFWAY) || ((side == 2 && my > this.parameters.HALFWAY))) {
                return false;
            }
            var sb = this.getChildByName('callIn_' + side + '_1');
            if (side == 1) {
                //enemy side
                if (my < this.parameters.HALFWAY)
                    return false;

                //on UI area
                if (my > 824)
                    return false;

                //on call in UI area
                if (mx >= 675 && my >= 507 && sb.visible)
                    return false;
            } else {
                //enemy side
                if (my > this.parameters.HALFWAY)
                    return false;

                //on UI area
                if (my < 200)
                    return false;

                //on call in UI area
                if (mx < 93 && my < 524 && sb.visible)
                    return false;
            }
            return true;
        };

        Play.prototype.dragChevron = function (side, device) {
            if (device == null)
                return;
            var mx = device.x;
            var my = device.y;
            if ((side == 1 && my < this.parameters.HALFWAY) || (side == 2 && my > this.parameters.HALFWAY)) {
                this.callInManager.releaseChevron(side, mx, my);
                return;
            }
            var chevron = this.getChildByName('chevron' + side);

            //console.log('chev drag', chevron);
            if (chevron == undefined)
                return;

            var chevronOffset = chevron.transform.rotPointX;
            var cx = chevron.x + chevronOffset;
            var cy = chevron.y + chevronOffset;
            if (chevron.animation.frameIndex > 2) {
                chevron.animation.switchTo('default', false);
                var line = new Kiwi.Geom.Line(cx, cy, mx, my);
                var chevronVar = this.processVar(60);
                var lineVar = line.length - 125;
                if (lineVar < 0)
                    lineVar = 0;
                var frame = Math.floor(lineVar / chevronVar) + 3;
                if (frame > 6)
                    frame = 6;
                chevron.animation.switchTo(frame, false);
                chevron.rotation = -line.angle + Math.PI / 2;
            }
        };

        Play.prototype.getSideWithinRadius = function (x, y, side, radius) {
            var myArray = [];
            if (this['soldiers' + side] != undefined) {
                for (var i = 0; i < this['soldiers' + side].length; i++) {
                    var soldier = this['soldiers' + side][i];
                    var line = new Kiwi.Geom.Line(soldier.returnX(), soldier.returnY(), x, y);
                    if (line.length < radius) {
                        myArray.push(soldier);
                    }
                }
            }
            if (this['vehicles' + side] != undefined) {
                for (var i = 0; i < this['vehicles' + side].length; i++) {
                    var vehicle = this['vehicles' + side][i];
                    var line = new Kiwi.Geom.Line(vehicle.returnX(), vehicle.returnY(), x, y);
                    if (line.length < radius) {
                        myArray.push(vehicle);
                    }
                }
            }
            return myArray;
        };

        Play.prototype.removeClickable = function (clip, side) {
            if (clip === undefined)
                return;
            if (clip === null)
                return;
            if (this['clickables' + side] == undefined) {
                return;
            }
            for (var i = 0; i < this['clickables' + side].length; i++) {
                if (clip == this['clickables' + side][i]) {
                    this['clickables' + side].splice(i, 1);
                    clip.destroy();
                    clip.parent.removeChild(clip);
                    return;
                }
            }
            clip.destroy();
        };

        //MOUSE
        Play.prototype.catchMouse = function () {
            for (var j = 1; j <= this.players; j++) {
                if (this['callIn_' + j + '_var'] == 1 && this['clickTarget' + j] == '') {
                    this.dragChevron(j, this.mouse);
                } else {
                    if (this['clickTarget' + j] != '') {
                        this['dragVar' + j]++;
                        switch (this['clickTarget' + j].name) {
                            case 'cannon' + j:
                                this.cannonManager.rotateCannon(j, this.mouse);
                                break;
                            case 'node' + j + '_0_base':
                            case 'node' + j + '_1_base':
                            case 'node' + j + '_2_base':
                            case 'node' + j + '_3_base':
                            case 'node' + j + '_4_base':
                            case 'node' + j + '_5_base':
                                if (this['dragVar' + j] >= this.parameters.DRAG_MIN) {
                                    var node = this['node' + this['clickTarget' + j].side + '_' + this['clickTarget' + j].pos];
                                    if (node.type != 0 && node.ready) {
                                        this.updateArrow(j, this.mouse);
                                    }
                                }
                                break;
                        }
                    }
                }
            }
            //release
            /*if (this.mouse.justReleased()) {
            //console.log('RELEASE')
            if (this['bombing' + i]) {
            this.releaseChevron(i, this.mouse);
            } else {
            this.releaseResponse(this.mouse);
            }
            
            this.mouse.reset();
            }*/
        };

        //TOUCH
        Play.prototype.startEvents = function () {
            if (Kiwi.DEVICE.touch === false) {
                this.mouse = this.game.input.mouse;
            } else {
                this.game.input.touch.maximumPointers = 2;
            }

            this.game.input.onUp.add(this.released, this);
            this.game.input.onDown.add(this.pressed, this);
        };

        Play.prototype.pressed = function (x, y, up, down, duration, pointer) {
            this.updateTouchDown = pointer;
            if (pointer.y > this.halfway) {
                this.finger1 = pointer;
                this.finger1Down = true;
            } else {
                this.finger2 = pointer;
                this.finger2Down = true;
            }
        };

        Play.prototype.released = function (x, y, up, down, duration, pointer) {
            //need implementing
            this.updateTouchUp = pointer;
        };

        //drag
        Play.prototype.catchTouch = function () {
            for (var j = 1; j <= this.players; j++) {
                if (this['finger' + j] === null) {
                    continue;
                }
                var chevron = this.getChildByName('chevron' + j);
                if (this['callIn_' + j + '_var'] == 1 && this['clickTarget' + j] == '') {
                    this.dragChevron(j, this['finger' + j]);
                } else {
                    if (this['clickTarget' + j] != '') {
                        this['dragVar' + j]++;

                        switch (this['clickTarget' + j].name) {
                            case 'cannon' + j:
                                this.cannonManager.rotateCannon(j, this['finger' + j]);
                                break;
                            case 'node' + j + '_0_base':
                            case 'node' + j + '_1_base':
                            case 'node' + j + '_2_base':
                            case 'node' + j + '_3_base':
                            case 'node' + j + '_4_base':
                            case 'node' + j + '_5_base':
                                if (this['dragVar' + j] >= this.parameters.DRAG_MIN) {
                                    var node = this['node' + this['clickTarget' + j].side + '_' + this['clickTarget' + j].pos];
                                    if (node.type != 0 && node.ready) {
                                        this.updateArrow(j, this['finger' + j]);
                                    }
                                }
                                break;

                            default:
                                break;
                        }
                    }
                }
            }
        };

        Play.prototype.pressedCatch = function (pointer) {
            if (this.paused)
                return;
            this.checkClickablesPressed(pointer);
            for (var i = 1; i <= this.players; i++) {
                if (this['clickTarget' + i] != '') {
                    this.initClickTarget(i);
                }
                if (this['callIn_' + i + '_var'] === 1 && this['clickTarget' + i] == '') {
                    this.initChevron(i, pointer);
                }
            }
        };

        Play.prototype.releaseCatch = function (pointer) {
            if (this.paused)
                return;
            var i = 0;
            if (this['bombing' + i]) {
                this.callInManager.releaseChevron(i, pointer.x, pointer.y);
            } else {
                this.releaseResponse(pointer);
            }
        };

        Play.prototype.sendMessage = function (email, details) {
            console.log('\nStandOff Debug Error Catch.\n', details.stack, details.message, '\n\nPlease send info to ', email);
            /*var det = '';
            
            det += '<br />' + details.stack + '<br />';
            det += details.message;
            
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'http://files.kiwijs.org/error/error-email.php?e=' + email + '&d=' + det, true);
            xhr.send();
            */
        };

        Play.prototype.update = function () {
            _super.prototype.update.call(this);
            if (!this.GAME_ACTIVE) {
                if (this.countdown1 != undefined) {
                    if (this.countdown1.animation.frameIndex == 5) {
                        var backgroundMusic;
                        for (var i = this.game.audio._sounds.length - 1; i >= 0; i--) {
                            if (this.game.audio._sounds[i].key == 'backgroundMusic') {
                                backgroundMusic = this.game.audio._sounds[i];
                            }
                        }
                        backgroundMusic.stop();

                        //this.NNLogoIn = this.game.tweens.create(this.NNLogo);
                        //this.panelTopOpen.to({ y: -501 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
                        this.countdown1.visible = false;
                        this.countdownText1.visible = false;
                        this.countdownEngage1.visible = true;
                        if (this.players == 2) {
                            this.countdown2.visible = false;
                            this.countdownText2.visible = false;
                            this.countdownEngage2.visible = true;
                        }
                        this.GAME_ACTIVE = true;
                    } else if (this.countdown1.animation.frameIndex == 0) {
                        var backgroundMusic;
                        for (var i = this.game.audio._sounds.length - 1; i >= 0; i--) {
                            if (this.game.audio._sounds[i].key == 'backgroundMusic') {
                                backgroundMusic = this.game.audio._sounds[i];
                            }
                        }

                        //backgroundMusic.volume = 0;
                        if (backgroundMusic.volume == 0) {
                            this.parameters.AUDIO_ON = false;
                            this.bgSFX.mute = true;
                        } else {
                            var backgroundMusicOut = this.game.tweens.create(backgroundMusic);
                            backgroundMusicOut.to({ volume: 0 }, 2500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
                            backgroundMusicOut.start();
                        }

                        if (this.game.muteSFX) {
                            this.parameters.SFX_ON = false;
                        }
                    }
                }
                return;
            }
            if (this.paused) {
                return;
            }
            try  {
                //console.log(game.time.now(),'...');
                this.elapsedTime = this.game.time.now() - this.startTime;
                if (!this.callInsStarted) {
                    if (this.elapsedTime >= this.parameters.CALL_IN_START_TIME) {
                        this.startCallIns();
                    }
                    if (this.countdown1 != undefined) {
                        if (this.countdown1.animation.frameIndex == 6) {
                            this.removeCountdown();
                        }
                    }
                } else {
                    //if support is dropped, check time, if long enough, FUCK OFF
                    if (this.callIn_1_1.visible || this.callIn_1_var != -1) {
                        if (this.game.time.now() - this.retractTime1 >= this.parameters.CALL_IN_RETRACT_TIME) {
                            this.hideCallIns(1, true);
                        }
                    }
                    if (this.callIn_2_2.visible || this.callIn_2_var != -1) {
                        if (this.game.time.now() - this.retractTime2 >= this.parameters.CALL_IN_RETRACT_TIME)
                            this.hideCallIns(2, true);
                    }
                }

                //tick moneys
                if (this.game.time.now() - this.tickStart >= this.parameters.TICK_DURATION) {
                    this.gainCredits(this.parameters.TICK_MONEY, 1);
                    this.gainCredits(this.parameters.TICK_MONEY, 2);
                    this.tickStart = this.game.time.now();
                    //this.audioManager.playSFX(this.creditTickSFX);
                }

                this.handleInput();

                this.tick();

                this.unitManager.updateMovement();
                this.cannonManager.updateCannons();
                this.callInManager.updateCallIns();
                this.updateBullets();
                this.callInManager.updateCrates();

                this.updateBubbles();

                this.updateActionManager();
            } catch (e) {
                this.GAME_ACTIVE = false;
                this.sendMessage('zachary.freiberg@gmail.com', e);
            }
        };

        Play.prototype.handleInput = function () {
            if (this.paused)
                return;
            if (this.updateTouchDown !== null) {
                this.pressedCatch(this.updateTouchDown);
                this.updateTouchDown = null;
            }

            //this.catchTouch();
            if (Kiwi.DEVICE.touch || 1 == 1) {
                this.catchTouch();
            } else {
                this.catchMouse();
            }
            if (this.updateTouchUp !== null) {
                this.releaseCatch(this.updateTouchUp);

                if (this.finger1 !== null && this.finger1.id === this.updateTouchUp.id) {
                    this.finger1 = null;
                    this.finger1Down = false;
                } else if (this.finger2 !== null && this.finger2.id === this.updateTouchUp.id) {
                    this.finger2 = null;
                    this.finger2Down = false;
                }

                this.updateTouchUp = null;
            }
        };

        Play.prototype.doAction = function () {
            this.actionManager.waitVar = 0;
            this.actionManager.actionNum++;
            this.actionManager.doAction();
        };

        Play.prototype.updateActionManager = function () {
            if (this.players == 2)
                return;

            //tick build nodes if set to auto and alive
            var count = 0;
            for (var i = 0; i < 6; i++) {
                var n = this['node2_' + i];
                if (n != undefined) {
                    if (n.alive && n.exists) {
                        count++;
                        if (n.frequencyVar >= 0) {
                            //frequency set, peow!
                            if (n.ready) {
                                n.frequencyVar++;
                                if (n.frequencyVar >= n.frequency) {
                                    this.UIManager.releaseNode(n);
                                    n.frequencyVar = 0;
                                }
                            }
                        }
                    }
                }
            }
            if (this.waitingWave) {
                if (count == 0 && this.soldiers2.length == 0) {
                    /*for (var i = 0; i < 6; i++) {
                    var n = this['node2_' + i];
                    console.log(this['node2_' + i])
                    }*/
                    //check to see alive player 2 solders/vehicles
                    this.waitingWave = false;
                    this.actionManager.endWave();
                }
            }

            //wait
            if (this.actionManager.waitVar != 0) {
                if (typeof this.actionManager.waitVar == 'number') {
                    if (this.playTimer.elapsed() >= this.actionManager.waitVar) {
                        this.doAction();
                    }
                }
            }
        };

        Play.prototype.sendAction = function (actionName) {
            if (this.actionManager.waitVar != 0) {
                if (actionName == this.actionManager.waitVar) {
                    this.doAction();
                }
            }
        };

        Play.prototype.getOppSide = function (side) {
            var oppSide = 2;
            if (side == 2) {
                oppSide = 1;
            }
            return oppSide;
        };

        Play.prototype.healthBar = function (char) {
            var cx = char.returnX();
            var cy = char.returnY();
            if (char.healthBarRed != undefined) {
                if (char.healthBarRed.width != undefined)
                    char.healthBarRed.destroy();

                if (char.healthBarGreen != undefined) {
                    if (char.healthBarGreen.width != undefined)
                        char.healthBarGreen.destroy();
                }
                char.healthBarGreen = undefined;
            }
            var yOff = -15;
            if (char.side == 1) {
                var yOff = 15;
            }

            var hbb = new StandOffEntities.followingEffect(this, this.textures.healthRed, char, 1, 0, cx - 8, cy + yOff);
            hbb.animation.add('anim', [0, 0], 1, false, true);
            this.addChild(hbb);
            char.healthBarRed = hbb;
            var boxWidth = (char.health / char.baseHealth);
            var gx = hbb.x - (hbb.width / 2) + ((hbb.width / 2) * boxWidth);
            if (char.side == 2) {
                gx = hbb.x + hbb.width / 2 - ((hbb.width / 2) * boxWidth);
            }
            var hbg = new StandOffEntities.followingEffect(this, this.textures.healthGreen, char, boxWidth, 0, gx, cy + yOff);

            //hbg.width = (char.health / char.baseHealth) * 64;
            hbg.animation.add('anim', [0, 0], 1, false, true);
            this.addChild(hbg);
            char.healthBarGreen = hbg;
        };

        Play.prototype.getName = function (char) {
            if (char.contentType == 0) {
                switch (char.type) {
                    case 0:
                        return 'rifleman';
                    case 1:
                        return 'bazooka';
                    case 2:
                        return 'flamer';
                }
            } else {
                switch (char.type) {
                    case 0:
                        return 'apc';
                    case 1:
                        return 'sniper';
                    case 2:
                        return 'tank';
                }
            }
            return null;
        };

        Play.prototype.removeClip = function (clip) {
            //splice from arrays
            var s = 'soldiers';
            if (clip.contentType == 1) {
                s = 'vehicles';
            }

            var num = this.getContentPos(clip);
            if (num == -1)
                return;
            this[s + '' + clip.side].splice(num, 1);

            var num2 = this.getMovingContentPos(clip);
            if (num2 != -1) {
                this.movingContent.splice(num2, 1);
            }

            if (clip.legs != undefined) {
                clip.legs.exists = false;
                clip.legs.destroy();
            }
            clip.exists = false;
            clip.destroy();
        };

        Play.prototype.getContentPos = function (clip) {
            if (clip.contentType == 0) {
                var s = 'soldiers';
            } else {
                var s = 'vehicles';
            }
            var myArray = this[s + '' + clip.side];
            if (myArray != undefined) {
                var l = myArray.length;
                for (var i = 0; i < l; i++) {
                    var testClip = myArray[i];
                    if (clip == testClip) {
                        return i;
                    }
                }
            }
            return -1;
        };

        //get position in movingContent array
        Play.prototype.getMovingContentPos = function (clip) {
            for (var i = 0; i < this.movingContent.length; i++) {
                if (clip == this.movingContent[i]) {
                    return i;
                }
            }
            return -1;
        };

        Play.prototype.tick = function () {
            this.tickVar++;

            this.tickCredits(1);
            this.tickCredits(2);

            switch (this.tickVar) {
                case this.parameters.TICK_VAR:
                    for (var i = this.soldiers1.length - 1; i >= 0; i--) {
                        this.unitManager.attack(this.soldiers1[i]);
                    }
                    break;
                case this.parameters.TICK_VAR * 2:
                    for (var i = this.soldiers2.length - 1; i >= 0; i--) {
                        this.unitManager.attack(this.soldiers2[i]);
                    }
                    break;

                case this.parameters.TICK_VAR * 5:
                    for (var i = this.deathArray.length - 1; i >= 0; i--) {
                        var clip = this.deathArray[i];
                        if (clip != undefined) {
                            this.unitManager.kill(clip);
                        }
                    }

                    this.deathArray.length = 0;
                    this.tickVar = 0;
                    break;
                default:
                    break;
            }
            for (var i = this.removeArray.length - 1; i >= 0; i--) {
                var clip = this.removeArray[i];
                if (clip != undefined) {
                    this.removeClip(clip);
                }
            }
            this.removeArray.length = 0;
        };

        Play.prototype.updateBubbles = function () {
            if (this.bubbles.length == 0)
                return;
            this.bubbleVar++;
            if (this.bubbles[0].name == 'mudBubble') {
                if (this.bubbleVar >= this.parameters.MUD_BUBBLE_VAR) {
                    var r = Math.floor(Math.random() * this.bubbles.length);
                    this.myBubble = this.bubbles[r];
                    this.myBubble.visible = true;
                    this.myBubble.animation.play('pop');
                    this.bubbleVar = 0;
                    this.parameters.MUD_BUBBLE_VAR = Math.floor(Math.random() * (this.parameters.MUD_MAX_TIME - this.parameters.MUD_MIN_TIME) + this.parameters.MUD_MIN_TIME);
                }
            } else if (this.bubbles[0].name == 'lavaBubble') {
                if (this.bubbleVar >= this.parameters.LAVA_BUBBLE_VAR) {
                    var r = Math.floor(Math.random() * this.bubbles.length);
                    this.myBubble = this.bubbles[r];
                    this.myBubble.visible = true;
                    var myAni = Math.floor(Math.random() * 3);
                    switch (myAni) {
                        case 0:
                            this.myBubble.animation.play('pop1');
                            break;
                        case 1:
                            this.myBubble.animation.play('pop2');
                            break;
                        case 2:
                            this.myBubble.animation.play('pop3');
                            break;
                    }

                    //this.myBubble.animation.play('pop');
                    this.bubbleVar = 0;
                    this.parameters.LAVA_BUBBLE_VAR = Math.floor(Math.random() * (this.parameters.LAVA_MAX_TIME - this.parameters.LAVA_MIN_TIME) + this.parameters.LAVA_MIN_TIME);
                }
            }

            for (var i = this.bubbles.length - 1; i >= 0; i--) {
                if (!this.bubbles[i].animation.isPlaying) {
                    this.bubbles[i].visible = false;
                }
            }
        };

        Play.prototype.getSin = function (ang) {
            while (ang < 0) {
                ang += Math.PI * 2;
            }
            while (Math.PI * 2 <= ang) {
                ang -= Math.PI * 2;
            }
            var perc = (ang / (Math.PI * 2));
            var num = Math.floor(this.trigCount * perc);
            return this.sinArr[num];
        };

        Play.prototype.getCos = function (ang) {
            while (ang < 0) {
                ang += Math.PI * 2;
            }
            while (Math.PI * 2 <= ang) {
                ang -= Math.PI * 2;
            }

            //if (ang < 0) ang += Math.PI * 2;
            var perc = (ang / (Math.PI * 2));
            var num = Math.floor(this.trigCount * perc);
            return this.cosArr[num];
        };

        Play.prototype.returnHOffsetX = function (dist, ang) {
            //return this.getSin(ang)*dist;
            var newX = this.getSin(ang) * dist;
            return newX;
        };

        Play.prototype.returnHOffsetY = function (dist, ang) {
            //return this.getCos(ang)*dist;
            var newY = this.getCos(ang) * dist;
            return newY;
        };

        Play.prototype.gainCredits = function (num, side) {
            this['p' + side + 'TickCredits'] += num;
        };

        Play.prototype.tickCredits = function (side) {
            var tCredits = this['p' + side + 'TickCredits'];
            if (tCredits > 0) {
                var val = 1;
                if (tCredits > 100) {
                    val = 100;
                } else if (tCredits > 10) {
                    val = 10;
                }

                this.updateCredits(val, side);
                this['p' + side + 'TickCredits'] -= val;
            }
        };

        Play.prototype.updateCredits = function (value, side) {
            this['p' + side + 'Credits'] += value;
            var credits = this['p' + side + 'Credits'];
            var n0;
            var n1;
            var n2;
            var n3;
            if (credits < 0) {
                this['p' + side + 'Credits'] = 0;
                n0 = 0;
                n1 = 0;
                n2 = 0;
                n3 = 0;
            } else {
                n0 = Math.floor(credits / 1000);
                if (n0 > 9) {
                    n0 = 9;
                    n1 = 9;
                    n2 = 9;
                    n3 = 9;
                } else {
                    //console.log('n0:', n0);
                    //hundreds
                    //'w' means working var
                    var w0 = Math.floor(credits / 1000) * 1000;
                    var w1 = credits - w0;
                    n1 = Math.floor(w1 / 100);

                    //console.log('n1:', n1);
                    //tens
                    var w2 = w1 - (n1 * 100);
                    n2 = Math.floor(w2 / 10);

                    //console.log('n2:', n2);
                    n3 = w2 - (n2 * 10);
                }
            }

            if (this['credit' + side + 'Num1'] != undefined) {
                this['credit' + side + 'Num1'].animation.switchTo(n0);
                this['credit' + side + 'Num2'].animation.switchTo(n1);
                this['credit' + side + 'Num3'].animation.switchTo(n2);
                this['credit' + side + 'Num4'].animation.switchTo(n3);
            }

            //check to see if the console is open on that side
            if (value > 0)
                this.UIManager.updateConsole(side);
        };

        Play.prototype.updateTokens = function (value, pos, side) {
            //this['p1Tokens' + i] = this.parameters['TOKENS_P1_' + i];
            //sprites
            //first digit player, token count, digit
            //private token1Num0_1: Kiwi.GameObjects.Sprite;
            //this['token1Num' + i + '_1']
            this['p' + side + 'Tokens' + pos] += value;
            var tokens = this['p' + side + 'Tokens' + pos];

            //console.log('update tokens play:', value, pos, side, tokens)
            var n1;
            var n2;
            if (tokens < 0) {
                this['p' + side + 'Tokens' + pos] = 0;
                n1 = 0;
                n2 = 0;
            } else {
                n1 = Math.floor(tokens / 10);
                if (n1 > 9) {
                    n1 = 9;
                    n2 = 9;
                } else {
                    //tens
                    //'w' means working var
                    var w0 = Math.floor(tokens / 10) * 10;
                    var w1 = tokens - w0;
                    n1 = Math.floor(w0 / 10);

                    //console.log('n1:', n1);
                    //ones
                    n2 = tokens - (n1 * 10);
                    //console.log('n2:', n2);
                }
            }

            //console.log('numerals:', 'token' + side + 'Num' + pos + '_1', 'token' + side + 'Num' + pos + '_2');
            this['token' + side + 'Num' + pos + '_1'].animation.switchTo(n1);
            this['token' + side + 'Num' + pos + '_2'].animation.switchTo(n2);

            //exhausted?
            if (this['p' + side + 'Tokens0'] == 0 && this['p' + side + 'Tokens1'] == 0 && this['p' + side + 'Tokens2'] == 0 && this.callInsStarted) {
                var myText = this['supportText' + side];

                //if (myText == undefined || myText.animation.name == "") return;
                //if (this.support[0] == 0 && this.support[1] == 0 && this.support[2] == 0) return;
                myText.animation.switchTo('default');
                myText.animation.switchTo(5);
                this.hideCallIns(side, true);
            }
        };
        return Play;
    })(Kiwi.State);
    MyStates.Play = Play;
})(MyStates || (MyStates = {}));
var MyStates;
(function (MyStates) {
    var Replay = (function (_super) {
        __extends(Replay, _super);
        function Replay() {
            _super.call(this, 'Replay');
            this.players = 2;
        }
        Replay.prototype.create = function (players, level, colour1, colour2, support) {
            _super.prototype.create.call(this);
            this.players = players;
            this.game.audio.stopAll();

            if (!this.game.commodityManager.hasElite) {
                this.game.audio.stopAll(); //Stop all sounds!
                CocoonJS.Ad.preloadFullScreen();
                CocoonJS.Ad.showFullScreen();
            }

            this.game.states.switchState('Play', MyStates.Play, null, { players: this.players, level: level, colour1: colour1, colour2: colour2, support: support });
        };
        return Replay;
    })(Kiwi.State);
    MyStates.Replay = Replay;
})(MyStates || (MyStates = {}));
var MyStates;
(function (MyStates) {
    var TwoPlayerSetup = (function (_super) {
        __extends(TwoPlayerSetup, _super);
        function TwoPlayerSetup() {
            _super.call(this, 'TwoPlayerSetup');
            this.side1Colour = 0;
            this.side2Colour = 1;
            this.overlayActive = false;
        }
        TwoPlayerSetup.prototype.preload = function () {
            _super.prototype.preload.call(this);
        };

        TwoPlayerSetup.prototype.create = function (players, level, colour1, colour2, support) {
            _super.prototype.create.call(this);
            this.parameters = new StandOff.Parameters();
            this.overlayActive = false;

            this.background = new Kiwi.GameObjects.Sprite(this, this.textures.splashBackground, 0, 0);
            this.addChild(this.background);

            //Add callback BEFORE sides to stop create/login if the user was scrolling
            this.game.input.onUp.add(this.showButtons, this);

            this.side1 = new MenuEntities.twoPlayerSetupPanel(this, 1, 1, this.game.userManager.currentMainUser);
            this.side1.y = this.game.stage.height / 2;
            this.addChild(this.side1);

            this.side2 = new MenuEntities.twoPlayerSetupPanel(this, 2, 2, this.game.userManager.secondaryUser);
            this.side2.rotation = Math.PI;
            this.side2.y = this.game.stage.height / 2;
            this.side2.x = this.game.stage.width;
            this.addChild(this.side2);

            //Panels
            this.middlePanel = new Kiwi.GameObjects.Sprite(this, this.textures.middlePanel, 0, 286);
            this.topPanel = new Kiwi.GameObjects.Sprite(this, this.textures.topPanel, 0, -63);
            this.bottomPanel = new Kiwi.GameObjects.Sprite(this, this.textures.bottomPanel, 0, 485);

            // Panel Tweens
            //Close
            this.panelTopClose = this.game.tweens.create(this.topPanel);
            this.panelBottomClose = this.game.tweens.create(this.bottomPanel);
            this.panelTopClose.to({ y: -63 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomClose.to({ y: 485 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelTopClose.onComplete(this.openPanels, this);

            //Open
            this.panelTopOpen = this.game.tweens.create(this.topPanel);
            this.panelBottomOpen = this.game.tweens.create(this.bottomPanel);
            this.panelTopOpen.to({ y: -601 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomOpen.to({ y: 1023 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);

            this.backButton = new MenuEntities.MenuButton(this, this.textures.backButton, 0, 0);
            this.backButton.x = this.game.stage.width / 2 - this.backButton.width / 2;
            this.backButton.y = this.game.stage.height / 2 - this.backButton.height / 2;
            this.addChild(this.backButton);

            //Layering panels
            this.addChild(this.bottomPanel);
            this.addChild(this.topPanel);

            this.openPanels();
        };

        TwoPlayerSetup.prototype.showButtons = function (x, y, timeDown, timeUp, duration, pointer) {
            if (this.overlayActive)
                return;

            var rect = new Kiwi.Geom.Rectangle(390, 5, 190, 27);

            if (!this.side2.readyToStart && !this.side2.scrolling) {
                /*rect.setTo(390, 5, 190, 27);
                if (rect.contains(x, y)) {
                if (this.game.webview.available) {
                this.overlayActive = true;
                this.sideToLogin = this.side2;
                this.game.webview.showRegister(this.webviewCallback, this);
                } else {
                //Complete lies....
                console.log('Sorry we couldn\'t launch the login screen at this moment. Please re-launch the app to try again.');
                }
                }*/
                //Login
                //rect.setTo(608, 5, 124, 27);
                rect.setTo(390, 5, 124 + 190 + 28, 27 + 63);
                if (rect.contains(x, y)) {
                    if (this.game.webview.available) {
                        //Login
                        this.overlayActive = true;
                        this.sideToLogin = this.side2;
                        this.game.webview.showLogin(this.webviewCallback, this, 'Player 2: Login', '');
                    } else {
                        //Complete lies....
                        console.log('Sorry we couldn\'t launch the login screen at this moment. Please re-launch the app to try again.');
                    }
                }
            }

            if (!this.side1.readyToStart && !this.side1.scrolling) {
                /*rect.setTo(185, 990, 185, 25);
                if (rect.contains(x, y)) {
                if(this.game.webview.available) {
                this.overlayActive = true;
                this.sideToLogin = this.side1;
                this.game.webview.showRegister(this.webviewCallback, this);
                } else {
                //Complete lies....
                console.log('Sorry we couldn\'t launch the login screen at this moment. Please re-launch the app to try again.');
                }
                }*/
                //Login
                rect.setTo(35, 927, 125 + 185 + 25, 25 + 63);
                if (rect.contains(x, y)) {
                    if (this.game.webview.available) {
                        //Login
                        this.overlayActive = true;
                        this.sideToLogin = this.side1;
                        this.game.webview.showLogin(this.webviewCallback, this, 'Player 1: Login', '');
                    } else {
                        //Complete lies....
                        console.log('Sorry we couldn\'t launch the login screen at this moment. Please re-launch the app to try again.');
                    }
                }
            }

            if (this.side1.scrollPointer && this.side1.scrollPointer.id == pointer.id || this.side2.scrollPointer && this.side2.scrollPointer.id == pointer.id) {
                return;
            }

            if (this.backButton.box.worldHitbox.contains(x, y)) {
                this.backButtonHit();
            }
        };

        TwoPlayerSetup.prototype.webviewCallback = function (eventType, success, data) {
            switch (eventType) {
                case 'login':
                    if (success && this.sideToLogin) {
                        this.overlayActive = false;
                        this.sideToLogin.selectedUser = data;
                        this.sideToLogin.selectedUserText.text = this.sideToLogin.selectedUser.name.toUpperCase();
                        this.side1.updateUserList();
                        this.side2.updateUserList();
                    }
                    break;
                case 'register':
                    if (success) {
                        this.overlayActive = false;
                        this.sideToLogin.selectedUser = data;
                        this.sideToLogin.selectedUserText.text = this.sideToLogin.selectedUser.name.toUpperCase();
                        this.side1.updateUserList();
                        this.side2.updateUserList();
                    }
                    break;
                case 'closed':
                    this.overlayActive = false;
                    break;
            }
        };

        TwoPlayerSetup.prototype.update = function () {
            _super.prototype.update.call(this);
        };
        TwoPlayerSetup.prototype.checkReadyStatus = function () {
            if (this.side1.readyToStart && this.side2.readyToStart) {
                //Set the user accounts here...
                this.game.userManager.currentMainUser = this.side1.selectedUser;
                this.game.userManager.secondaryUser = this.side2.selectedUser;

                this.panelTopClose.onComplete(this.switchToSettings, this);
                this.closePanels();
            }
        };
        TwoPlayerSetup.prototype.colourRight = function (side) {
            if (this.game.commodityManager.hasElite) {
                if (this['side' + side + 'Colour'] == 3) {
                    this['side' + side + 'Colour'] = 0;
                } else {
                    this['side' + side + 'Colour']++;
                }
                this.game.menuSFX.playSuccess();
            } else {
                //Do NO sound. Aka Error
                this.game.menuSFX.playError();
            }
        };

        TwoPlayerSetup.prototype.colourLeft = function (side) {
            if (this.game.commodityManager.hasElite) {
                if (this['side' + side + 'Colour'] == 0) {
                    this['side' + side + 'Colour'] = 3;
                } else {
                    this['side' + side + 'Colour']--;
                }
                this.game.menuSFX.playSuccess();
            } else {
                //Do NO sound. Aka Error
                this.game.menuSFX.playError();
            }
        };
        TwoPlayerSetup.prototype.switchToSettings = function () {
            this.exitState();
            this.game.side1Colour = this.side1Colour;
            this.game.side2Colour = this.side2Colour;
            this.game.states.switchState('TwoPlayerSettings', MyStates.TwoPlayerSettings, null, { players: 2, level: 1, colour1: this.side1Colour, colour2: this.side2Colour, support: [this.parameters.HELI_AMOUNT, this.parameters.BOMB_AMOUNT, this.parameters.HEAL_AMOUNT, this.parameters.HELI_AMOUNT, this.parameters.BOMB_AMOUNT, this.parameters.HEAL_AMOUNT] });
        };

        TwoPlayerSetup.prototype.openPanels = function () {
            this.panelTopOpen.start();
            this.panelBottomOpen.start();
        };
        TwoPlayerSetup.prototype.closePanels = function () {
            this.panelTopClose.start();
            this.panelBottomClose.start();
        };
        TwoPlayerSetup.prototype.exitState = function () {
            //game.tweens.removeAll();
        };
        TwoPlayerSetup.prototype.backButtonHit = function () {
            this.game.menuSFX.playSuccess();
            if (this.overlayActive)
                return;
            if (this.panelTopClose.isRunning || this.panelTopOpen.isRunning)
                return;
            this.panelTopClose.onComplete(this.backButtonStart, this);
            this.closePanels();
        };
        TwoPlayerSetup.prototype.backButtonStart = function () {
            if (this.overlayActive)
                return;
            this.game.states.switchState('MainMenu', MyStates.MainMenu, null);
        };

        TwoPlayerSetup.prototype.shutDown = function () {
            this.game.input.onDown.remove(this.side1.pressedInput, this.side1);
            this.game.input.onUp.remove(this.side1.releasedInput, this.side1);

            this.game.input.onDown.remove(this.side2.pressedInput, this.side2);
            this.game.input.onUp.remove(this.side2.releasedInput, this.side2);

            this.game.input.onUp.remove(this.showButtons, this);
        };
        return TwoPlayerSetup;
    })(Kiwi.State);
    MyStates.TwoPlayerSetup = TwoPlayerSetup;
})(MyStates || (MyStates = {}));
var MyStates;
(function (MyStates) {
    var TwoPlayerSettings = (function (_super) {
        __extends(TwoPlayerSettings, _super);
        function TwoPlayerSettings() {
            _super.call(this, 'TwoPlayerSettings');
            this.selectedMap = 0;
        }
        TwoPlayerSettings.prototype.preload = function () {
            _super.prototype.preload.call(this);
        };

        TwoPlayerSettings.prototype.create = function (players, level, colour1, colour2, support) {
            _super.prototype.create.call(this);
            this.colour1 = colour1;
            this.colour2 = colour2;

            this.selectedMap = 0;

            this.stateData = {
                players: players,
                level: level,
                colour1: colour1,
                colour2: colour2,
                support: []
            };

            this.parameters = new StandOff.Parameters();

            this.callinText1 = support[0];
            this.callinText2 = support[1];
            this.callinText3 = support[2];

            this.background = new Kiwi.GameObjects.Sprite(this, this.textures.splashBackground, 0, 0);
            this.addChild(this.background);

            this.side1 = new MenuEntities.twoPlayerSettingsPanel(this, 1, this.colour1);
            this.side1.y = this.game.stage.height / 2;
            this.addChild(this.side1);

            this.side2 = new MenuEntities.twoPlayerSettingsTop(this, 2, 2);
            this.side2.y = 0;
            this.side2.x = 0;
            this.addChild(this.side2);

            //Panels
            this.middlePanel = new Kiwi.GameObjects.Sprite(this, this.textures.middlePanel, 0, 286);
            this.topPanel = new Kiwi.GameObjects.Sprite(this, this.textures.topPanel, 0, -63);
            this.bottomPanel = new Kiwi.GameObjects.Sprite(this, this.textures.bottomPanel, 0, 485);
            this.backButton = new MenuEntities.MenuButton(this, this.textures.backButton, 0, 0);
            this.backButton.x = this.game.stage.width / 2 - this.backButton.width / 2;
            this.backButton.y = this.game.stage.height / 2 - this.backButton.height / 2;

            // Panel Tweens
            //Close
            this.panelTopClose = this.game.tweens.create(this.topPanel);
            this.panelBottomClose = this.game.tweens.create(this.bottomPanel);
            this.panelTopClose.to({ y: -63 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomClose.to({ y: 485 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelTopClose.onComplete(this.openPanels, this);

            //Open
            this.panelTopOpen = this.game.tweens.create(this.topPanel);
            this.panelBottomOpen = this.game.tweens.create(this.bottomPanel);
            this.panelTopOpen.to({ y: -601 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomOpen.to({ y: 1023 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);

            this.backButton.input.onUp.add(this.backButtonHit, this);
            this.addChild(this.backButton);

            //Layering panels
            this.addChild(this.bottomPanel);
            this.addChild(this.topPanel);

            this.openPanels();
        };

        TwoPlayerSettings.prototype.update = function () {
            _super.prototype.update.call(this);
        };
        TwoPlayerSettings.prototype.startSettings = function () {
            this.panelTopClose.onComplete(this.switchToPlay, this);
            this.closePanels();
        };
        TwoPlayerSettings.prototype.switchToPlay = function () {
            this.exitState();

            this.game.mapSelected = this.selectedMap; //(<Kiwi.GameObjects.Sprite> this.side1.getChildByName('map')).animation.frameIndex;

            //Random Map Selector // 7 is the
            if (this.game.mapSelected == 6) {
                this.game.mapSelected = Math.floor(Math.random() * 5);
            }

            this.game.colorsSelected = [this.colour1, this.colour2];
            this.game.commodityManager.useCredits(this.side2.creditsBeingUsed);
            this.game.states.switchState('Loader', MyStates.Loader, null, {
                players: 2,
                level: this.game.mapSelected,
                colour1: this.colour1,
                colour2: this.colour2,
                support: [
                    this.side2.slot1.quantity,
                    this.side2.slot2.quantity,
                    this.side2.slot3.quantity,
                    this.side2.slot1.quantity,
                    this.side2.slot2.quantity,
                    this.side2.slot3.quantity]
            });
            //this.game.states.switchState('TwoPlayerSettings', MyStates.TwoPlayerSettings, null);
        };

        TwoPlayerSettings.prototype.toTheStore = function () {
            this.panelTopClose.onComplete(function () {
                this.game.states.switchState('StoreMenu', MyStates.StoreMenu, null, { backTo: 'TwoPlayerSettings', data: this.stateData });
            }, this);
            this.closePanels();
        };

        TwoPlayerSettings.prototype.openPanels = function () {
            this.panelTopOpen.start();
            this.panelBottomOpen.start();
        };

        TwoPlayerSettings.prototype.closePanels = function () {
            this.panelTopClose.start();
            this.panelBottomClose.start();
        };
        TwoPlayerSettings.prototype.exitState = function () {
        };
        TwoPlayerSettings.prototype.backButtonHit = function () {
            this.game.menuSFX.playSuccess();
            if (this.panelTopClose.isRunning || this.panelTopOpen.isRunning)
                return;
            this.panelTopClose.onComplete(this.backButtonStart, this);
            this.closePanels();
        };
        TwoPlayerSettings.prototype.backButtonStart = function () {
            this.game.states.switchState('TwoPlayerSetup', MyStates.TwoPlayerSetup, null);
        };
        return TwoPlayerSettings;
    })(Kiwi.State);
    MyStates.TwoPlayerSettings = TwoPlayerSettings;
})(MyStates || (MyStates = {}));
var MyStates;
(function (MyStates) {
    var TrainingSetup = (function (_super) {
        __extends(TrainingSetup, _super);
        function TrainingSetup() {
            _super.call(this, 'TrainingSetup');
            this.side1Colour = 0;
            this.side2Colour = 0;
            this.overlayActive = false;
        }
        TrainingSetup.prototype.preload = function () {
            _super.prototype.preload.call(this);
        };

        TrainingSetup.prototype.create = function (players, level, colour1, colour2, support) {
            _super.prototype.create.call(this);

            this.parameters = new StandOff.Parameters();

            this.overlayActive = false;

            this.background = new Kiwi.GameObjects.Sprite(this, this.textures.splashBackground, 0, 0);
            this.addChild(this.background);
            this;

            this.game.input.onUp.add(this.showButtons, this);

            this.side1 = new MenuEntities.trainingSetupBottom(this, 1, 1, this.game.userManager.currentMainUser);
            this.side1.y = this.game.stage.height / 2;
            this.addChild(this.side1);

            this.side2 = new MenuEntities.trainingSetupTop(this, 2, 2);
            this.addChild(this.side2);

            //Panels
            this.middlePanel = new Kiwi.GameObjects.Sprite(this, this.textures.middlePanel, 0, 286);
            this.topPanel = new Kiwi.GameObjects.Sprite(this, this.textures.topPanel, 0, -63);
            this.bottomPanel = new Kiwi.GameObjects.Sprite(this, this.textures.bottomPanel, 0, 485);

            // Panel Tweens
            //Close
            this.panelTopClose = this.game.tweens.create(this.topPanel);
            this.panelBottomClose = this.game.tweens.create(this.bottomPanel);
            this.panelTopClose.to({ y: -63 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomClose.to({ y: 485 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelTopClose.onComplete(this.openPanels, this);

            //Open
            this.panelTopOpen = this.game.tweens.create(this.topPanel);
            this.panelBottomOpen = this.game.tweens.create(this.bottomPanel);
            this.panelTopOpen.to({ y: -601 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomOpen.to({ y: 1023 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);

            this.backButton = new MenuEntities.MenuButton(this, this.textures.backButton, 0, 0);
            this.backButton.x = this.game.stage.width / 2 - this.backButton.width / 2;
            this.backButton.y = this.game.stage.height / 2 - this.backButton.height / 2;
            this.addChild(this.backButton);

            //Layering panels
            this.addChild(this.bottomPanel);
            this.addChild(this.topPanel);

            this.openPanels();
        };

        TrainingSetup.prototype.showButtons = function (x, y) {
            if (this.overlayActive || this.side1.scrolling)
                return;

            var rect = new Kiwi.Geom.Rectangle(185, 990, 185, 25 + 63);

            /*
            if (rect.contains(x, y)) {
            if(this.game.webview.available) {
            this.overlayActive = true;
            this.game.webview.showRegister(this.webviewCallback, this);
            } else {
            //Complete lies....
            console.log('Sorry we couldn\'t launch the login screen at this moment. Please re-launch the app to try again.');
            }
            return;
            }
            */
            rect.setTo(35, 927, 125 + 20 + 185, 25 + 63); //nasty but cbf
            if (rect.contains(x, y)) {
                if (this.game.webview.available) {
                    //Login
                    this.overlayActive = true;
                    this.game.webview.showLogin(this.webviewCallback, this, 'Login', '');
                } else {
                    //Complete lies....
                    console.log('Sorry we couldn\'t launch the login screen at this moment. Please re-launch the app to try again.');
                }
                return;
            }

            if (this.backButton.box.worldHitbox.contains(x, y)) {
                this.game.menuSFX.playSuccess();
                this.backButtonHit();
            }
        };

        TrainingSetup.prototype.webviewCallback = function (eventType, success, data) {
            switch (eventType) {
                case 'login':
                    if (success) {
                        this.overlayActive = false;
                        this.side1.selectedUser = data;
                        this.side1.selectedUserText.text = this.side1.selectedUser.name.toUpperCase();
                        this.side1.updateUserList();
                    }
                    break;
                case 'register':
                    if (success) {
                        this.overlayActive = false;
                        this.side1.selectedUser = data;
                        this.side1.selectedUserText.text = this.side1.selectedUser.name.toUpperCase();
                        this.side1.updateUserList();
                    }
                    break;
                case 'closed':
                    this.overlayActive = false;
                    break;
            }
        };

        TrainingSetup.prototype.update = function () {
            _super.prototype.update.call(this);
        };
        TrainingSetup.prototype.toTheStore = function () {
            if (this.overlayActive)
                return;

            this.panelTopClose.onComplete(function () {
                this.game.states.switchState('StoreMenu', MyStates.StoreMenu, null, { backTo: 'TrainingSetup' });
            }, this);
            this.closePanels();
        };
        TrainingSetup.prototype.startSettings = function () {
            if (this.overlayActive)
                return;

            this.game.userManager.currentMainUser = this.side1.selectedUser;
            this.panelTopClose.onComplete(this.switchToSettings, this);
            this.closePanels();
        };
        TrainingSetup.prototype.colourRight = function (side) {
            if (this.game.commodityManager.hasElite) {
                if (this['side' + side + 'Colour'] == 3) {
                    this['side' + side + 'Colour'] = 0;
                } else {
                    this['side' + side + 'Colour']++;
                }
                this.game.menuSFX.playSuccess();
            } else {
                //Do NO sound. Aka Error
                this.game.menuSFX.playError();
            }
        };

        TrainingSetup.prototype.colourLeft = function (side) {
            if (this.game.commodityManager.hasElite) {
                if (this['side' + side + 'Colour'] == 0) {
                    this['side' + side + 'Colour'] = 3;
                } else {
                    this['side' + side + 'Colour']--;
                }
                this.game.menuSFX.playSuccess();
            } else {
                //Do NO sound. Aka Error
                this.game.menuSFX.playError();
            }
        };
        TrainingSetup.prototype.switchToSettings = function () {
            this.game.side1Colour = this.side1Colour;
            this.game.side2Colour = this.side2Colour;
            this.game.states.switchState('TrainingSettings', MyStates.TrainingSettings, null, { players: 1, level: 1, colour1: this.side1Colour, colour2: 1, support: [this.parameters.HELI_AMOUNT, this.parameters.BOMB_AMOUNT, this.parameters.HEAL_AMOUNT, this.parameters.HELI_AMOUNT, this.parameters.BOMB_AMOUNT, this.parameters.HEAL_AMOUNT] });
        };

        TrainingSetup.prototype.openPanels = function () {
            this.panelTopOpen.start();
            this.panelBottomOpen.start();
        };
        TrainingSetup.prototype.closePanels = function () {
            this.panelTopClose.start();
            this.panelBottomClose.start();
        };
        TrainingSetup.prototype.backButtonHit = function () {
            if (this.panelTopClose.isRunning || this.panelTopOpen.isRunning)
                return;
            this.panelTopClose.onComplete(this.backButtonStart, this);
            this.closePanels();
        };
        TrainingSetup.prototype.backButtonStart = function () {
            this.game.states.switchState('MainMenu', MyStates.MainMenu, null);
        };

        TrainingSetup.prototype.shutDown = function () {
            this.game.input.onDown.remove(this.side1.pressedInput, this.side1);
            this.game.input.onUp.remove(this.side1.releasedInput, this.side1);

            this.game.input.onUp.remove(this.showButtons, this);
        };
        return TrainingSetup;
    })(Kiwi.State);
    MyStates.TrainingSetup = TrainingSetup;
})(MyStates || (MyStates = {}));
var MyStates;
(function (MyStates) {
    var TrainingSettings = (function (_super) {
        __extends(TrainingSettings, _super);
        function TrainingSettings() {
            _super.call(this, 'TrainingSettings');
        }
        TrainingSettings.prototype.preload = function () {
            _super.prototype.preload.call(this);
        };

        TrainingSettings.prototype.create = function (players, level, colour1, colour2, support) {
            _super.prototype.create.call(this);

            this.stateData = {
                players: players,
                level: level,
                colour1: colour1,
                colour2: colour2,
                support: []
            };

            this.colour1 = colour1;
            this.colour2 = colour2;

            this.parameters = new StandOff.Parameters();

            this.callinText1 = support[0];
            this.callinText2 = support[1];
            this.callinText3 = support[2];

            this.background = new Kiwi.GameObjects.Sprite(this, this.textures.splashBackground, 0, 0);
            this.addChild(this.background);

            this.side1 = new MenuEntities.trainingSettingsBottom(this, 1, this.colour1);
            this.side1.y = this.game.stage.height / 2;
            this.addChild(this.side1);

            this.side2 = new MenuEntities.trainingSettingsTop(this, 2, 2);
            this.side2.y = 0;
            this.side2.x = 0;
            this.addChild(this.side2);

            //Panels
            this.middlePanel = new Kiwi.GameObjects.Sprite(this, this.textures.middlePanel, 0, 286);
            this.topPanel = new Kiwi.GameObjects.Sprite(this, this.textures.topPanel, 0, -63);
            this.bottomPanel = new Kiwi.GameObjects.Sprite(this, this.textures.bottomPanel, 0, 485);
            this.backButton = new MenuEntities.MenuButton(this, this.textures.backButton, 0, 0);
            this.backButton.x = this.game.stage.width / 2 - this.backButton.width / 2;
            this.backButton.y = this.game.stage.height / 2 - this.backButton.height / 2;

            // Panel Tweens
            //Close
            this.panelTopClose = this.game.tweens.create(this.topPanel);
            this.panelBottomClose = this.game.tweens.create(this.bottomPanel);
            this.panelTopClose.to({ y: -63 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomClose.to({ y: 485 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelTopClose.onComplete(this.openPanels, this);

            //Open
            this.panelTopOpen = this.game.tweens.create(this.topPanel);
            this.panelBottomOpen = this.game.tweens.create(this.bottomPanel);
            this.panelTopOpen.to({ y: -601 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomOpen.to({ y: 1023 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);

            this.backButton.input.onUp.add(this.backButtonHit, this);
            this.addChild(this.backButton);

            //Setting inputs
            //this.backButton.input.onUp.add(this.backButtonHit, this);
            //this.signUpButton.input.onUp.add(this.signUpButtonHit, this);
            //this.loginButton.input.onUp.add(this.loginButtonHit, this);
            //this.guestButton.input.onUp.add(this.guestButtonHit, this);
            //Layering panels
            this.addChild(this.bottomPanel);
            this.addChild(this.topPanel);

            //this.game.input.onDown.add(this.mousePos, this);
            this.openPanels();
        };

        TrainingSettings.prototype.update = function () {
            _super.prototype.update.call(this);
        };
        TrainingSettings.prototype.startSettings = function () {
            this.panelTopClose.onComplete(this.switchToPlay, this);
            this.closePanels();
        };
        TrainingSettings.prototype.switchToPlay = function () {
            //this.state
            this.game.saveManager.add('playTutorial', false, true);

            this.game.mapSelected = 0;
            this.game.colorsSelected = [this.colour1, this.colour2];

            //Reduce the amount of credits being used
            this.game.commodityManager.useCredits(this.side2.creditsBeingUsed);

            this.game.states.switchState('Loader', MyStates.Loader, null, {
                players: 1,
                level: this.game.mapSelected,
                colour1: this.colour1,
                colour2: this.colour2,
                support: [this.side2.slot1.quantity, this.side2.slot2.quantity, this.side2.slot3.quantity, this.side2.slot1.quantity, this.side2.slot2.quantity, this.side2.slot3.quantity]
            });
            //this.game.states.switchState('TwoPlayerSettings', MyStates.TwoPlayerSettings, null);
        };

        TrainingSettings.prototype.toTheStore = function () {
            this.panelTopClose.onComplete(function () {
                this.game.states.switchState('StoreMenu', MyStates.StoreMenu, null, { backTo: 'TrainingSettings', data: this.stateData });
            }, this);
            this.closePanels();
        };

        TrainingSettings.prototype.openPanels = function () {
            this.panelTopOpen.start();
            this.panelBottomOpen.start();
        };
        TrainingSettings.prototype.closePanels = function () {
            this.panelTopClose.start();
            this.panelBottomClose.start();
        };
        TrainingSettings.prototype.backButtonHit = function () {
            if (this.panelTopClose.isRunning || this.panelTopOpen.isRunning)
                return;
            this.game.menuSFX.playSuccess();
            this.panelTopClose.onComplete(this.backButtonStart, this);
            this.closePanels();
        };
        TrainingSettings.prototype.backButtonStart = function () {
            this.game.states.switchState('TrainingSetup', MyStates.TrainingSetup, null);
        };
        return TrainingSettings;
    })(Kiwi.State);
    MyStates.TrainingSettings = TrainingSettings;
})(MyStates || (MyStates = {}));
var MyStates;
(function (MyStates) {
    var StoreMenu = (function (_super) {
        __extends(StoreMenu, _super);
        function StoreMenu() {
            _super.call(this, 'StoreMenu');
        }
        StoreMenu.prototype.preload = function () {
            _super.prototype.preload.call(this);
        };

        StoreMenu.prototype.init = function () {
            //Store Launch
            this.purchaseManager = new Managers.PurchaseManager(this.game);
        };

        StoreMenu.prototype.create = function (backTo, stateData) {
            if (typeof backTo === "undefined") { backTo = 'MainMenu'; }
            if (typeof stateData === "undefined") { stateData = {}; }
            _super.prototype.create.call(this);

            this.previousState = backTo;
            this.previousStateData = stateData;

            FlurryAgent.logEvent("Store from " + this.previousState);

            this.parameters = new StandOff.Parameters();

            this.background = new Kiwi.GameObjects.Sprite(this, this.textures.splashBackground, 0, 0);
            this.addChild(this.background);

            this.side1 = new MenuEntities.storeBottom(this, 1, 1);
            this.side1.y = this.game.stage.height / 2;
            this.addChild(this.side1);

            this.side2 = new MenuEntities.storeTop(this, this.purchaseManager, 2, 2);
            this.side2.y = 0;
            this.side2.x = 0;
            this.addChild(this.side2);

            //Panels
            this.middlePanel = new Kiwi.GameObjects.Sprite(this, this.textures.middlePanel, 0, 286);
            this.topPanel = new Kiwi.GameObjects.Sprite(this, this.textures.topPanel, 0, -63);
            this.bottomPanel = new Kiwi.GameObjects.Sprite(this, this.textures.bottomPanel, 0, 485);

            // Panel Tweens
            //Close
            this.panelTopClose = this.game.tweens.create(this.topPanel);
            this.panelBottomClose = this.game.tweens.create(this.bottomPanel);
            this.panelTopClose.to({ y: -63 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomClose.to({ y: 485 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelTopClose.onComplete(this.openPanels, this);

            //Open
            this.panelTopOpen = this.game.tweens.create(this.topPanel);
            this.panelBottomOpen = this.game.tweens.create(this.bottomPanel);
            this.panelTopOpen.to({ y: -601 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomOpen.to({ y: 1023 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);

            this.backButton = new MenuEntities.MenuButton(this, this.textures.backButton, 0, 0);
            this.backButton.x = this.game.stage.width / 2 - this.backButton.width / 2;
            this.backButton.y = this.game.stage.height / 2 - this.backButton.height / 2;
            this.backButton.input.onUp.add(this.backButtonHit, this);
            this.addChild(this.backButton);

            //Layering panels
            this.addChild(this.bottomPanel);
            this.addChild(this.topPanel);

            this.openPanels();
        };

        StoreMenu.prototype.openPanels = function () {
            this.panelTopOpen.start();
            this.panelBottomOpen.start();
        };
        StoreMenu.prototype.closePanels = function () {
            this.panelTopClose.start();
            this.panelBottomClose.start();
        };
        StoreMenu.prototype.backButtonHit = function () {
            if (this.panelTopClose.isRunning || this.panelTopOpen.isRunning)
                return;
            this.panelTopClose.onComplete(this.backButtonStart, this);
            this.game.menuSFX.playSuccess();
            this.closePanels();
        };
        StoreMenu.prototype.backButtonStart = function () {
            this.game.states.switchState(this.previousState, null, null, this.previousStateData);
        };
        return StoreMenu;
    })(Kiwi.State);
    MyStates.StoreMenu = StoreMenu;
})(MyStates || (MyStates = {}));
var MyStates;
(function (MyStates) {
    var StatsMenu = (function (_super) {
        __extends(StatsMenu, _super);
        function StatsMenu() {
            _super.call(this, 'StatsMenu');
            this.max = 20;
            this.offset = 0;
            this.finalOffset = 20;
            this.moreScoresToGet = false;
            this.scrolling = false;
            this.scrollPointer = null;
            this.lastY = 92;
            this.initY = 0;
            this.scrollCoords = {
                min: 352,
                max: 775
            };
        }
        StatsMenu.prototype.create = function () {
            _super.prototype.create.call(this);
            this.parameters = new StandOff.Parameters();

            this.background = new Kiwi.GameObjects.Sprite(this, this.textures.splashBackground, 0, 0);
            this.addChild(this.background);
            this.contentPanel = new Kiwi.GameObjects.Sprite(this, this.textures.leaderboardPanel, 0, 0);
            this.addChild(this.contentPanel);

            //Get current main player
            this.playerName = new Kiwi.GameObjects.Textfield(this, this.game.userManager.currentMainUser.name.toUpperCase(), 110, 127, '#01aef2', 12, 'normal', 'venusRisingFont');
            this.playerWins = new Kiwi.GameObjects.Textfield(this, '---', 329, 127, '#01aef2', 12, 'normal', 'venusRisingFont');
            this.playerLosses = new Kiwi.GameObjects.Textfield(this, '---', 416, 127, '#01aef2', 12, 'normal', 'venusRisingFont');

            this.addChild(this.playerLosses);
            this.addChild(this.playerWins);
            this.addChild(this.playerName);

            //Panels
            this.middlePanel = new Kiwi.GameObjects.Sprite(this, this.textures.middlePanel, 0, 286);
            this.topPanel = new Kiwi.GameObjects.Sprite(this, this.textures.topPanel, 0, -63);
            this.bottomPanel = new Kiwi.GameObjects.Sprite(this, this.textures.bottomPanel, 0, 485);

            // Panel Tweens
            // Close
            this.panelTopClose = this.game.tweens.create(this.topPanel);
            this.panelBottomClose = this.game.tweens.create(this.bottomPanel);
            this.panelTopClose.to({ y: -63 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomClose.to({ y: 485 }, 250, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelTopClose.onComplete(this.openPanels, this);

            //Open
            this.panelTopOpen = this.game.tweens.create(this.topPanel);
            this.panelBottomOpen = this.game.tweens.create(this.bottomPanel);
            this.panelTopOpen.to({ y: -601 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);
            this.panelBottomOpen.to({ y: 1023 }, 500, Kiwi.Animations.Tweens.Easing.Cubic.Out, false);

            this.doneButton = new Kiwi.GameObjects.Sprite(this, this.textures.backButton, 207, 924);
            this.addChild(this.doneButton);

            this.leaderboardGroup = new Kiwi.Group(this);
            this.leaderboardGroup.x = 55;
            this.leaderboardGroup.y = 350;
            this.addChild(this.leaderboardGroup);

            //Scrolling
            this.scrollBar = new Kiwi.GameObjects.Sprite(this, this.textures.scrollbar, 0, this.scrollCoords.min);
            this.scrollBar.x = 732; //X Location of user choice + width of the user choice + padding.
            this.addChild(this.scrollBar);

            //Layering panels
            this.addChild(this.bottomPanel);
            this.addChild(this.topPanel);

            this.game.input.onDown.add(this.pressedInput, this);
            this.game.input.onUp.add(this.releasedInput, this);

            //XHR requests
            this.offset = 0;
            this.finalOffset = this.offset + this.max;
            this.moreScoresToGet = true;

            this.getMoreScores();

            this.openPanels();
        };

        StatsMenu.prototype.updateLeaderboard = function (error, data) {
            if (error || this.game.states.current.name != this.name)
                return;

            var user = null;
            var stat = null;
            var spacing = 2;
            var sub = 0;

            for (var i = 0; i < data.length; i++) {
                user = data[i];

                if (typeof user.data !== "string")
                    continue;

                try  {
                    user.data = JSON.parse(user.data);
                } catch (e) {
                    continue;
                }

                if (this.game.userManager.currentMainUser.isValid && user.user == this.game.userManager.currentMainUser.name) {
                    this.playerWins.text = user.data.wins;
                    this.playerLosses.text = user.data.losses;
                    stat = new MenuEntities.LeaderboardStat(this, i + 1, user, 0, 0, true);
                } else {
                    stat = new MenuEntities.LeaderboardStat(this, i + 1, user, 0, 0, false);
                }

                stat.visible = false;
                this.leaderboardGroup.addChild(stat);
                sub++;
                this.offset++;
            }

            this.repositionUserList();

            //If we got the amount of scores we wanted to, then get some more!!!
            if (this.offset >= this.finalOffset) {
                this.moreScoresToGet = true;
            } else {
                this.moreScoresToGet = false;
            }
        };

        StatsMenu.prototype.getMoreScores = function () {
            if (this.moreScoresToGet) {
                console.log('Get More Scores');
                this.finalOffset = this.offset + this.max;
                this.game.gameDataManager.getGameStats(this.updateLeaderboard, this, this.offset, this.max);
            }
        };

        StatsMenu.prototype.pressedInput = function (x, y, timeUp, timeDown, duration, pointer) {
            //Not currently scrolling and allow to continue
            if (this.scrolling == true)
                return;

            //Overlaps the scrollbar?
            if (this.scrollBar.box.worldHitbox.contains(x, y)) {
                this.startScrolling(pointer);
                return;
            }

            //Does the pointer intersect any userchoice?
            var members = this.leaderboardGroup.members;
            var member = null;
            for (var i = 0; i < members.length; i++) {
                member = members[i];

                if (member.visible && member.background.box.worldHitbox.contains(x, y)) {
                    //Allow the drag
                    this.startScrolling(pointer);
                    break;
                }
            }
        };

        StatsMenu.prototype.releasedInput = function (x, y, timeUp, timeDown, duration, pointer) {
            this.stopScrolling(pointer);

            //Did the user scroll at all? Was the duration held for longer than 500 millisecond and did it move at all?
            if (pointer.duration > 500 || Kiwi.Utils.GameMath.difference(pointer.startPoint.y, pointer.endPoint.y) > 50)
                return;

            if (this.doneButton.box.worldHitbox.contains(x, y)) {
                this.doneButtonHit();
            }
        };

        StatsMenu.prototype.startScrolling = function (pointer) {
            this.scrolling = true;
            this.scrollPointer = pointer;
            this.initY = this.scrollPointer.y;
            this.lastY = this.scrollBar.y;
        };

        StatsMenu.prototype.stopScrolling = function (pointer) {
            if (this.scrollPointer && pointer.id == this.scrollPointer.id) {
                this.scrolling = false;
                this.scrollPointer = null;
            }
        };

        StatsMenu.prototype.update = function () {
            _super.prototype.update.call(this);

            if (this.scrolling) {
                var mouseMovementY = -(this.scrollPointer.y - this.initY);

                //Movement
                this.scrollBar.y = this.lastY;
                this.scrollBar.y += mouseMovementY;

                //Constraints
                if (this.scrollBar.y < this.scrollCoords.min) {
                    this.scrollBar.y = this.scrollCoords.min;
                } else if (this.scrollBar.y > this.scrollCoords.max) {
                    this.scrollBar.y = this.scrollCoords.max;
                }

                //Update
                this.repositionUserList();
            }
        };

        StatsMenu.prototype.repositionUserList = function () {
            var members = this.leaderboardGroup.members;
            var spacing = 2;
            var maxMembers = 14;

            //Get the scrollbars y...
            //Get its percentage in the scrollbar its at.
            var percent = (this.scrollBar.y - this.scrollCoords.min) / (this.scrollCoords.max - this.scrollCoords.min);

            //Convert its percentage on-screen into which part of the user list to view.
            var start = Math.max(0, Math.round((members.length - maxMembers) * percent));
            var end = Math.min(start + maxMembers, start + members.length);
            var member = null;

            var sub = 0;
            for (var i = 0; i < members.length; i++) {
                member = members[i];

                if (i >= start && i < end) {
                    member.y = sub * (member.background.height + spacing);
                    member.visible = true;
                    sub++;
                } else {
                    member.visible = false;
                }
            }

            //If we are showing more than 75% of the scores and the scroll bar is over 75% then get some more!
            if (percent >= 0.75 && Math.round(members.length * 0.5) <= end) {
                this.getMoreScores();
            }
        };

        StatsMenu.prototype.startSettings = function () {
            this.closePanels();
        };

        StatsMenu.prototype.openPanels = function () {
            this.panelTopOpen.start();
            this.panelBottomOpen.start();
        };
        StatsMenu.prototype.closePanels = function () {
            this.game.input.onDown.remove(this.pressedInput, this);
            this.game.input.onUp.remove(this.releasedInput, this);
            this.panelTopClose.start();
            this.panelBottomClose.start();
        };

        StatsMenu.prototype.doneButtonHit = function () {
            if (this.panelTopClose.isRunning || this.panelTopOpen.isRunning)
                return;
            this.game.menuSFX.playSuccess();
            this.panelTopClose.onComplete(this.doneButtonStart, this);
            this.closePanels();
        };
        StatsMenu.prototype.doneButtonStart = function () {
            this.game.states.switchState('MainMenu', MyStates.MainMenu, null);
        };
        return StatsMenu;
    })(Kiwi.State);
    MyStates.StatsMenu = StatsMenu;
})(MyStates || (MyStates = {}));
var Managers;
(function (Managers) {
    var AudioManager = (function () {
        function AudioManager(play) {
            this.play = play;
            this.sfx = [];
            this.addSFX('selectFactorySFX');
            this.addSFX('selectUnitSFX');
            this.addSFX('factoryExplodeSFX');

            this.addSFX('bomberSFX');
            this.addSFX('bombSFX');
            this.addSFX('selectCannonSFX');
            this.addSFX('cannonMGSFX');
            this.addSFX('artillarySFX');

            //this.addSFX('footstepSFX');
            /*//Test tank
            
            this.addSFX('bazookaHitSFX');
            this.addSFX('tankStepSFX');
            this.addSFX('tankRotateSFX');
            //end test tank */
            //TANK SOUND TEST
            this.addSFX('tankStepSFX');

            //UI sfx - tested, works.
            this.addSFX('cannonErrorSFX');
            this.addSFX('cannonEmptySFX');
            this.addSFX('cannonChargedSFX');
            this.addSFX('creditTickSFX');
            this.addSFX('buttonErrorSFX');
            this.addSFX('launchUnitSFX');
            this.addSFX('arrowSFX');
            this.addSFX('readyClickSFX');

            //vehicle deaths
            this.addSFX('vehDieSFX1');
            this.addSFX('vehDieSFX2');
            this.addSFX('vehDieSFX3');

            //apc
            this.addSFX('APCOpenSFX');
            this.addSFX('APCStartSFX');

            //snipe
            this.addSFX('sniperDigDownSFX');
            this.addSFX('sniperDigUpSFX');

            //tank
            this.addSFX('tankStepSFX');
            this.addSFX('tankRotateSFX');

            //shoot
            this.addSFX('infShotSFX1');
            this.addSFX('infShotSFX2');
            this.addSFX('infShotSFX3');
            this.addSFX('vehShotSFX1');
            this.addSFX('vehShotSFX2');
            this.addSFX('vehShotSFX3');

            //shared
            //this.addSFX('explosionBigSFX');
            this.addSFX('explosionMediumSFX');
            this.addSFX('explosionSmallSFX');

            //call ins
            this.addSFX('AlphaTeamSFX');
            this.addSFX('DeployTroopsSFX');
            this.addSFX('HealSFX');

            this.addLoop('bgSFX');
        }
        AudioManager.prototype.init = function () {
            this.playSFX(this.play.bgSFX);
        };

        AudioManager.prototype.addSFX = function (sfx) {
            this.play[sfx] = new Kiwi.Sound.Audio(this.play.game, sfx, 1, false);
            this.sfx.push(this.play[sfx]);
        };

        AudioManager.prototype.addLoop = function (sfx) {
            this.play[sfx] = new Kiwi.Sound.Audio(this.play.game, sfx, 1, true);
            this.sfx.push(this.play[sfx]);
        };

        //Call in handler
        AudioManager.prototype.playSFX = function (sfx) {
            if (sfx == undefined)
                return;
            if (sfx._loop) {
                sfx.play('default', true);
                if (!this.play.parameters.AUDIO_ON) {
                    sfx.mute = true;
                }
            } else {
                if (this.play.parameters.SFX_ON) {
                    sfx.play('default', true);
                }
            }
        };

        AudioManager.prototype.muteAll = function (muteBool) {
            for (var i = 0; i < this.sfx.length; i++) {
                this.sfx[i].mute = muteBool;
            }
        };
        return AudioManager;
    })();
    Managers.AudioManager = AudioManager;
})(Managers || (Managers = {}));
var Managers;
(function (Managers) {
    var ActionManager = (function () {
        function ActionManager() {
            this.actionNum = 0;
            this.waitVar = 0;
            this.currentCallback = '';
        }
        ActionManager.prototype.doAction = function () {
            var levelData = ActionManager.play.actionData;

            //console.log('DO ACTION: ' + levelData[this.actionNum]);
            var myInfo = levelData[this.actionNum];
            if (myInfo[0] === 'end') {
                console.log('stage complete!');
                return;
            }

            var myAction = myInfo[0];

            var waiting = false;

            switch (myAction) {
                case 'doText':
                    if (myInfo[2] == null || myInfo[2] == undefined) {
                        myInfo[2] = myInfo[1];
                    }
                    if (myInfo[3] == undefined) {
                        ActionManager.play.writeMessage(myInfo[2]);
                        this.waitVar = ActionManager.play.playTimer.elapsed() + 5;
                        waiting = true;
                    } else {
                        ActionManager.play.writeMessage(myInfo[2], myInfo[3]);
                        this.waitVar = ActionManager.play.playTimer.elapsed() + myInfo[3];
                        waiting = true;
                    }

                    console.log('TEXT:\nHeading: ', myInfo[1], '\nBody: ', myInfo[2]);
                    break;
                case 'tutorial':
                    if (ActionManager.play.game.playTutorial) {
                        this.currentCallback = 'endTutorial';
                        var cannon = ActionManager.play.nodeButtons.getChildByName('cannon' + 1);
                        cannon.active = true;
                        waiting = true;
                        ActionManager.play.startTutorial();
                    }
                    break;

                case 'cannonType':
                    //machine gun or shell. flare is handled differently, through the action manager directly
                    ActionManager.play.parameters.CANNON_TYPE = myInfo[1];
                    var cannon = ActionManager.play.getChildByName('cannon2');
                    if (cannon != undefined)
                        ActionManager.play.UIManager.selectCannonButton(2, myInfo[1]);
                    break;
                case 'cannonFrequency':
                    ActionManager.play.parameters.CANNON_FREQUENCY = myInfo[1];
                    var cannon = ActionManager.play.getChildByName('cannon2');
                    if (cannon != undefined)
                        cannon.frequency = myInfo[1];
                    break;
                case 'cannonLeeway':
                    var deg = myInfo[1];
                    var rads = deg * (Math.PI / 180);
                    ActionManager.play.parameters.CANNON_LEEWAY = rads;
                    ActionManager.play.parameters.CANNON_DIST_LEEWAY = myInfo[1];
                    var cannon = ActionManager.play.getChildByName('cannon2');
                    if (cannon != undefined)
                        cannon.leeway = rads;
                    break;
                case 'activateCannon':
                    //tag, side, true/false
                    var cannon = ActionManager.play.nodeButtons.getChildByName('cannon' + myInfo[1]);
                    cannon.active = myInfo[2];
                    break;

                case 'activateAutoCannon':
                    //tag, side, true/false
                    ///////////////////////////
                    //TURN OFF AUTO CANNON FIRST INCASE THINGS BREAK // AKA RESET IT BACK TO NORMAL
                    //////////////////////
                    ActionManager.play.cannonManager.turnOnAutoCannon(myInfo[1], myInfo[2], myInfo[3]);
                    break;
                case 'stopAutoFire':
                    //tag, side, true/false
                    var cannon = ActionManager.play.cannon2;
                    ActionManager.play.cannonManager.canAutoFire = false;
                    cannon.active = false;
                    break;
                case 'autoCannonRange':
                    //tag, range
                    ActionManager.play.cannonManager.autoCannonRange = myInfo[1];
                    break;
                case 'autoCannonDuration':
                    //tag, duration
                    ActionManager.play.cannonManager.autoCannonDuration = myInfo[1];
                    break;
                case 'activateCallIns':
                    ActionManager.play.retractTime1 = ActionManager.play.game.time.now();
                    ActionManager.play.callinsActive = true;
                    ActionManager.play.startCallIns();
                    break;
                case 'deactivateCallIns':
                    console.log('DEACTIVATE');
                    ActionManager.play.callinsActive = false;
                    ActionManager.play.hideCallIns(1, false);
                    ActionManager.play.hideCallIns(2, false);
                    var myText = ActionManager.play.supportText1;
                    myText.animation.switchTo('default');
                    myText.animation.switchTo(0);
                    var myText2 = ActionManager.play.supportText2;
                    myText2.animation.switchTo('default');
                    myText2.animation.switchTo(0);
                    break;
                case 'setNodeTypeAvailable':
                    ActionManager.play.UIManager['nodeTypeAvailable_' + myInfo[1] + '_' + myInfo[2]] = myInfo[3];
                    break;
                case 'flare':
                    var cannon = ActionManager.play.getChildByName('cannon2');
                    var prev = cannon.type;
                    cannon.type = 2;
                    var line = new Kiwi.Geom.Line(cannon.returnX(), cannon.returnY(), myInfo[1], myInfo[2]);
                    cannon.rotation = Math.PI - line.angle;
                    cannon.distance = line.length / ActionManager.play.parameters.CANNON_DIST_VAR;
                    ActionManager.play.cannonManager.fireCannon(2);
                    cannon.type = prev;
                    break;

                case 'setUpgradeLimit':
                    ActionManager.play.UIManager["upgradeLimit_" + myInfo[1] + "_" + myInfo[2]] = myInfo[3];
                    break;

                case 'generateNode':
                    ActionManager.play.UIManager.addFactoryButton(myInfo[1], myInfo[2]);
                    break;

                case 'activateNode':
                    ActionManager.play.UIManager.activateNode(myInfo[2], myInfo[1]);

                    break;

                case 'removeNode':
                    ActionManager.play.UIManager.removeNode(myInfo[2], myInfo[1]);
                    break;
                case 'deactivateNode':
                    ActionManager.play.UIManager.deactivateNode(myInfo[2], myInfo[1]);
                    break;
                case 'nodeType':
                    //1 = infantry, veh = 2
                    //0-2 (rif/baz/flame) (apc/snipe/tank)
                    //tag, pos, side, setType, selectType
                    var node = ActionManager.play.nodeButtons.getChildByName('node' + myInfo[2] + '_' + myInfo[1]);

                    //console.log('NODE TYPE:',node,myInfo)
                    if (node != null) {
                        ActionManager.play.UIManager.setNode(node, myInfo[3]);
                        node.selected = myInfo[4];
                        node.updateNode();
                    }
                    break;
                case 'nodeLevel':
                    //level 0-2
                    //tag, pos, side, level selector, value
                    var node = ActionManager.play.nodeButtons.getChildByName('node' + myInfo[2] + '_' + myInfo[1]);
                    if (node != null) {
                        node['level' + myInfo[3]] = myInfo[4];
                        node.updateNode();
                    }
                    break;
                case 'nodeAngle':
                    //tag, pos, side, leeway // angle 0 == down
                    var node = ActionManager.play.nodeButtons.getChildByName('node' + myInfo[2] + '_' + myInfo[1]);
                    if (node != null) {
                        var deg = myInfo[3];
                        var rads = deg * (Math.PI / 180);
                        node.myAngle = rads;
                    }

                    break;
                case 'nodeLeeway':
                    //tag, pos, side, leeway
                    var node = ActionManager.play.nodeButtons.getChildByName('node' + myInfo[2] + '_' + myInfo[1]);
                    if (node != null) {
                        var deg = myInfo[3];
                        var rads = deg * (Math.PI / 180);
                        node.leeway = rads;
                    }
                    break;
                case 'nodeFrequency':
                    //tag, pos, side, freq
                    var node = ActionManager.play.nodeButtons.getChildByName('node' + myInfo[2] + '_' + myInfo[1]);
                    if (node != null) {
                        node.frequency = myInfo[3];
                        node.frequencyVar = 0;
                    }
                    break;
                case 'nodeProgress':
                    //tag, pos, side, perc
                    var node = ActionManager.play.nodeButtons.getChildByName('node' + myInfo[2] + '_' + myInfo[1]);

                    if (node != null) {
                        node.startingProgress = myInfo[3] / 100;
                    }
                    break;
                case 'setColour':
                    ActionManager.play['colour' + myInfo[1]] = myInfo[2];
                    break;
                case 'setCredits':
                    ActionManager.play['p' + myInfo[1] + 'Credits'] = myInfo[2];
                    ActionManager.play.updateCredits(0, myInfo[1]);
                    break;
                case 'addCredits':
                    ActionManager.play['p' + myInfo[1] + 'Credits'] += myInfo[2];
                    ActionManager.play.updateCredits(0, myInfo[1]);
                    break;
                case 'wait':
                    this.waitVar = ActionManager.play.playTimer.elapsed() + myInfo[1];
                    waiting = true;
                    break;
                case 'end':
                    console.log('stage complete!');
                    break;
                case 'prop':
                    ActionManager.play.addProp(myInfo[1], myInfo[2], myInfo[3]);
                    break;

                case 'activateCallins':
                    ActionManager.play.callinsActive = myInfo[1];
                    break;
                case 'callInHeal':
                    ActionManager.play.callIn_2_var = 0;
                    ActionManager.play.callInManager.healCallIn(2, ActionManager.play.mouse.x, ActionManager.play.mouse.y);
                    break;
                case 'callInBombs':
                    ActionManager.play.callIn_2_var = 1;
                    var sx = myInfo[1];
                    var sy = myInfo[2];
                    var ex = myInfo[3];
                    var ey = myInfo[4];
                    ActionManager.play.callInManager.dropBombs(sx, sy, ex, ey, myInfo[5]);
                    break;
                case 'callInHeli':
                    ActionManager.play.callInManager.heliLaunch(myInfo[1], myInfo[2], myInfo[3]);
                    break;
                case 'lock':
                    //available types: Soldiers, Vehicles, Rifleman, Bazooka, Flamer, Tank, Sniper, APC
                    ActionManager.play['locked' + myInfo[1]] = true;
                    break;
                case 'unlock':
                    //side, type
                    ActionManager.play['locked' + myInfo[1]] = false;
                    break;
                case 'spawn':
                    //['spawn', 'bazooka', 2, 1, 100, 200, 10],
                    //releaseFormation(name, level, side, x, y, r)
                    //this.releaseCharacter(name, texture, r, x, y, side, type(0-1), level(1-3), f);
                    //var texture = this.textures[name + '' + (this['colour' + side] + 1)];
                    var deg = myInfo[6];
                    var rads = deg * (Math.PI / 180);
                    var myY = myInfo[5] + ActionManager.play.parameters.GAME_Y;
                    switch (myInfo[1]) {
                        case 'rifleman':
                        case 'bazooka':
                        case 'flameAr':
                            if (myInfo[3] > 1) {
                                //ActionManager.play.releaseFormation(myInfo[1], myInfo[3], myInfo[2], myInfo[4], myY, rads)
                            } else {
                                var texture = ActionManager.play.textures[myInfo[1] + '' + ActionManager.play['colour' + myInfo[2]]];
                                //ActionManager.play.unitManager.releaseCharacter(myInfo[1], texture, rads, myInfo[4], myY, myInfo[2], 0, 1);
                            }
                            break;
                        default:
                            var texture = ActionManager.play.textures[myInfo[1] + '' + ActionManager.play['colour' + myInfo[2]]];

                            break;
                    }
                    break;
                case 'wave':
                    //wait til all is dead
                    ActionManager.play.waitingWave = true;
                    waiting = true;
                    break;
                case 'clearStage':
                    this.endWave();
                    break;

                case 'waitCallback':
                    //wait til you receive a message from the game before progressing
                    this.currentCallback = myInfo[1];
                    waiting = true;
                    break;
                case 'addTokens':
                    ActionManager.play.creditsEarned += myInfo[1];

                    break;
                case 'setCheating':
                    ActionManager.play.parameters.CHEATING = myInfo[1];
                    break;
                case 'clear':
                    ActionManager.play.unitManager.clear();
                    break;
                case 'logEvent':
                    FlurryAgent.logEvent(myInfo[1]);
                    break;
                default:
                    console.log('Incorrect action:', myAction);
                    break;
            }

            if (!waiting) {
                //console.log('action is complete, next action');
                this.stepAction();
            }
        };

        ActionManager.prototype.stepAction = function () {
            this.actionNum++;
            var levelData = ActionManager.play.actionData;
            if (this.actionNum >= levelData.length) {
                console.log('no more actions, stage complete!');
            } else {
                this.doAction();
            }
        };

        ActionManager.prototype.receiveCallback = function (call) {
            //console.log('receive call:',call)
            if (call == this.currentCallback) {
                this.currentCallback = '';
                this.stepAction();
            }
        };

        ActionManager.prototype.endWave = function () {
            ActionManager.play.unitManager.clear();
            for (var i = 0; i < 6; i++) {
                ActionManager.play.UIManager.removeNode(2, i);
            }
            this.stepAction();
        };
        return ActionManager;
    })();
    Managers.ActionManager = ActionManager;
})(Managers || (Managers = {}));
var Managers;
(function (Managers) {
    var CallInManager = (function () {
        function CallInManager(play) {
            this.play = play;
            this.callIns = [];
            this.crates = [];

            //r desides crate type drop type setDrop 0 - 5
            var r = Math.floor(Math.random() * 5) + 1;
            this.setDrop((Math.random() * 500) + 100, play.halfway, r);
        }
        CallInManager.prototype.setAnimating = function (animBool) {
            if (animBool) {
            } else {
            }
        };

        //Call in handler
        CallInManager.prototype.updateCallIns = function () {
            for (var i = this.callIns.length - 1; i >= 0; i--) {
                //bomber this.callIns.push([count, callInType, side, cx, cy, mx, my]);
                var cell = this.callIns[i];

                //console.log(cell);
                if (cell != undefined) {
                    cell[0]++;
                    switch (cell[1]) {
                        case 1:
                            //dropBombs(sx, sy, ex, ey, side)
                            if (cell[0] == this.play.parameters.BOMB_WAIT) {
                                this.dropBombs(cell[3], cell[4], cell[5], cell[6], cell[2]);
                            }
                            break;
                        case 2:
                            //heliDrop(side, hx, hy)
                            if (cell[0] == this.play.parameters.HELI_WAIT) {
                                this.heliLaunch(cell[2], cell[3], cell[4]);
                            }
                            break;
                        case 3:
                            //sendDrop(x, y)
                            if (cell[0] == this.play.parameters.CRATE_WAIT) {
                                this.sendDrop(cell[2], cell[3], cell[4]);
                            }
                            break;
                    }
                }
            }
        };

        //HELI DROP
        CallInManager.prototype.heliCall = function (side, device) {
            //make initial call then wait for copter
            var tokens = this.play['p' + side + 'Tokens0'];
            if (tokens > 0) {
                var mx = device.x;
                var my = device.y;

                if (my < 200 && side == 2) {
                    return;
                }
                if (my > this.play.game.stage.height - 200 && side == 1) {
                    return;
                }

                if (mx < this.play.parameters.HELI_BOUNDS)
                    mx = this.play.parameters.HELI_BOUNDS;
                if (mx > 768 - this.play.parameters.HELI_BOUNDS)
                    mx = 768 - this.play.parameters.HELI_BOUNDS;

                this.callIns.push([0, 2, side, mx, my]);

                this.play.updateTokens(-1, 0, side);
            } else {
                var prev = this.play['callIn_' + side + '_' + (this.play['callIn_' + side + '_var'])];
                prev.animation.switchTo(0);
                this.play['callIn_' + side + '_count'] = -1;
                this.play['callIn_' + side + '_var'] = -1;
            }
        };

        CallInManager.prototype.heliLaunch = function (side, hx, hy) {
            var heli = new StandOffEntities.helicopter(this.play, side, hx, hy, 0, 0);
            this.play.addChild(heli);
            this.play['callIn_' + side + '_count'] = -1;
            this.play['callIn_' + side + '_var'] = -1;

            var base = this.play['callIn_' + side + '_0'];
            if (base != undefined)
                base.animation.switchTo(0);
        };

        CallInManager.prototype.heliDrop = function (side, hx, hy, r) {
            var ang = 0;
            if (side == 1) {
                ang = Math.PI;
            }

            this.play.unitManager.releaseFormation('rifleman', 0, 3, side, hx - 50, hy, ang);
            this.play.unitManager.releaseFormation('rifleman', 0, 3, side, hx + 50, hy, ang);

            var heli = new StandOffEntities.helicopter(this.play, side, hx, hy, r, 3);
            this.play.addChild(heli);
        };

        //BOMBER
        //------
        CallInManager.prototype.releaseChevron = function (side, mx, my) {
            var chevron = this.play.getChildByName('chevron' + side);
            if (chevron == undefined)
                return;
            var chevronOffset = chevron.transform.rotPointX;
            var cx = chevron.x + chevronOffset;
            var cy = chevron.y + chevronOffset;
            var line = new Kiwi.Geom.Line(cx, cy, mx, my);

            var base = this.play['callIn_' + side + '_1'];
            if (base != undefined)
                base.animation.switchTo(0);

            this.play['callIn_' + side + '_x'] = cx;
            this.play['callIn_' + side + '_y'] = cy;
            this.play['bomb_' + side + '_x'] = mx;
            this.play['bomb_' + side + '_y'] = my;
            this.play['callIn_' + side + '_count'] = 0;

            this.play['callIn_' + side + '_var'] = -1;

            this.callIns.push([0, 1, side, cx, cy, mx, my]);

            this.play.removeChild(chevron);

            this.play.updateTokens(-1, 1, side);
        };

        CallInManager.prototype.dropBombs = function (sx, sy, ex, ey, side) {
            //console.log('release chevron', sx, sy, ex, ey)
            var diffX = ex - sx;
            var diffY = ey - sy;
            var line = new Kiwi.Geom.Line(sx, sy, ex, ey);
            var l = line.length;
            if (l > this.play.parameters.RUN_MAX) {
                l = this.play.parameters.RUN_MAX;
            }

            //console.log('LINE:', line)
            diffX = this.play.getSin(line.angle) * l; //this.play.parameters.BOMB_RANGE;
            diffY = this.play.getCos(line.angle) * l; //this.play.parameters.BOMB_RANGE;

            var bomberCount = 1;
            var bombsCount = 4;
            var gapX = diffX / bombsCount;
            var gapY = diffY / bombsCount;
            var rand = 50;
            var delayVar = 50;

            this.play.audioManager.playSFX(this.play.bombSFX);

            for (var i = 0; i < bomberCount; i++) {
                for (var j = 0; j < bombsCount; j++) {
                    var r = Math.random() * rand;
                    var bx = sx + (gapX * j) + r - (r / 2);
                    var by = sy + (gapY * j) + r - (r / 2);
                    var bombEffect = new StandOffEntities.bomb(this.play, this.play.textures['effects' + this.play['colour' + side]], 0, (j * 5) + delayVar, bx, by, side);
                    bombEffect.animation.switchTo('bomberImpact');
                    bombEffect.x -= bombEffect.box.bounds.width / 2;
                    bombEffect.y -= bombEffect.box.bounds.height / 2;
                    bombEffect.transform.rotPointX = bombEffect.box.bounds.width / 2;
                    bombEffect.transform.rotPointY = bombEffect.box.bounds.width / 2;
                    bombEffect.rotation = Math.PI - line.angle;
                    this.play['effects' + side].addChild(bombEffect);
                }
            }

            //run bomber
            var bomber = new StandOffEntities.bomber(this.play, sx, sy, Math.PI - line.angle);
            bomber.animation.play('bomber_' + this.play['colour' + side]);
            bomber.transform.rotPointX = bomber.box.bounds.width / 2;
            bomber.transform.rotPointY = bomber.box.bounds.height / 2;
            bomber.x -= bomber.box.bounds.width / 2;
            bomber.y -= bomber.box.bounds.height / 2;
            bomber.rotation = -line.angle;
            this.play.addChild(bomber);
            this.play.audioManager.playSFX(this.play.bomberSFX);
        };

        CallInManager.prototype.bombHurt = function (bomb) {
            var x = bomb.x + 56;
            var y = bomb.y + 56;
            var side = bomb.side;
            var oppSide = this.play.getOppSide(side);
            var arr = this.play.getSideWithinRadius(x, y, oppSide, this.play.parameters.BOMB_RADIUS);

            for (var i = 0; i < arr.length; i++) {
                var char = arr[i];
                this.play.unitManager.hurtChar(char, bomb[char.constructor.name + 'Splash']);
            }
        };

        //HEAL BEAM
        //---------
        CallInManager.prototype.healCallIn = function (side, mx, my) {
            var tokens = this.play['p' + side + 'Tokens2'];
            if (tokens > 0) {
                this.play['callIn_' + side + '_var'] = -1;
                var base = this.play['callIn_' + side + '_2'];
                if (base != undefined)
                    base.animation.switchTo(0);

                this.play['clickTarget' + side] = '';

                //if within the build node area
                if ((side == 1 && my > 824) || (side == 2 && my < 200)) {
                    return;
                }

                //place brief heal beam graphic effect
                this.play['healBeam' + side] = new StandOffEntities.effect(this.play, this.play.textures['effects' + this.play['colour' + side]], 0, mx - 125, my - 125);
                this.play['healBeam' + side].animation.switchTo('healBeam', true);
                this.play['healBeam' + side].transform.rotPointX = 125;
                this.play['healBeam' + side].transform.rotPointY = 125;
                if (side == 2) {
                    this.play['healBeam' + side].rotation = Math.PI;
                }
                this.play['effects' + side].addChild(this.play['healBeam' + side]);

                //get all within radius and add health
                var arr = this.play.getSideWithinRadius(mx, my, side, 65);
                for (var i = 0; i < arr.length; i++) {
                    this.play.unitManager.healChar(arr[i], this.play.parameters.HEAL_SHOT);
                }

                this.play.updateTokens(-1, 2, side);

                this.play.audioManager.playSFX(this.play.HealSFX);
            }
        };

        //CRATES
        //------
        CallInManager.prototype.setDrop = function (dx, dy, dt) {
            this.callIns.push([0, 3, dx, dy, dt]);
        };

        //send dropper out
        CallInManager.prototype.sendDrop = function (dx, dy, dt) {
            var dropRotation = Math.random() * (Math.PI * 2);

            var dropEffect = new StandOffEntities.crateDrop(this.play, this.play.textures.crate, 0, 50, dx, dy, dt);

            //state: MyStates.Play, textureID: any, r:number, delay: number, x: number, y: number
            this.play.addChild(dropEffect);

            var dropper = new StandOffEntities.dropper(this.play, dx, dy, dropRotation);
            this.play.addChild(dropper);
        };

        //after crate drop anim, the effect calls this from crateDrop.ts
        CallInManager.prototype.placeCrate = function (dx, dy, dt) {
            var crate = new StandOffEntities.crate(this.play, this.play.textures.crate, dx, dy);
            this.play.effects1.addChild(crate);
            var pog = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.pog, dx, dy);
            pog.animation.currentAnimation.play();
            this.play.effects1.addChild(pog);
            crate.pog = pog;

            var reward = new Kiwi.GameObjects.Sprite(this.play, this.play.textures['reward' + dt], dx, dy);
            reward.animation.add('anim', [0, 1, 2, 3, 4, 4, 4, 4, 3, 2, 1, 0, 5, 6, 7, 8, 9, 9, 9, 9, 8, 7, 6, 5], 0.1, true, true);
            this.play.effects1.addChild(reward);
            crate.rewardAnim = reward;

            crate.reward = dt;
            this.crates.push(crate);
        };

        CallInManager.prototype.collectCrate = function (crate, side) {
            switch (crate.reward) {
                case 1:
                    this.play.updateCredits(25, side);
                    break;
                case 2:
                    this.play.updateCredits(50, side);
                    break;
                case -1:
                    this.play.updateCredits(100, side);
                    break;
                case 3:
                    //give an extra heli drop
                    this.play.updateTokens(1, 0, side);
                    break;
                case 4:
                    //give an extra bomb drop
                    this.play.updateTokens(1, 1, side);
                    break;
                case 5:
                    //give an extra heal
                    this.play.updateTokens(1, 2, side);
                    break;
                default:
                    console.log('CallInManager Error: incorrect crate variable:', crate.reward);

                    break;
            }

            if (this.play.callInsStarted) {
                this.play.startCallIns();
            }

            this.play.removeChild(crate.pog);
            crate.pog.destroy();

            this.play.removeChild(crate.rewardAnim);
            crate.rewardAnim.destroy();

            this.play.removeChild(crate);
            crate.destroy();
        };

        CallInManager.prototype.updateCrates = function () {
            for (var i = this.crates.length - 1; i >= 0; i--) {
                var crate = this.crates[i];
                for (var j = 1; j <= 2; j++) {
                    var soldiers = this.play['soldiers' + j];
                    var vehicles = this.play['vehicles' + j];

                    for (var k = 0; k < soldiers.length; k++) {
                        if (this.checkCrateCollide(crate, soldiers[k])) {
                            this.crates.splice(i, 1);
                            this.collectCrate(crate, j);
                            break;
                        }
                    }
                    for (var k = 0; k < vehicles.length; k++) {
                        if (this.checkCrateCollide(crate, vehicles[k])) {
                            this.crates.splice(i, 1);
                            this.collectCrate(crate, j);
                            break;
                        }
                    }
                }
            }
        };

        CallInManager.prototype.checkCrateCollide = function (c, e) {
            var dist = 40;
            var ex = e.returnX();
            var ey = e.returnY();
            var cx = c.my_x;
            var cy = c.my_y;
            if (cx > e.x - dist) {
                if (cx < e.x + dist) {
                    if (cy > e.y - dist) {
                        if (cy < e.y + dist) {
                            return true;
                        }
                    }
                }
            }
            return false;
        };
        return CallInManager;
    })();
    Managers.CallInManager = CallInManager;
})(Managers || (Managers = {}));
var Managers;
(function (Managers) {
    var UIManager = (function () {
        function UIManager(play) {
            //inf
            this.nodeTypeAvailable_0_1 = true;
            this.nodeTypeAvailable_1_1 = true;
            this.nodeTypeAvailable_2_1 = true;
            //veh
            this.nodeTypeAvailable_0_2 = true;
            this.nodeTypeAvailable_1_2 = true;
            this.nodeTypeAvailable_2_2 = true;
            this.upgradeLimit_1_0 = 0;
            this.upgradeLimit_1_1 = 0;
            this.upgradeLimit_1_2 = 0;
            this.upgradeLimit_2_0 = 0;
            this.upgradeLimit_2_1 = 0;
            this.upgradeLimit_2_2 = 0;
            console.log('UI CREATED');
            this.play = play;
            this.createHex(1);
            this.createHex(2);
            this.createWarning(1);
            this.createWarning(2);

            //this.createUI();
            this.upgradeLimit_1_0 = this.play.parameters.NODE_UPGRADE_LIMIT;
            this.upgradeLimit_1_1 = this.play.parameters.NODE_UPGRADE_LIMIT;
            this.upgradeLimit_1_2 = this.play.parameters.NODE_UPGRADE_LIMIT;
            this.upgradeLimit_2_0 = this.play.parameters.NODE_UPGRADE_LIMIT;
            this.upgradeLimit_2_1 = this.play.parameters.NODE_UPGRADE_LIMIT;
            this.upgradeLimit_2_2 = this.play.parameters.NODE_UPGRADE_LIMIT;
        }
        UIManager.prototype.createUI = function () {
            var UI_1 = new Kiwi.GameObjects.StaticImage(this.play, this.play.textures['nodeButtons' + this.play.colour1]);
            UI_1.cellIndex = 16;
            UI_1.name = 'UI_1';
            UI_1.transform.rotPointX = UI_1.box.bounds.width / 2;
            UI_1.transform.rotPointY = UI_1.box.bounds.height / 2;
            UI_1.rotation = Math.PI;
            UI_1.y = 760;
            this.play.nodeButtons.addChild(UI_1);

            var UI_2 = new Kiwi.GameObjects.StaticImage(this.play, this.play.textures['nodeButtons' + this.play.colour2]);
            UI_2.cellIndex = 16;
            UI_2.name = 'UI_2';
            this.play.nodeButtons.addChild(UI_2);
            this.addConsole(1);
            this.addConsole(2);

            for (var i = 0; i < 3; i++) {
                //cannon buttons
                var cb = new StandOffEntities.selectButton(this.play, this.play.textures['nodeButtons' + this.play.colour1], 319 + (45 * i), 899, 1, i);
                cb.animation.switchTo('cannonBtn');
                cb.name = 'cb_1_' + i;
                cb.clickType = 'cannonButton';
                this.play.clickables1.push(cb);
                this.play.nodeButtons.addChild(cb);
                cb.animation.switchTo(4 * i);

                var cb2 = new StandOffEntities.selectButton(this.play, this.play.textures['nodeButtons' + this.play.colour2], 409 - (45 * i), 60, 2, i);
                cb2.animation.switchTo('cannonBtn');
                cb2.name = 'cb_2_' + i;
                cb2.transform.rotPointX = cb2.box.bounds.width / 2;
                cb2.transform.rotPointY = cb2.box.bounds.height / 2;
                cb2.rotation = Math.PI;
                cb2.clickType = 'cannonButton';
                this.play.clickables2.push(cb2);
                this.play.nodeButtons.addChild(cb2);
                cb2.animation.switchTo(4 * i);
            }

            this.createFactoryButtons();

            for (var i = 1; i <= 4; i++) {
                this.play['credit1Num' + i] = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.consoleButtons, (350 + (18 * (i - 1))), 990);
                this.play.consoleButtons.addChild(this.play['credit1Num' + i]);
                this.play['credit1Num' + i].animation.switchTo('creditNumbers');

                this.play['credit2Num' + i] = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.consoleButtons, (400 - (18 * (i - 1))), 20);
                this.play.consoleButtons.addChild(this.play['credit2Num' + i]);
                this.play['credit2Num' + i].animation.switchTo('creditNumbers');
                this.play['credit2Num' + i].transform.rotPointX = this.play['credit2Num' + i].box.bounds.width / 2;
                this.play['credit2Num' + i].transform.rotPointY = this.play['credit2Num' + i].box.bounds.height / 2;
                this.play['credit2Num' + i].rotation += Math.PI;
            }

            //this.play.p1Credits = -1;
            //console.log('set default credits:', this.play.p1Credits)
            //if (this.play.p1Credits == -1) {
            this.play.p1Credits = this.play.parameters.P1_CREDITS;
            this.play.p2Credits = this.play.parameters.P2_CREDITS;

            //}
            this.play.updateCredits(0, 1);
            this.play.updateCredits(0, 2);

            this.play.pauseBtn1 = new StandOffEntities.selectButton(this.play, this.play.textures.consolePauseBtn, 436, 986, 1, 0);
            this.play.pauseBtn1.clickType = 'pauseButton';
            this.play.clickables1.push(this.play.pauseBtn1);
            this.play.addChild(this.play.pauseBtn1);
            this.play.pauseBtn1.input.onDown.add(this.depressed);

            this.play.pauseBtn2 = new StandOffEntities.selectButton(this.play, this.play.textures.consolePauseBtn, 310, 18, 2, 0);
            this.play.pauseBtn2.clickType = 'pauseButton';
            this.play.clickables2.push(this.play.pauseBtn2);
            this.play.addChild(this.play.pauseBtn2);
            this.play.pauseBtn2.input.onDown.add(this.depressed);

            //CANNON
            //selected cannon overlay
            var overlay1 = new Kiwi.GameObjects.Sprite(this.play, this.play.textures['nodeButtons' + this.play.colour1], 304, 756);
            overlay1.name = 'canonOverlay_1';
            overlay1.animation.switchTo('canonOverlay');
            overlay1.visible = false;
            this.play.nodeButtons.addChild(overlay1);

            var overlay2 = new Kiwi.GameObjects.Sprite(this.play, this.play.textures['nodeButtons' + this.play.colour2], 303, 53);
            overlay2.name = 'canonOverlay_2';
            overlay2.animation.switchTo('canonOverlay');
            overlay2.visible = false;
            overlay2.transform.rotPointX = overlay2.box.bounds.width / 2;
            overlay2.transform.rotPointY = overlay2.box.bounds.height / 2;
            overlay2.rotation = Math.PI;
            this.play.nodeButtons.addChild(overlay2);

            //progress circle
            var c1 = new Kiwi.GameObjects.Sprite(this.play, this.play.textures['nodeButtons' + this.play.colour1], 314, 765);
            c1.animation.switchTo('cannonCircle');
            c1.name = 'circle1';
            this.play.nodeButtons.addChild(c1);

            var c2 = new Kiwi.GameObjects.Sprite(this.play, this.play.textures['nodeButtons' + this.play.colour2], 314, 126);
            c2.animation.switchTo('cannonCircle');
            c2.name = 'circle2';
            c2.transform.rotPointX = c2.box.bounds.width / 2;
            c2.transform.rotPointY = c2.box.bounds.height / 2;
            c2.rotation = Math.PI;
            this.play.nodeButtons.addChild(c2);

            this.play.cannonManager.addCannon(1, 1, Math.PI, false);
            this.play.cannonManager.addCannon(2, 1, 0, false);

            this.selectCannonButton(1, 0);
            this.selectCannonButton(2, 0);

            this.addSupport();

            this.play.hideCallIns(1, false);
            this.play.hideCallIns(2, false);
        };

        //callin hex
        UIManager.prototype.createHex = function (side) {
            this.play['hex' + side] = new Kiwi.Group(this.play);
            var hex = this.play['hex' + side];
            this.play.addChild(hex);

            if (side == 1) {
                for (var i = 0; i <= 12; i++) {
                    var t = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.hex, i * 60, this.play.parameters.HALFWAY - 10);
                    t.animation.switchTo(this.play.colour1 - 1);
                    hex.addChild(t);
                    var border = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.hexBorder, i * 60, this.play.parameters.HALFWAY - 10);
                    border.animation.switchTo(this.play.colour2 - 1);
                    hex.addChild(border);
                }
            } else {
                for (var i = 0; i <= 13; i++) {
                    var t = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.hex, (i * 60) - 50, 0);
                    t.animation.switchTo(this.play.colour2 - 1);
                    t.transform.rotation += Math.PI;
                    hex.addChild(t);
                    var border = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.hexBorder, i * 60 - 50, 505);
                    border.animation.switchTo(this.play.colour1 - 1);
                    border.transform.rotation += Math.PI;
                    hex.addChild(border);
                }
            }
            this.showHex(side, false);
        };

        UIManager.prototype.showHex = function (side, vis) {
            var hex = this.play['hex' + side];

            for (var i = 0; i < hex.members.length; i++) {
                hex.members[i].visible = vis;
            }
        };

        UIManager.prototype.createWarning = function (side) {
            this.play['warning' + side] = new Kiwi.Group(this.play);
            var warning = this.play['warning' + side];
            this.play.addChild(warning);
            if (side == 1) {
                for (var i = 0; i <= 12; i++) {
                    var t = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.bottomHex, i * 60, 736);
                    t.animation.switchTo(this.play.colour1 - 1);
                    warning.addChild(t);
                }
            } else {
                for (var i = 0; i <= 12; i++) {
                    var t = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.bottomHex, i * 60, 180);
                    t.animation.switchTo(this.play.colour2 - 1);
                    t.rotation = Math.PI;
                    warning.addChild(t);
                }
            }
            this.showWarning(side, false);
        };

        UIManager.prototype.showWarning = function (side, vis) {
            var warning = this.play['warning' + side];
            for (var i = 0; i < warning.members.length; i++) {
                warning.members[i].visible = vis;
            }
        };

        UIManager.prototype.checkWarning = function (side) {
            //clip.myTarget
            var oppSide = this.play.getOppSide(side);
            for (var i = 0; i < this.play['soldiers' + oppSide].length; i++) {
                var e = this.play['soldiers' + oppSide][i];
                if (e.myTarget != undefined && e.alive) {
                    return;
                }
            }
            this.showWarning(side, false);
        };

        UIManager.prototype.createFactoryButtons = function () {
            for (var i = 0; i < 3; i++) {
                //player 1
                this.addFactoryButton(i, 1);
                this.addFactoryButton(i + 3, 1);

                //player 2
                if (this.play.players == 2) {
                    this.addFactoryButton(i, 2);
                    this.addFactoryButton(i + 3, 2);
                }
            }
        };

        UIManager.prototype.addFactoryButton = function (num, side) {
            //console.log('add num side',num,side)
            var nodeGap = 100;
            var lPos = 22;
            var rPos = 461;
            var uPos = 124;
            var dPos = 820;

            var myX = lPos + (num * nodeGap);
            var myY = dPos;

            if (num >= 3)
                myX = rPos + ((num - 3) * nodeGap);
            if (side == 2)
                myY = uPos;

            this.play['node' + side + '_' + num + '_base'] = new StandOffEntities.buildNodeBase(this.play, this.play.textures['nodeButtons' + this.play['colour' + side]], myX - 8, myY - 75, side, num);
            this.play.nodeButtons.addChild(this.play['node' + side + '_' + num + '_base']);
            if (this.play.players >= side)
                this.play['clickables' + side].push(this.play['node' + side + '_' + num + '_base']);

            this.play['node' + side + '_' + num] = new StandOffEntities.buildNode(this.play, this.play.textures, this.play['colour' + side], myX, myY, side, num);
            this.play.nodeButtons.addChild(this.play['node' + side + '_' + num]);

            this.play['node' + side + '_' + num].build();

            if (side == 2) {
                this.play['node' + side + '_' + num + '_base'].transform.rotPointX = this.play['node' + side + '_' + num + '_base'].box.bounds.width / 2;
                this.play['node' + side + '_' + num + '_base'].transform.rotPointY = this.play['node' + side + '_' + num + '_base'].box.bounds.height / 2;
                this.play['node' + side + '_' + num + '_base'].transform.y += 80;
                this.play['node' + side + '_' + num].rotateNode();
                if (this.play.players == 1) {
                    this.play['node' + side + '_' + num].auto = true;
                }
            }
        };

        UIManager.prototype.resetSelectButtonFrames = function (node) {
            var credits = this.play['p' + node.side + 'Credits'];
            var highlight = this.play.consoleButtons.getChildByName('consoleButtonHighlight' + node.side);
            var curr;
            for (var i = 0; i < 3; i++) {
                var f = 0;
                var myLevel = node['level' + i];

                //infantry/ mech(1 or 2), type (0-2), level (0-2)
                //rifleman
                //COST_1_0_0 = 10;
                var myCost = this.play.parameters['COST_' + node.type + '_' + i + '_' + myLevel];
                var afford = true;

                //cant afford, go back one
                if (credits < myCost && !this.play.parameters.CHEATING) {
                    afford = false;
                }

                if (myLevel == 0) {
                    if (afford) {
                        f = 1;
                    }
                } else {
                    if (myLevel == 1) {
                        if (afford) {
                            f = 4;
                        } else {
                            f = 2;
                        }
                    } else if (myLevel == 2) {
                        if (afford) {
                            f = 8;
                        } else {
                            f = 6;
                        }
                    } else if (myLevel == 3) {
                        f = 10;
                    }
                    if (node.selected == i) {
                        f++;
                    }
                }

                f += i * 12;

                var myString = 'fbo_' + i + '_' + node.side;
                var clip = this.play.consoleButtons.getChildByName(myString);
                if (clip != null) {
                    clip.animation.switchTo(f);
                    if (highlight != undefined) {
                        if (clip.transform.x == highlight.transform.x) {
                            curr = clip;
                        }
                    }
                } else {
                }
            }

            //if an upgrade btn exists, update
            var confirmBtn = this.play.consoleButtons.getChildByName('confirmBtn' + node.side);
            if (confirmBtn != undefined) {
                if (confirmBtn.animation.frameIndex == 6) {
                    var confirmCost = this.play.parameters['COST_' + node.type + '_' + curr.pos + '_' + (node['level' + curr.pos])];

                    //node type is0, make it barrack/mech cost
                    //Check if you can upgrade node past current level. If not set animation to 6
                    //upgrade button animation updage below
                    if (credits >= confirmCost) {
                        confirmBtn.animation.switchTo(8);
                        this.play['clickables' + node.side].push(confirmBtn);
                        confirmBtn.clickType = 'confirmUpgrade';
                    }
                }
                var canUpgrade = true;
                var buildNode = this.play['selectedNode' + curr.side];
                if (buildNode["level" + curr.pos] >= this["upgradeLimit_" + buildNode.type + "_" + curr.pos]) {
                    canUpgrade = false;
                }
                if (!canUpgrade) {
                    confirmBtn.animation.switchTo(6);
                }
            }
        };

        //CONSOLE
        UIManager.prototype.addConsole = function (side) {
            //add base
            var base = new Kiwi.GameObjects.Sprite(this.play, this.play.textures['nodeButtons' + this.play['colour' + side]], 0, 896);
            base.name = 'consoleBG' + side;
            base.animation.switchTo('consoleBG');

            //this.play[bgName].animation.add('popConsole', [0, 1, 2, 3, 4, 5], 0.04, false, false);
            //this.play[bgName].animation.add('hideConsole', [4, 3, 2, 1, 0], 0.04, false, false);
            this.play.nodeButtons.addChild(base);
            if (side == 2) {
                base.transform.rotPointX = base.box.bounds.width / 2;
                base.transform.rotPointY = base.box.bounds.height / 2;
                base.transform.y = 0;
                base.rotation = Math.PI;
            }
        };

        UIManager.prototype.updateConsole = function (side) {
            //update type select
            var curr = this.play['clickTarget' + side];
            var node = this.play['selectedNode' + side];

            var soldierBtn = this.play.consoleButtons.getChildByName('soldierBtn' + side);
            if (soldierBtn != undefined) {
                var infCost = this.play.parameters.INFANTRY_COST;
                var confirmBtn = this.play.consoleButtons.getChildByName('confirmBtn' + side);
                if (infCost <= this.play['p' + side + 'Credits']) {
                    soldierBtn.animation.switchTo(3);
                } else {
                    soldierBtn.animation.switchTo(2);
                }

                var mechBtn = this.play.consoleButtons.getChildByName('mechBtn' + side);
                if (mechBtn != null) {
                    var mechCost = this.play.parameters.VEHICLE_COST;
                    if (mechCost <= this.play['p' + side + 'Credits']) {
                        mechBtn.animation.switchTo(1);
                    } else {
                        mechBtn.animation.switchTo(0);
                    }
                }

                //colourize confirm button
                //find pos of frame to indicate which is selected
                var highlight = this.play.consoleButtons.getChildByName('consoleButtonHighlight' + side);
                if (highlight != undefined && confirmBtn != null) {
                    if (highlight.transform.x == soldierBtn.transform.x) {
                        if (infCost <= this.play['p' + side + 'Credits']) {
                            confirmBtn.animation.switchTo(2);
                            confirmBtn.clickType = 'confirmYes';
                        } else {
                            confirmBtn.animation.switchTo(0);
                        }
                    } else {
                        if (mechCost <= this.play['p' + side + 'Credits']) {
                            confirmBtn.animation.switchTo(2);
                            confirmBtn.clickType = 'confirmYes';
                        } else {
                            confirmBtn.animation.switchTo(0);
                        }
                    }
                }
            } else if (this.play.consoleButtons.getChildByName('consoleTextUnit') != undefined) {
                if (this.play['selectedNode' + side] != undefined)
                    this.resetSelectButtonFrames(this.play['selectedNode' + side]);
                //var myString: string = 'fbo_' + num + '_' + node.side; 0-2
            }
        };

        UIManager.prototype.popConsole = function (side) {
            var bg = this.play.nodeButtons.getChildByName('consoleBG' + side);
            var cf = bg.animation.frameIndex;
            if (bg.animation.currentAnimation.name == 'hideConsole' && cf == 0) {
                bg.animation.switchTo('popConsole');
                bg.animation.switchTo(6);
                bg.animation.play();
            } else if (cf != 5) {
                bg.animation.switchTo('popConsole');
                bg.animation.play();
            }
        };

        UIManager.prototype.removeConsole = function (side) {
            this.play.removeClickable(this.play.consoleButtons.getChildByName('soldierBtn' + side), side);
            this.play.removeClickable(this.play.consoleButtons.getChildByName('mechBtn' + side), side);

            var confirmBtn = this.play.consoleButtons.getChildByName('confirmBtn' + side);
            if (confirmBtn != undefined) {
                confirmBtn.input.onDown.remove(this.depressedGreen);
                this.play.removeClickable(confirmBtn, side);
            }
            var miscText = this.play.consoleButtons.getChildByName('consoleTextMisc' + side);
            if (miscText != undefined) {
                miscText.destroy();
            }

            var unitText = this.play.consoleButtons.getChildByName('consoleTextUnit' + side);
            if (unitText != undefined) {
                unitText.destroy();
            }

            var portrait = this.play.consoleButtons.getChildByName('consolePortrait' + side);
            if (portrait != undefined) {
                portrait.destroy();
            }

            var highlight = this.play.consoleButtons.getChildByName('consoleButtonHighlight' + side);
            if (highlight != undefined) {
                highlight.destroy();
            }
        };

        //CANNON BUTTONS
        UIManager.prototype.selectCannonButton = function (side, num) {
            //change to reveal cb options
            var cannon = this.play.nodeButtons.getChildByName('cannon' + side);
            cannon.warming = false;
            if (cannon.type == 1) {
                if (cannon.firing) {
                    return;
                }
            }

            //not currently selected, so change cannon
            if ((cannon.type - 1) != num) {
                var auto = cannon.auto;
                var r = cannon.rotation;

                //previous progress
                var prevProg = cannon.charge;
                var prevTotal = cannon.total;

                //new max
                var tot;
                if (num == 0) {
                    tot = this.play.parameters.CANNON_MG_WARM_TIME;
                } else if (num == 1) {
                    tot = this.play.parameters.CANNON_SHELL_WARM_TIME;
                } else {
                    tot = this.play.parameters.CANNON_FLARE_WARM_TIME;
                }

                //cannon.charge = tot * (prevProg / 100);
                var newCharge = cannon.charge;

                this.play.cannonManager.removeCannon(side);

                this.play.cannonManager.addCannon(side, num + 1, r, auto);
                var cannon = this.play.nodeButtons.getChildByName('cannon' + side);
                cannon.charge = newCharge;

                //if (cannon.charge > cannon.total) cannon.charge = cannon.total;
                var newProg = (cannon.charge / cannon.total) * 100;
                cannon.updateProgress(newProg);
                cannon.cannonClip.animation.switchTo('cannon_warmup_' + cannon.type);
                cannon.cannonClip.animation.switchTo(0);
                if (newProg < 100) {
                    cannon.cannonClip.animation.stop();
                    cannon.pullback.animation.switchTo('cannonOverlayInactive');
                } else {
                    cannon.cannonClip.animation.play();
                    cannon.pullback.animation.switchTo('cannonOverlayReady');
                    cannon.pullback.animation.play();
                }

                //cannon.pullback.animation.switchTo(0);
                //cannon.pullback.animation.play();
                this.play.audioManager.playSFX(this.play.selectCannonSFX);

                this.setCannonButtons(side);
            }
        };

        UIManager.prototype.setCannonButtons = function (side) {
            var cannon = this.play.nodeButtons.getChildByName('cannon' + side);
            var cb = this.play.nodeButtons.getChildByName('cb_' + side + '_' + (cannon.type - 1));

            for (var i = 0; i < 3; i++) {
                var c = this.play.nodeButtons.getChildByName('cb_' + side + '_' + i);
                c.animation.switchTo(i * 4);
            }

            //set current
            cb.animation.switchTo(cb.animation.frameIndex + 1);

            //set available buttons
            if (cannon.charge >= this.play.parameters.CANNON_MG_WARM_TIME) {
                var cb1 = this.play.nodeButtons.getChildByName('cb_' + side + '_0');
                cb1.animation.switchTo(cb1.animation.frameIndex + 2);
            }
            if (cannon.charge >= this.play.parameters.CANNON_SHELL_WARM_TIME) {
                var cb2 = this.play.nodeButtons.getChildByName('cb_' + side + '_1');
                cb2.animation.switchTo(cb2.animation.frameIndex + 2);
            }
            if (cannon.charge >= this.play.parameters.CANNON_FLARE_WARM_TIME) {
                var cb3 = this.play.nodeButtons.getChildByName('cb_' + side + '_2');
                cb3.animation.switchTo(cb3.animation.frameIndex + 2);
            }
        };

        UIManager.prototype.addCannonSelect = function (cannon) {
            for (var i = 0; i < 3; i++) {
                //add type selection
                this.addCannonSelectButton(cannon, i);
            }
        };

        UIManager.prototype.addCannonSelectButton = function (cannon, num) {
            if (side > this.play.players)
                return;
            var side = cannon.side;

            var myString = 'cannonMG';
            if (cannon.type == 1) {
                myString = 'cannonShell';
            }
            if (side == 1) {
                this.play[myString] = new StandOffEntities.selectButton(this.play, this.play.textures[myString], (32 + num * 100), 945, side, num);
            } else {
                this.play[myString] = new StandOffEntities.selectButton(this.play, this.play.textures[myString], this.play.game.stage.width - ((32 + num * 100) - 65), 19, side, num);
                this.play[myString].rotation = Math.PI;
            }
            this.play[myString].name = myString + '_' + cannon.side + '_' + num;
            this.play.addChild(this.play[myString]);
            this[myString].clickType = 'cannonButton';
            this['clickables' + side].push(this.play[myString]);
        };

        //NODE/FACTORY (same thing really)
        UIManager.prototype.selectNode = function (curr) {
            if (curr.side > this.play.players)
                return;

            this.play.audioManager.playSFX(this.play.selectUnitSFX);

            var buildNode = this.play['node' + curr.side + '_' + curr.pos];
            if (this.play['arrow' + curr.side] != null) {
                if (this.play['arrow' + curr.side].parent != null) {
                    //release soldier and remove arrow
                    if (buildNode.ready && this.play['arrow' + curr.side].animation.currentAnimation.frameIndex > 0) {
                        this.releaseNode(buildNode);
                    }
                    this.play.removeChild(this.play['arrow' + curr.side]);
                    this.play['arrow' + curr.side] = null;
                    buildNode.arrowing = false;

                    ///////////////////////////////////
                    //Uncomment this line of code to enable the base to be selected easily when it is ready to launch a unit or 'has an arrow'
                    if (this.play.parameters.AUTO_SELECT_NODE) {
                        this.selectNode(curr);
                    }
                    return;
                }
            }

            if (this.play['selectedNode' + curr.side] == buildNode) {
                /*this.deselectNode(curr);
                var bg = <Kiwi.GameObjects.Sprite> this.play.nodeButtons.getChildByName('consoleBG' + curr.side);
                bg.animation.switchTo('hideConsole');
                bg.animation.play();*/
                return;
            }
            if (this.play['selectedNode' + curr.side] != null) {
                this.deselectNode(this.play['selectedNode' + curr.side]);
            }
            this.play['selectedNode' + curr.side] = buildNode;
            buildNode.selectNode();

            switch (buildNode.type) {
                case 0:
                    this.addTypeSelect(buildNode);
                    break;
                case 1:
                case 2:
                    this.addBarrackSelect(buildNode);
                    break;
                default:
                    break;
            }

            this.play.actionManager.receiveCallback('selectNode');
        };

        UIManager.prototype.setNode = function (node, type) {
            if (type == 1) {
                if (this.play['p' + node.side + 'Credits'] < this.play.parameters.INFANTRY_COST && !this.play.parameters.CHEATING) {
                    if (node.side == 2 && this.play.players == 1) {
                    } else {
                        return;
                    }
                }
                this.play.updateCredits(-this.play.parameters.INFANTRY_COST, node.side);
            } else if (type == 2) {
                if (this.play['p' + node.side + 'Credits'] < this.play.parameters.VEHICLE_COST && !this.play.parameters.CHEATING) {
                    if (node.side == 2 && this.play.players == 1) {
                    } else {
                        return;
                    }
                }
                this.play.updateCredits(-this.play.parameters.VEHICLE_COST, node.side);
            }
            var buildNodeBase = this.play['node' + node.side + '_' + node.pos + '_base'];

            node.myType.alpha = 1;
            node.type = type;
            if (type == 1) {
                node.myBarracks.alpha = 1;
                buildNodeBase.animation.switchTo('fbDoorBarrack');
            } else {
                node.myMech.alpha = 1;
                buildNodeBase.animation.switchTo('fbDoorMech');
            }
            buildNodeBase.animation.play();
            node.updateNode();
        };

        UIManager.prototype.releaseNode = function (node) {
            //need to find out what type of char you release
            var nodeName = '';
            var count = 1;
            if (node.type == 1) {
                count = node['level' + node.selected];
                switch (node.selected) {
                    case 1:
                        nodeName = 'bazooka';
                        break;
                    case 2:
                        nodeName = 'flamer';
                        break;
                    default:
                        nodeName = 'rifleman';
                        break;
                }
            } else if (node.type == 2) {
                switch (node.selected) {
                    case 1:
                        nodeName = 'sniper';
                        break;
                    case 2:
                        nodeName = 'tank';
                        break;
                    default:
                        nodeName = 'apc';
                        break;
                }
            }

            if (nodeName == '') {
                console.log('\n***DATA NOTICE***\nIncorrect node data: type (1 or 2) =', node.type, 'selected:(0-2) =', node.selected, '\n');
                return;
            }

            //this.releaseNodeChar(node, nodeName, this['mouseStartX' + node.side], this['mouseStartY' + node.side]);
            var r;
            if (node.auto) {
                r = node.myAngle;
                var rand = (Math.random() * (node.leeway * 2)) - node.leeway;
                r += rand;

                this.play.mouseStartX2 = node.returnX();
                this.play.mouseStartY2 = node.returnY();
            } else {
                if (this.play['arrow' + node.side] != undefined) {
                    r = this.play['arrow' + node.side].rotation - Math.PI;
                } else {
                    //console.log('error: arrow does not exist');
                }
            }
            var mx = this.play['mouseStartX' + node.side];
            var my = this.play['mouseStartY' + node.side];

            //if (node.side == 2) my += 85;
            //console.log('release node:',node.type,node,count)
            if (node.type == 1) {
                switch (count) {
                    case 1:
                        this.play.unitManager.releaseCharacter(nodeName, r, mx, my, node.side, node.selected, count);
                        break;
                    case 2:
                    case 3:
                        this.play.unitManager.releaseFormation(nodeName, node.selected, count, node.side, mx, my, r);
                        break;
                }
            } else {
                this.play.unitManager.releaseCharacter(nodeName, r, mx, my, node.side, node.selected, node['level' + node.selected]);
            }
            node.reset();
        };

        UIManager.prototype.upgradeNode = function (curr) {
            var buildNode = this.play['selectedNode' + curr.side];

            if (buildNode["level" + curr.pos] >= this["upgradeLimit_" + buildNode.type + "_" + curr.pos]) {
                console.log(buildNode["level" + curr.pos], this["upgradeLimit_" + buildNode.type + "_" + curr.pos], "DID NOT UPGRADE");
                return;
            }
            var val = this.play.parameters['COST_' + buildNode.type + '_' + curr.pos + '_' + buildNode['level' + curr.pos]];
            if (this.play['p' + curr.side + 'Credits'] >= val || this.play.parameters.CHEATING) {
                this.play.statManager.updateStat('nodeUpgrade', 1, curr.side);
                buildNode['level' + curr.pos]++;
                buildNode.ready = false;
                buildNode.selected = curr.pos;
                buildNode.updateNode();
                this.play.updateCredits(-val, buildNode.side);

                this.deselectNode(buildNode);
                this.selectNode(buildNode);
                this.play.actionManager.receiveCallback('upgradeNode');
            }
        };

        UIManager.prototype.deselectNode = function (curr) {
            if (curr == undefined) {
                console.log('deselect node error: curr undefined');
                return;
            }

            this.removeConsole(curr.side);

            //deselect and clear node
            var buildNode = this.play['node' + curr.side + '_' + curr.pos];

            //console.log('remove:', buildNode, curr.side,curr.pos);
            //OLD BRACKET
            if (buildNode != null) {
                var selection = buildNode.mySelection;
                if (selection != null) {
                    selection.alpha = 0;
                }
            }

            for (var i = 0; i < 3; i++) {
                this.play.removeClickable(this.play.consoleButtons.getChildByName('fbo_' + i + '_' + curr.side), curr.side);
                this.play.removeClickable(this.play.consoleButtons.getChildByName('fbb_' + i + '_' + curr.side), curr.side);
                /*if (this.play['fb_bg_' + i + '_' + curr.side] != null) {
                if (this.play['fb_bg_' + i + '_' + curr.side].parent != null) {
                this.play.removeChild(this.play['fb_bg_' + i + '_' + curr.side]);
                }
                }
                if (this.play['fb_max_' + i + '_' + curr.side] != null) {
                if (this.play['fb_max_' + i + '_' + curr.side].parent != null) {
                this.play.removeChild(this.play['fb_max_' + i + '_' + curr.side]);
                }
                }
                if (this.play['fb_lock_' + i + '_' + curr.side] != null) {
                if (this.play['fb_lock_' + i + '_' + curr.side].parent != null) {
                this.play.removeChild(this.play['fb_lock_' + i + '_' + curr.side]);
                }
                }*/
            }

            if (buildNode != undefined) {
                if (this.play['confirmYes' + buildNode.side] != null) {
                    this.removeConfirmation(buildNode.side);
                    this.play['confirmYes' + buildNode.side].updating = -1;
                }

                buildNode.deselectNode();
                this.play['selectedNode' + buildNode.side] = null;
            }
        };

        UIManager.prototype.activateNode = function (side, pos) {
            var node = this.play.getChildByName('node' + side + '_' + pos);
            if (node == null) {
                console.log('no node UIM', side, pos);
                return;
            }
            var b = this.play.nodeButtons.getChildByName('node' + side + '_' + pos + '_base');
            b.alpha = 1;

            //check clickables to make sure you dont re-add
            var clickables = this.play['clickables' + side];
            for (var i = 0; i < clickables.length; i++) {
                if (clickables[i] == b) {
                    return;
                }
            }

            clickables.push(b);
            node.alive = true;
            node.show();
        };

        UIManager.prototype.deactivateNode = function (side, pos) {
            var node = this.play.nodeButtons.getChildByName('node' + side + '_' + pos);
            var b = this.play.nodeButtons.getChildByName('node' + side + '_' + pos + '_base');
            if (this.play['selectedNode' + node.side] == node) {
                this.deselectNode(node);
            }

            if (node == null) {
                return;
            }

            var clickables = this.play['clickables' + side];
            for (var i = 0; i < clickables.length; i++) {
                if (clickables[i] == b) {
                    this.play['clickables' + side].splice(i, 1);
                    break;
                }
            }

            node.alive = false;
        };

        UIManager.prototype.explodeNode = function (side, pos) {
            //b.alpha = 0;
            var node = this.play.nodeButtons.getChildByName('node' + side + '_' + pos);
            var b = this.play.nodeButtons.getChildByName('node' + side + '_' + pos + '_base');
            node.hide();

            //node.death();
            //death anim?
            b.animation.switchTo('fbDoor');
            if (node.type == 1) {
                b.animation.switchTo(8);
            } else if (node.type == 2) {
                b.animation.switchTo(15);
            } else {
                b.animation.switchTo(1);
            }

            //explosion
            if (node.alive) {
                this.play.audioManager.playSFX(this.play.factoryExplodeSFX);
                var effect = new StandOffEntities.effect(this.play, this.play.textures['effects' + this.play['colour' + node.side]], 0, node.returnX(), node.returnY());
                effect.animation.play('nodeDeath' + node.type);
                effect.transform.rotPointX = effect.box.bounds.width / 2;
                effect.transform.rotPointY = effect.box.bounds.height / 2;
                effect.x -= effect.box.bounds.width / 2;
                effect.y -= node.myHeight;
                this.play['effects' + node.side].addChild(effect);
                if (node.side == 1) {
                    effect.y -= node.myHeight;
                    effect.rotation = Math.PI;
                } else {
                    effect.y -= 6;
                }
            }
        };

        UIManager.prototype.removeNode = function (side, pos) {
            //console.log('REMOVE NODE: s:',side,'.',pos)
            var node = this.play.nodeButtons.getChildByName('node' + side + '_' + pos);
            var b = this.play.nodeButtons.getChildByName('node' + side + '_' + pos + '_base');

            //console.log('check:', this.play['selectedNode' + side],node)
            if (node == null)
                return;
            if (this.play['selectedNode' + node.side] == node) {
                console.log('remove console!');
                this.deselectNode(node);
                this.removeConsole(node.side);
            }
            this.deactivateNode(node.side, node.pos);
            node.parent.removeChild(node);
            node.destroy();
            b.parent.removeChild(b);
            b.destroy();
        };

        UIManager.prototype.killNode = function (node) {
            this.explodeNode(node.side, node.pos);
            this.deactivateNode(node.side, node.pos);
            this.checkWarning(node.side);

            for (var i = 0; i < 6; i++) {
                var n = this.play.nodeButtons.getChildByName('node' + node.side + '_' + i);
                if (n != null) {
                    if (n.alive)
                        return;
                }
            }
            var oppSide = this.play.getOppSide(node.side);

            //console.log('PLAYER', oppSide, 'WINS');
            this.play.winGame(oppSide);
        };

        //TYPE SELECTION
        UIManager.prototype.addBarrackSelect = function (buildNode) {
            //add console base
            this.popConsole(buildNode.side);

            //unit
            var consoleTextUnit = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.consoleButtons, 103, 910);
            consoleTextUnit.animation.switchTo('consoleTextUnit');
            consoleTextUnit.name = 'consoleTextUnit';
            consoleTextUnit.visible = false;
            this.play.consoleButtons.addChild(consoleTextUnit);

            for (var i = 0; i < 3; i++) {
                //add Barrack selection
                this.addBarrackSelectButton(buildNode, i);
            }

            this.resetSelectButtonFrames(buildNode);

            buildNode.selectNode();

            if (buildNode['level' + buildNode.selected] > 0) {
                var b = this.play.consoleButtons.getChildByName('fbo_' + buildNode.selected + '_' + buildNode.side);
                this.selectBarrack(b);
            } else {
                //add portrait for type
                // 1 or 2 buildNode.type
                this.addUnselectedPortrait(buildNode);

                var miscText = this.play.consoleButtons.getChildByName('consoleTextMisc' + buildNode.side);
                if (miscText != null) {
                    miscText.destroy();
                    miscText.parent.removeChild(miscText);
                }

                var consoleTextMisc = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.consoleButtons, 103, 910);
                consoleTextMisc.name = 'consoleTextMisc' + buildNode.side;
                consoleTextMisc.animation.switchTo('consoleTextMisc');
                this.play.consoleButtons.addChild(consoleTextMisc);
                if (buildNode.type == 1) {
                    consoleTextMisc.animation.switchTo(2);
                } else {
                    consoleTextMisc.animation.switchTo(1);
                }
            }
            if (buildNode.side == 2)
                this.flipConsole();
        };

        UIManager.prototype.addUnselectedPortrait = function (buildNode) {
            var portrait = this.play.consoleButtons.getChildByName('consolePortrait' + buildNode.side);
            if (portrait != null) {
                portrait.parent.removeChild(portrait);
                portrait.destroy();
            }
            var consolePortrait = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.consoleButtons, 24, 914);
            consolePortrait.animation.switchTo('unselectedPortrait' + this.play['colour' + buildNode.side]);
            consolePortrait.animation.switchTo(buildNode.type);
            consolePortrait.name = 'consolePortrait' + buildNode.side;
            this.play.consoleButtons.addChild(consolePortrait);
        };

        UIManager.prototype.addBarrackSelectButton = function (node, num) {
            if (!this['nodeTypeAvailable_' + num + '_' + node.type])
                return;

            //img
            var myString = 'fbo_' + num + '_' + node.side;
            this.play.removeClickable(this.play.consoleButtons.getChildByName(myString), node.side);
            var myTexture = 'troopBarracks_' + this.play['colour' + node.side];
            var myCost = this.play.parameters.INFANTRY_COST;
            if (node.type === 2) {
                myTexture = 'troopMech_' + this.play['colour' + node.side];
                myCost = this.play.parameters.VEHICLE_COST;
            }

            //position new button
            var b = new StandOffEntities.selectButton(this.play, this.play.textures.consoleButtons, 463 + (num * 102), 910, node.side, num);
            b.name = myString;
            b.animation.switchTo(myTexture);

            this.play.consoleButtons.addChild(b);

            if (node.side == 2) {
                b.x = this.play.game.stage.width - 463 - num * 102 - 80; //gw - pos - w
                b.y = this.play.game.stage.height - 910 - 100;
                b.transform.rotPointX = b.box.bounds.width / 2;
                b.transform.rotPointY = b.box.bounds.height / 2;
                b.rotation = Math.PI;
            }

            b.clickType = 'selectBarrack';

            var myLevel = node['level' + num];

            var selectedNode = this.play['selectedNode' + node.side];

            //selectedNode.animation.switchTo(f+1);
            if (node.side <= this.play.players)
                this.play['clickables' + node.side].push(b);
        };

        UIManager.prototype.selectBarrack = function (curr) {
            //console.log('select barrack!',curr)
            this.play.audioManager.playSFX(this.play.selectUnitSFX);

            var myCurr = curr;

            var buildNode = this.play['selectedNode' + myCurr.side];

            this.highlightCurr(curr);

            //change node
            if (buildNode.selected != myCurr.pos) {
                if (buildNode['level' + myCurr.pos] != 0) {
                    buildNode.selected = myCurr.pos;
                    buildNode.selectNode();
                    buildNode.updateNode();
                }

                this.resetSelectButtonFrames(buildNode);
            }

            //UPGRADE BUTTON
            //remove prev upgrade button
            var prevBtn = this.play.consoleButtons.getChildByName('confirmBtn' + curr.side);
            this.play.removeClickable(prevBtn, curr.side);

            //TEXT
            //remove pre-existing text
            var unitText = this.play.consoleButtons.getChildByName('consoleTextUnit' + curr.side);
            if (unitText != undefined) {
                unitText.destroy();
                //this.play.consoleButtons.removeChild(unitText);
            } else {
                //console.log('no unitText to remove');
            }
            var miscText = this.play.consoleButtons.getChildByName('consoleTextMisc' + curr.side);
            if (miscText != undefined) {
                miscText.destroy();
                //this.play.consoleButtons.removeChild(unitText);
            }

            //remove pre-existing portrait
            var portrait = this.play.consoleButtons.getChildByName('consolePortrait' + curr.side);
            if (portrait != null) {
                portrait.parent.removeChild(portrait);
                portrait.destroy();
            }

            //check max
            if (buildNode['level' + myCurr.pos] == 3)
                return;

            //add text
            var consoleTextUnit = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.consoleButtons, 103, 910);
            consoleTextUnit.animation.switchTo('consoleTextUnit');
            consoleTextUnit.name = 'consoleTextUnit' + curr.side;
            this.play.consoleButtons.addChild(consoleTextUnit);

            var consolePortrait = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.consoleButtons, 24, 914);
            consolePortrait.animation.switchTo('consolePortrait' + this.play['colour' + curr.side]);
            consolePortrait.name = 'consolePortrait' + curr.side;
            this.play.consoleButtons.addChild(consolePortrait);
            if (buildNode.type == 1) {
                //inf
                consoleTextUnit.animation.switchTo(myCurr.pos * 2);
                consolePortrait.animation.switchTo(myCurr.pos);
            } else {
                //veh
                consoleTextUnit.animation.switchTo(myCurr.pos * 2 + 6);
                if (myCurr.pos == 0) {
                    consolePortrait.animation.switchTo(4);
                } else if (myCurr.pos == 1) {
                    consolePortrait.animation.switchTo(3);
                } else {
                    consolePortrait.animation.switchTo(5);
                }
            }

            //levelled up
            if (buildNode['level' + myCurr.pos] > 0) {
                consoleTextUnit.animation.switchTo(consoleTextUnit.animation.frameIndex + 1);
            }

            //place new
            var confirmBtn = new StandOffEntities.selectButton(this.play, this.play.textures.consoleButtons, 99, 970, curr.side, curr.pos);
            confirmBtn.animation.switchTo('consoleUpgradeBtn');
            confirmBtn.name = 'confirmBtn' + curr.side;

            //afford?
            confirmBtn.animation.switchTo(2);

            var canUpgrade = true;

            //buildNode = this.play['selectedNode' + curr.side];
            if (buildNode["level" + curr.pos] >= this["upgradeLimit_" + buildNode.type + "_" + curr.pos]) {
                canUpgrade = false;
            }

            if (buildNode['level' + myCurr.pos] > 0) {
                if (canUpgrade) {
                    confirmBtn.animation.switchTo(8);
                } else if (!canUpgrade) {
                    confirmBtn.animation.switchTo(6);
                }
            }

            this.play.consoleButtons.addChild(confirmBtn);
            confirmBtn.input.onDown.add(this.depressedGreen);
            var val = this.play.parameters['COST_' + buildNode.type + '_' + myCurr.pos + '_' + buildNode['level' + myCurr.pos]];

            //2 player pos
            if (curr.side == 2) {
                confirmBtn.transform.rotPointX = confirmBtn.box.bounds.width / 2;
                confirmBtn.transform.rotPointY = confirmBtn.box.bounds.height / 2;
                confirmBtn.rotation = Math.PI;
                confirmBtn.transform.x = 569;
                confirmBtn.transform.y = 4;

                consoleTextUnit.transform.rotPointX = consoleTextUnit.box.bounds.width / 2;
                consoleTextUnit.transform.rotPointY = consoleTextUnit.box.bounds.height / 2;
                consoleTextUnit.rotation = Math.PI;
                consoleTextUnit.transform.x = 465; //768-103-200 / stagew-x-w
                consoleTextUnit.transform.y = 50; //1024-910-64;

                this.flipConsole();
            }
            if (this.play['p' + myCurr.side + 'Credits'] < val && !this.play.parameters.CHEATING) {
                confirmBtn.animation.switchTo(6);
                this.play['clickables' + curr.side].push(confirmBtn);
                confirmBtn.clickType = 'confirmNo';
            } else {
                //able to click
                this.play['clickables' + curr.side].push(confirmBtn);
                confirmBtn.clickType = 'confirmUpgrade';
            }
        };

        UIManager.prototype.flipConsole = function () {
            var portrait = this.play.consoleButtons.getChildByName('consolePortrait2');
            if (portrait != null) {
                portrait.transform.rotPointX = portrait.box.bounds.width / 2;
                portrait.transform.rotPointY = portrait.box.bounds.height / 2;
                portrait.rotation = Math.PI;
                portrait.transform.x = 652; //768-24-92 / stagew-x-w
                portrait.transform.y = 18; //1024-914-92;
            }

            var miscText = this.play.consoleButtons.getChildByName('consoleTextMisc2');
            if (miscText != null) {
                miscText.transform.rotPointX = miscText.box.bounds.width / 2;
                miscText.transform.rotPointY = miscText.box.bounds.height / 2;
                miscText.rotation = Math.PI;
                miscText.transform.x = 465; //768-103-200 / stagew-x-w
                miscText.transform.y = 50; //1024-910-64;
            }

            var unitText = this.play.consoleButtons.getChildByName('consoleTextUnit2');
            if (unitText != undefined) {
                unitText.transform.rotPointX = unitText.box.bounds.width / 2;
                unitText.transform.rotPointY = unitText.box.bounds.height / 2;
                unitText.rotation = Math.PI;
                unitText.transform.x = 465; //768-103-200 / stagew-x-w
                unitText.transform.y = 50; //1024-910-64;
            }
        };

        UIManager.prototype.cancelBuy = function (b) {
            b.animation.prevFrame();
            this.play.audioManager.playSFX(this.play.buttonErrorSFX);
        };

        UIManager.prototype.depressed = function (b) {
            b.animation.nextFrame();
        };

        UIManager.prototype.depressedGreen = function (b) {
            if (b.clickType == 'confirmNo')
                return;
            b.animation.switchTo(b.animation.currentAnimation.frameIndex + 2);
        };

        UIManager.prototype.confirmSelection = function (curr) {
            //NEW CONSOLE UI
            //change text
            var miscText = this.play.consoleButtons.getChildByName('consoleTextMisc' + curr.side);
            if (miscText != undefined) {
                if (curr.pos == 1) {
                    miscText.animation.switchTo(2);
                } else {
                    miscText.animation.switchTo(1);
                }
            }

            var portrait = this.play.consoleButtons.getChildByName('consolePortrait' + curr.side);
            var buildNode = this.play['node' + curr.side + '_' + curr.pos];
            portrait.animation.switchTo('unselectedPortrait' + this.play['colour' + buildNode.side]);

            //portrait.animation.switchTo('unselectedPortrait' + curr.side);
            portrait.animation.switchTo(curr.pos);

            //is this causing the incorrect frame?
            /*if (portrait != undefined) {
            if (curr.pos == 1) {
            portrait.animation.switchTo(2);
            } else {
            portrait.animation.switchTo(1);
            }
            }*/
            //highlight current button -> highlight exists?
            var prevBtn = this.play.consoleButtons.getChildByName('confirmBtn' + curr.side);
            this.play.removeClickable(prevBtn, curr.side);

            //remove highlight
            this.resetSelectButtonFrames(curr);
            this.highlightCurr(curr);

            //put in new buy button
            var confirmBtn = new StandOffEntities.selectButton(this.play, this.play.textures.consoleButtons, 99, 970, curr.side, curr.pos);
            confirmBtn.animation.switchTo('consoleUpgradeBtn');

            //afford?
            var myCost = this.play.parameters.INFANTRY_COST;
            if (curr.pos === 2) {
                myCost = this.play.parameters.VEHICLE_COST;
            }
            if (myCost <= this.play['p' + curr.side + 'Credits']) {
                confirmBtn.animation.switchTo(2);
                confirmBtn.clickType = 'confirmYes';
            } else {
                confirmBtn.clickType = 'confirmNo';
            }
            confirmBtn.name = 'confirmBtn' + curr.side;
            confirmBtn.input.onDown.add(this.depressedGreen);

            this.play['clickables' + curr.side].push(confirmBtn);
            this.play.consoleButtons.addChild(confirmBtn);
            if (curr.side == 2) {
                confirmBtn.transform.rotPointX = confirmBtn.box.bounds.width / 2;
                confirmBtn.transform.rotPointY = confirmBtn.box.bounds.height / 2;

                confirmBtn.rotation = Math.PI;
                confirmBtn.transform.x = 569;
                confirmBtn.transform.y = 4;
            }

            this.play.audioManager.playSFX(this.play.selectUnitSFX);
        };

        UIManager.prototype.removeConfirmation = function (side) {
            this.play.removeClickable(this.play['confirmYes' + side], side);
            this.play.removeClickable(this.play['confirmNo' + side], side);
            this.removeConsole(side);
        };

        //SELECT TYPE OF NODE
        UIManager.prototype.addTypeSelect = function (buildNode) {
            this.popConsole(buildNode.side);

            //var buildNodeBase = this.play['node' + buildNode.side + '_' + buildNode.pos + '_base'];
            buildNode.selectNode(); //myBase.animation.switchTo(1);

            //misc info
            var miscText = this.play.consoleButtons.getChildByName('consoleTextMisc' + buildNode.side);
            if (miscText != null) {
                miscText.destroy();
                miscText.parent.removeChild(miscText);
            }
            var consoleTextMisc = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.consoleButtons, 103, 910);
            consoleTextMisc.name = 'consoleTextMisc' + buildNode.side;
            consoleTextMisc.animation.switchTo('consoleTextMisc');
            this.play.consoleButtons.addChild(consoleTextMisc);

            this.addUnselectedPortrait(buildNode);

            //node type buttons
            //soldier select
            if (!this.play.lockedSoldiers) {
                var soldierBtn = new StandOffEntities.selectButton(this.play, this.play.textures.consoleButtons, 513, 910, buildNode.side, 1);
                soldierBtn.animation.switchTo('consoleNodeTypeBtn_' + this.play['colour' + buildNode.side]);
                soldierBtn.name = 'soldierBtn' + buildNode.side;

                this.play['clickables' + buildNode.side].push(soldierBtn);
                this.play.consoleButtons.addChild(soldierBtn);
            }

            if (!this.play.lockedVehicles) {
                //mech select
                var mechBtn = new StandOffEntities.selectButton(this.play, this.play.textures.consoleButtons, 613, 910, buildNode.side, 2);
                mechBtn.animation.switchTo('consoleNodeTypeBtn_' + this.play['colour' + buildNode.side]);
                mechBtn.name = 'mechBtn' + buildNode.side;

                this.play['clickables' + buildNode.side].push(mechBtn);
                this.play.consoleButtons.addChild(mechBtn);
            }

            //player 2 positioning
            if (buildNode.side == 2) {
                this.flipConsole();

                if (soldierBtn != undefined) {
                    soldierBtn.transform.rotPointX = soldierBtn.box.bounds.width / 2;
                    soldierBtn.transform.rotPointY = soldierBtn.box.bounds.height / 2;
                    soldierBtn.rotation = Math.PI;
                    soldierBtn.transform.x = 175;
                    soldierBtn.transform.y = 14;
                }
                if (mechBtn != undefined) {
                    mechBtn.transform.rotPointX = mechBtn.box.bounds.width / 2;
                    mechBtn.transform.rotPointY = mechBtn.box.bounds.height / 2;
                    mechBtn.rotation = Math.PI;
                    mechBtn.transform.x = 75;
                    mechBtn.transform.y = 14;
                }
            }

            this.updateConsole(buildNode.side);
        };

        UIManager.prototype.addTypeSelectButton = function (side, num) {
            console.log('removed possible old function UIM');
            return;
            if (side > this.play.players)
                return;
            if (num == 0 && this.play.lockedSoldiers) {
                return;
            } else if (num == 1 && this.play.lockedVehicles) {
                return;
            }

            //img button
            var myString = 'fbo_' + num + '_' + side;
            this.play.removeClickable(this.play.consoleButtons.getChildByName(myString), side);
            if (side == 1) {
                this.play[myString] = new StandOffEntities.selectButton(this.play, this.play.textures[myString], 32 + num * 100, 945, side, num);
            } else {
                this.play[myString] = new StandOffEntities.selectButton(this.play, this.play.textures[myString], this.play.game.stage.width - (32 + num * 100) - 65, 19, side, num);
                this.play[myString].rotation = Math.PI;
            }

            this.play[myString].name = myString;
            this.play.consoleButtons.addChild(this.play[myString]);

            //GOD MODE
            //if (num < 2) this['clickables' + side].push(this[myString]);
            this.play['clickables' + side].push(this.play[myString]);

            //green build button above
            var myString2 = 'fbb_' + num + '_' + side;
            this.play.removeClickable(this.play[myString2], side);
            if (side == 1) {
                this.play[myString2] = new StandOffEntities.selectButton(this.play, this.play.textures.confirmBtn, 32 + (num * 100), 915, side, num);
            } else {
                this.play[myString2] = new StandOffEntities.selectButton(this.play, this.play.textures.confirmBtn, this.play.game.stage.width - (32 + (num * 100)) - 65, 78, side, num);
                this.play[myString2].rotation = Math.PI;
            }

            //this.processImage(this[myString2], true);
            this.play[myString2].name = myString2;
            this.play.consoleButtons.addChild(this.play[myString2]);
            this.play[myString2].animation.switchTo(4);
            if (num < 2)
                this.play['clickables' + side].push(this.play[myString2]);
        };

        UIManager.prototype.finishSelection = function (curr) {
            //remove yes and no
            this.removeConfirmation(curr.side);
            var node = this.play['selectedNode' + curr.side];
            this.deselectNode(node);
            this.setNode(node, curr.pos);
            this.selectNode(node);

            this.play.actionManager.receiveCallback('finishSelection');
        };

        UIManager.prototype.highlightCurr = function (curr) {
            this.removeHighlight(curr);

            //highlight current selected button
            var highlight = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.consoleButtons, curr.transform.x, curr.transform.y);
            highlight.animation.switchTo('consoleButtonHighlight');
            highlight.name = 'consoleButtonHighlight' + curr.side;
            this.play.consoleButtons.addChild(highlight);
        };

        UIManager.prototype.removeHighlight = function (curr) {
            var prevHighlight = this.play.consoleButtons.getChildByName('consoleButtonHighlight' + curr.side);
            if (prevHighlight != null) {
                prevHighlight.destroy();
            }
        };

        //spport
        UIManager.prototype.addSupport = function () {
            //Support UI
            this.play.supportBase1 = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.supportBase, 690, 570);
            this.play.supportBase1.animation.add('transIn', [0, 1, 2, 3, 4], 0.03, false, false);
            this.play.supportBase1.animation.add('transOut', [4, 3, 2, 1, 0], 0.03, false, false);
            this.play.supportBase1.animation.switchTo(4);
            this.play.addChild(this.play.supportBase1);

            this.play.supportBase2 = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.supportBase, 0, 212);
            this.play.supportBase2.animation.add('transIn', [0, 1, 2, 3, 4], 0.03, false, false);
            this.play.supportBase2.animation.add('transOut', [4, 3, 2, 1, 0], 0.03, false, false);
            this.play.supportBase2.animation.switchTo(4);
            this.play.supportBase2.rotation = Math.PI;
            this.play.addChild(this.play.supportBase2);

            var callGap = 81;
            for (var i = 0; i < 3; i++) {
                //new call in button
                this.play['callIn_1_' + i] = new StandOffEntities.callInButton(this.play, this.play.textures['callIn' + i + '_' + this.play.colour1], 693, 586 + (i * callGap), 1, i);
                this.play.addChild(this.play['callIn_1_' + i]);
                this.play['callIn_1_' + i].animation.switchTo(0);
                this.play['callIn_1_' + i].name = 'callIn_1_' + i;
                this.play.clickables1.push(this.play['callIn_1_' + i]);

                //num display for call in button
                //num1
                this.play['token1Num' + i + '_1'] = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.tokenNumbers, 718, 627 + (i * callGap));
                this.play.addChild(this.play['token1Num' + i + '_1']);

                //num2
                this.play['token1Num' + i + '_2'] = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.tokenNumbers, 730, 627 + (i * callGap));
                this.play.addChild(this.play['token1Num' + i + '_2']);

                //p2
                this.play['callIn_2_' + i] = new StandOffEntities.callInButton(this.play, this.play.textures['callIn' + i + '_' + this.play.colour2], 7, 375 - (i * callGap), 2, i);
                this.play.addChild(this.play['callIn_2_' + i]);
                this.play['callIn_2_' + i].animation.switchTo(0);
                this.play['callIn_2_' + i].name = 'callIn_2_' + i;
                this.play['callIn_2_' + i].rotation = Math.PI;
                this.play.clickables2.push(this.play['callIn_2_' + i]);

                //num 1
                this.play['token2Num' + i + '_1'] = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.tokenNumbers, 40, 407 - (i * callGap) - 20);
                this.play['token2Num' + i + '_1'].rotation = Math.PI;
                this.play.addChild(this.play['token2Num' + i + '_1']);

                //num 2
                this.play['token2Num' + i + '_2'] = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.tokenNumbers, 27, 407 - (i * callGap) - 20);
                this.play['token2Num' + i + '_2'].rotation = Math.PI;
                this.play.addChild(this.play['token2Num' + i + '_2']);

                this.play.updateTokens(0, i, 1);
                this.play.updateTokens(0, i, 2);
            }

            this.play.supportButton1 = new StandOffEntities.selectButton(this.play, this.play.textures.supportButton, 675, 530, 1, 1);
            this.play.supportButton1.name = 'supportButton1';
            this.play.supportButton1.clickType = 'supportButton';
            this.play.clickables1.push(this.play.supportButton1);
            this.play.addChild(this.play.supportButton1);
            this.play.supportButton1.animation.switchTo(1);

            this.play.supportButton2 = new StandOffEntities.selectButton(this.play, this.play.textures.supportButton, 0, 455, 2, 1);
            this.play.supportButton2.name = 'supportButton2';
            this.play.supportButton2.rotation = Math.PI;
            this.play.supportButton2.clickType = 'supportButton';
            this.play.clickables2.push(this.play.supportButton2);
            this.play.addChild(this.play.supportButton2);
            this.play.supportButton2.animation.switchTo(1);

            this.play.supportText1 = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.supportText, 690, 566);
            this.play.supportText1.animation.add('inbound', [0, 1, 2, 3], 0.5, true, true);
            this.play.addChild(this.play.supportText1);

            this.play.supportText2 = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.supportText, 0, 447);
            this.play.supportText2.animation.add('inbound', [0, 1, 2, 3], 0.5, true, true);
            this.play.supportText2.transform.rotation = Math.PI;
            this.play.addChild(this.play.supportText2);
        };
        return UIManager;
    })();
    Managers.UIManager = UIManager;
})(Managers || (Managers = {}));
var Managers;
(function (Managers) {
    var UnitManager = (function () {
        function UnitManager(play) {
            this.play = play;
        }
        //core release character function
        UnitManager.prototype.releaseCharacter = function (contentName, r, x, y, side, type, level) {
            //console.log('release:', contentName, r, x, y, side, type, level)
            if (contentName == '') {
                //console.log('CANNOT FIND CORRECT CONTENT TYPE', side, type, level)
            }

            //-0.23403435137044387 603.5 166.5 2 0 1
            var soldier = new StandOffEntities[contentName](this.play, r, x, y, side, type);
            soldier.updateSoldier();
            soldier.tx = Math.floor(soldier.my_x / this.play.parameters.TILE_WIDTH);
            soldier.ty = Math.floor(soldier.my_y / this.play.parameters.TILE_HEIGHT);
            if (soldier.contentType == 0) {
                this.play.statManager.updateStat('spawnInfantry', 1, soldier.side);
                switch (type) {
                    case 0:
                        this.play.statManager.updateStat('spawnRifleman', 1, soldier.side);
                        break;
                    case 1:
                        this.play.statManager.updateStat('spawnFlamer', 1, soldier.side);
                        break;
                    case 2:
                        this.play.statManager.updateStat('spawnBazooka', 1, soldier.side);
                        break;
                }
                soldier.gotoAndPlay('walk_' + this.play.getName(soldier) + '_' + this.play['colour' + soldier.side]);
                this.addLegs(soldier, soldier.contentType);
                this.play['soldiers' + side].push(soldier);
                this.play.units.addChild(soldier);
            } else {
                this.play.statManager.updateStat('spawnVehicle', 1, soldier.side);
                this.play['vehicles' + side].push(soldier);
                soldier.level = level;
                switch (type) {
                    case 0:
                        this.play.statManager.updateStat('spawnApc', 1, soldier.side);
                        this.play.audioManager.playSFX(this.play.APCStartSFX);
                        this.addLegs(soldier, soldier.contentType);
                        soldier.hitWidth = 50;
                        this.play.vehicles.addChild(soldier);
                        break;
                    case 1:
                        this.play.statManager.updateStat('spawnSniper', 1, soldier.side);
                        this.play.vehicles.addChild(soldier);
                        break;
                    case 2:
                        this.play.statManager.updateStat('spawnTank', 1, soldier.side);
                        this.play.audioManager.playSFX(this.play.tankStepSFX);
                        this.addLegs(soldier, soldier.contentType);
                        soldier.updateTankVars();
                        this.play.tanks.addChild(soldier);
                        break;
                }
                //this.play.addChildAfter(soldier, this.play.background);
            }

            //console.log('release char:', type, side);
            this.play.movingContent.push(soldier);
            soldier.setBox();

            this.play.actionManager.receiveCallback('releaseCharacter');
        };

        UnitManager.prototype.releaseFormation = function (name, type, level, side, x, y, r) {
            var texture = this.play.textures[name + '' + this.play['colour' + side]];

            //need to add the rot stuff
            //forward
            var gap = 30;
            var p1x = this.play.returnHOffsetX(gap, r);
            var p1y = this.play.returnHOffsetY(gap, r);

            //side
            var p2x = this.play.returnHOffsetX(gap, r + Math.PI / 2);
            var p2y = this.play.returnHOffsetY(gap, r + Math.PI / 2);
            switch (level) {
                case 2:
                    this.releaseCharacter(name, r, x - p2x, y + p2y, side, type, level);
                    this.releaseCharacter(name, r, x + p2x, y - p2y, side, type, level);
                    break;
                case 3:
                    this.releaseCharacter(name, r, x - p2x, y + p2y, side, type, level);
                    this.releaseCharacter(name, r, x + p2x, y - p2y, side, type, level);
                    this.releaseCharacter(name, r, x - p1x, y + p1y, side, type, level);
                    break;
                default:
                    console.log('Error: no formation');
                    return;
            }
        };

        UnitManager.prototype.addLegs = function (soldier, contentType) {
            var legs;
            if (contentType == 0) {
                legs = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.infantry, soldier.returnX(), soldier.returnY());
                legs.animation.play('legs_' + this.play['colour' + soldier.side]);
                legs.transform.rotPointX = legs.box.bounds.width / 2;
                legs.transform.rotPointY = legs.box.bounds.height / 2;
                legs.x -= (legs.box.bounds.width / 2);
                legs.y -= (legs.box.bounds.height / 2);
                legs.rotation = soldier.rotation;

                soldier.legs = legs;
                this.play.units.addChild(legs);
                return;
            } else {
                var group = this.play.vehicles;
                legs = new Kiwi.GameObjects.Sprite(this.play, this.play.textures.vehicles, 0, soldier.returnX(), soldier.returnY());
                switch (soldier.type) {
                    case 0:
                        //apc legs
                        legs.alpha = 0;
                        legs.animation.play('walk_apc_' + this.play['colour' + soldier.side]);

                        var alfaTween = this.play.game.tweens.create(legs);
                        alfaTween.to({ alpha: 1 }, 10, Kiwi.Animations.Tweens.Easing.Linear.None, true);

                        break;
                    case 1:
                        //sniper
                        legs.animation.play('digDown_' + this.play['colour' + soldier.side]);
                        break;
                    case 2:
                        //tank
                        legs.animation.play('walk_tank_' + this.play['colour' + soldier.side]);
                        group = this.play.tanks;
                        break;
                }
                legs.transform.rotPointX = legs.box.bounds.width / 2;
                legs.transform.rotPointY = legs.box.bounds.height / 2;
                legs.x -= (legs.box.bounds.width / 2);
                legs.y -= (legs.box.bounds.height / 2);
                legs.rotation = soldier.rotation;

                soldier.legs = legs;
                group.addChild(legs);
            }
            /*
            var myString = 'legs';
            //console.log("ADD LEGS:",soldier.type,contentType)
            if (contentType != 0) {
            if (soldier.type == 2) {
            myString = 'tankBase';
            } else if (soldier.type == 1) {
            soldier.animation.add('digDown', [0, 1, 2, 3, 4, 5], 0.17, true);
            soldier.animation.add('digUp', [6, 7, 8, 9, 10, 11], 0.17, true);
            soldier.animation.add('shoot', [12, 13, 14, 15, 16, 17], 0.07, true);
            soldier.animation.play('digDown', true);
            return;
            } else {
            myString = 'apcBase';
            }
            }
            
            //var legs = new StandOffEntities.movingContent(this.play, this.play.textures[myString + this.play['colour' + soldier.side]], 0, soldier.returnX(), soldier.returnY(), soldier.side, 2, 0);
            legs.rotation = soldier.rotation;
            if (contentType == 0) {
            legs.animation.add('walk', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0.17, true);
            legs.animation.play('walk');
            } else {
            if (soldier.type == 2) {
            soldier.animation.add('walk', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0.17, true);
            soldier.animation.add('shoot', [12, 13, 14, 15, 16, 17], 0.17, false);
            soldier.animation.play('walk');
            legs.animation.add('walk', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0.17, true);
            legs.animation.play('walk');
            } else if (soldier.type == 1) {
            //sniper returned above
            } else {
            legs.animation.add('walk', [0, 1, 2, 3, 4, 5], 0.17, true);
            legs.animation.play('walk');
            legs.animation.add('drop', [6, 7, 8, 9, 10, 11, 0, 0, 0, 0], 0.2, true, false);
            }
            }
            legs.animation.play();
            //legs.soldier = soldier;
            soldier.legs = legs;
            this.play.vehicles.addChild(legs);
            */
        };

        UnitManager.prototype.updateMovement = function () {
            for (var i = 0; i < this.play.movingContent.length; i++) {
                var clip = this.play.movingContent[i];

                //on fire
                /*if (clip.fireVar > 0) {
                clip.fireVar--;
                this.hurtChar(clip, clip.fireHurt);
                }*/
                this.updateCharacterMovement(clip);

                //legs
                if (clip.legs != undefined) {
                    clip.legs.x = clip.returnX() - clip.legs.transform.rotPointX;
                    clip.legs.y = clip.returnY() - clip.legs.transform.rotPointY;
                    if (clip.contentType == 0) {
                        if (!clip.legs.animation.isPlaying) {
                            if (clip.rotatedTarget == undefined)
                                clip.legs.rotation = clip.rotation;
                        } else {
                            //clip.legs.rotation = clip.walkRotation;
                        }
                    } else {
                        clip.legs.rotation = clip.walkRotation;
                    }
                }
            }
        };

        //character movement
        UnitManager.prototype.updateCharacterMovement = function (clip) {
            var boundaryReached = this.boundaryReached(clip);
            var clipX = clip.returnX();
            var clipY = clip.returnY();
            var xVelocity = clip.xVelocity;
            var yVelocity = clip.yVelocity;
            if (clip.moving) {
                //catch if they need to aim toward target node
                if (clip.myTarget == undefined) {
                    if (boundaryReached) {
                        this.setBoundaryTarget(clip);
                    }
                }

                //flare
                if (!boundaryReached && clip.name != 'sniper') {
                    var flare = this.play['effects' + clip.side].getChildByName('flare' + clip.side);
                    if (!clip.flaring) {
                        if (flare != undefined) {
                            var line = new Kiwi.Geom.Line(clipX, clipY, flare.x + flare.box.bounds.width / 2, flare.y + flare.box.bounds.height / 2);
                            if (line.length < this.play.parameters.FLARE_DIST) {
                                //check to see if behind flare
                                if ((clip.side == 1 && clipY > flare.y + flare.height / 2) || (clip.side == 2 && clipY < flare.y + flare.height / 2)) {
                                    xVelocity = this.play.getSin(line.angle) * clip.baseVelocity * clip.friction;
                                    yVelocity = this.play.getCos(line.angle) * clip.baseVelocity * clip.friction;
                                    clip.flaring = true;
                                    clip.xVelocity = xVelocity;
                                    clip.yVelocity = yVelocity;
                                    clip.walkRotation = -line.angle;
                                    clip.rotation = -line.angle;
                                    clip.legs.rotation = clip.rotation;
                                } else {
                                    flare = undefined;
                                }
                            }
                        }
                    } else {
                        if (flare == null) {
                            clip.flaring = false;
                        } else {
                            //xVelocity = clip.flareXVelocity;
                            //yVelocity = clip.flareYVelocity;
                        }
                    }
                    /*if (clip.circling) {
                    if (xVelocity < 0) {
                    xVelocity = -clip.baseVelocity;
                    } else {
                    xVelocity = clip.baseVelocity;
                    }
                    if (yVelocity > 0) {
                    clipY--;
                    } else if (yVelocity < 0) {
                    clipY++;
                    }
                    yVelocity = 0;
                    }*/
                }
            } else {
                //console.log('not moving ucm');
            }

            switch (clip.name) {
                case 'apc':
                    this.updateAPCMovement(clip);
                    break;
                case 'sniper':
                    this.updateSniperMovement(clip);
                    if (clip.visible)
                        return;
                    break;
                case 'tank':
                    this.updateTankMovement(clip);
                    break;
            }

            //check movement past kill line
            if (clip.myTarget != undefined) {
                if (yVelocity < 0) {
                    if (clip.y < clip.myTarget.returnY()) {
                        clip.alive = false;
                        this.play.UIManager.killNode(clip.myTarget);
                        this.play.removeArray.push(clip);
                        return;
                    }
                } else if (yVelocity > 0) {
                    if (clip.y > clip.myTarget.y) {
                        clip.alive = false;
                        this.play.UIManager.killNode(clip.myTarget);
                        this.play.removeArray.push(clip);
                        return;
                    }
                }
                clip.x += xVelocity * clip.friction;
                clip.y += yVelocity * clip.friction;
                return;
            }

            if (clip.moving) {
                //PATH COLLISION
                var next_x = Math.floor((clipX + xVelocity) / this.play.parameters.TILE_WIDTH);
                var next_y = Math.floor((clipY - this.play.tileGroup.y + yVelocity) / this.play.parameters.TILE_HEIGHT);

                //walls
                var flipped = false;
                if (next_x < 0) {
                    next_x = 0;
                    if (xVelocity < 0) {
                        xVelocity *= -1;
                        clip.xVelocity *= -1;
                        flipped = true;
                    }
                }
                if (next_x >= this.play.mw - 1) {
                    next_x = this.play.mw - 2;
                    if (xVelocity > 0) {
                        xVelocity *= -1;
                        clip.xVelocity *= -1;
                        flipped = true;
                    }
                }
                if (next_x != clip.tx || next_y != clip.ty || flipped) {
                    this.setCharTile(clip, next_x, next_y);
                    if (clip.circling) {
                        if (xVelocity < 0) {
                            xVelocity = -clip.baseVelocity;
                            clip.walkRotation = Math.PI / 2;
                        } else {
                            xVelocity = clip.baseVelocity;
                            clip.walkRotation = Math.PI * 1.5;
                        }
                    } else {
                        if (flare != undefined) {
                            var line = new Kiwi.Geom.Line(clipX, clipY, flare.x + flare.width / 2, flare.y + flare.height / 2);
                            clip.walkRotation = -line.angle;
                        } else {
                            clip.walkRotation = clip.returnAngle();
                        }
                    }
                    if (clip.contentType == 0) {
                        clip.rotation = clip.walkRotation;
                    } else {
                        //if the vehicle is in a favourable state
                        if (flipped) {
                            clip.rotation = clip.walkRotation;
                        }
                    }
                }

                clip.x += xVelocity * clip.friction;
                clip.y += yVelocity * clip.friction;
            }
        };

        UnitManager.prototype.boundaryReached = function (clip) {
            if (clip.side == 1) {
                if (clip.contentType == 0) {
                    //infantry
                    if ((clip.y + clip.height / 2) <= this.play.parameters.HALFWAY - this.play.parameters.INFANTRY_BOUNDARY) {
                        return true;
                    }
                } else {
                    //vehicle
                    if ((clip.y + clip.height / 2) <= this.play.parameters.HALFWAY - this.play.parameters.VEHICLE_BOUNDARY) {
                        return true;
                    }
                }
            } else {
                if (clip.contentType == 0) {
                    //infantry
                    if ((clip.y + clip.height / 2) >= this.play.parameters.HALFWAY + this.play.parameters.INFANTRY_BOUNDARY) {
                        return true;
                    }
                } else {
                    //vehicle
                    if ((clip.y + clip.height / 2) >= this.play.parameters.HALFWAY + this.play.parameters.VEHICLE_BOUNDARY) {
                        return true;
                    }
                }
            }
            return false;
        };

        UnitManager.prototype.setCharTile = function (clip, next_x, next_y) {
            var yV = clip.yVelocity * clip.friction;
            if (next_x >= this.play.mw || next_y >= this.play.mh || next_x < 0 || next_y < 0) {
                var nextTile = 0;
            } else {
                if (isNaN(next_y)) {
                    console.log('no y??', next_y);
                    return;
                } else if (isNaN(next_x)) {
                    console.log('no x??', next_x);
                    return;
                }
                if (this.play.mapData[next_y] == undefined) {
                    console.log('no .mapData[next_y]??', this.play.mapData[next_y], next_y, this.play.mapData);
                    return;
                }
                var nextTile = this.play.mapData[next_y][next_x];
                if (nextTile == undefined || isNaN(nextTile)) {
                    console.log('what the fudge? unitm', nextTile, next_x, next_y);
                }
            }

            switch (nextTile) {
                case 1:
                    //block
                    if (next_y != clip.ty) {
                        clip.circling = true;
                    } else if (next_x != clip.tx) {
                        //console.log('flip!')
                        // clip.flip();
                    }
                    break;
                case 2:
                    //slow
                    clip.friction = this.play.parameters.TILE_FRICTION;
                    clip.circling = false;
                    break;
                case 3:
                    this.play.deathArray.push(clip);
                    clip.xVelocity = 0;
                    clip.yVelocity = 0;
                    break;

                    break;
                default:
                    //none
                    clip.friction = 1;
                    clip.circling = false;
                    break;
            }
            clip.tx = next_x;
            clip.ty = next_y;
        };

        //TANK
        //-------------------
        UnitManager.prototype.updateTankMovement = function (clip) {
            //catch and stop shooting animation
            if (clip.preCount > 0) {
                //has stopped, shooting
                //post shot, check more
                if (clip.postCount > 0) {
                    if (clip.postCount >= clip.postVar) {
                        this.endTankMoveCycle(clip);
                    } else {
                        clip.postCount++;
                    }
                } else {
                    //check shot
                    if (clip.preCount >= clip.preVar) {
                        if (clip.rotatedTarget == undefined) {
                            this.getTankTarget(clip);
                        } else {
                            this.rotateTankToTarget(clip);
                        }
                    } else {
                        clip.preCount++;
                    }
                }
                //clip.moving = false;
            } else {
                //walking
                this.tankWalk(clip);
            }
        };

        UnitManager.prototype.getTankTarget = function (clip) {
            clip.lastRange = 3;
            var oppSide = this.play.getOppSide(clip.side);
            var myTarget = this.getPriorityTarget(clip, this.getWithinRange(clip));

            //var myTarget = this.returnClosestByLine(clip.x, clip.y, clip.rotation, Math.PI * 2, oppSide);
            if (myTarget == -1 && clip.myTarget != undefined) {
                var line = new Kiwi.Geom.Line(clip.returnX(), clip.returnY(), clip.myTarget.returnX(), clip.myTarget.returnY());
                if (line.length < clip.range3)
                    myTarget = clip.myTarget;
            }
            clip.rotatedTarget = myTarget;

            //get dir
            if (clip.rotatedTarget != -1) {
                var line = new Kiwi.Geom.Line(clip.returnX(), clip.returnY(), myTarget.returnX(), myTarget.returnY());
                clip.targetRotation = (Math.PI * 2) - line.angle;
                if (clip.rotation < 0)
                    clip.rotation += Math.PI * 2;
                if (clip.rotation >= Math.PI * 2)
                    clip.rotation -= Math.PI * 2;

                var la = -line.angle;
                if (la < 0)
                    la += Math.PI * 2;
                if (la >= Math.PI * 2)
                    la -= Math.PI * 2;
                if (la >= Math.PI * 2)
                    la -= Math.PI * 2;

                //need to get the difference between the two angles
                var diff = la - clip.rotation;
                if (diff > Math.PI || (diff > -Math.PI && diff < 0)) {
                    clip.rotatedDir = -1;
                    if (clip.targetRotation > clip.rotation)
                        clip.targetRotation -= Math.PI * 2;
                    //console.log('-CHANGE', clip.rotation, '->', clip.targetRotation);
                } else if (diff != 0) {
                    clip.rotatedDir = 1;
                    if (clip.targetRotation >= Math.PI * 2)
                        clip.targetRotation -= Math.PI * 2;
                    if (clip.targetRotation >= Math.PI * 2)
                        clip.targetRotation -= Math.PI * 2;
                    if (clip.targetRotation < clip.rotation)
                        clip.rotation -= Math.PI * 2;
                    //console.log('+', clip.rotation, '->', clip.targetRotation);
                } else {
                    //same direction, skip rotation phase
                    clip.rotatedDir = 0;
                }
                //start rotating sfx
                //this.play.audioManager.playSFX(this.play.tankRotateSFX);
            } else {
                clip.postCount++;
            }
        };

        UnitManager.prototype.rotateTankToTarget = function (clip) {
            //check rotation toward target
            var rotationMet = false;

            //rotate
            clip.moving = false;
            clip.rotation += clip.rotatedSpeed * clip.rotatedDir;
            var a = clip.rotation;

            //anti clockwise
            //if (a < 0) a += Math.PI * 2;
            if (a > Math.PI * 2)
                a -= Math.PI * 2;
            if (a > Math.PI * 2)
                a -= Math.PI * 2;

            //console.log('rotating tank:', a,'->',clip.targetRotation, clip.rotatedDir, rotationMet)
            if (clip.rotatedDir == 1) {
                if (a >= clip.targetRotation)
                    rotationMet = true;
            } else if (clip.rotatedDir == -1) {
                if (a <= clip.targetRotation)
                    rotationMet = true;
            } else {
                rotationMet = true;
            }

            if (rotationMet) {
                //this.play.tankRotateSFX.stop();
                //shoot
                clip.shotCount++;
                var myTarget = clip.rotatedTarget;
                clip.lastRange = 3;
                if (myTarget != -1 && myTarget.exists) {
                    var line = new Kiwi.Geom.Line(clip.returnX(), clip.returnY(), myTarget.returnX(), myTarget.returnY());
                    if (line.length < clip.range3) {
                        this.shootTarget(clip, myTarget);
                        clip.animation.playAt(0, 'turret_shoot_tank_' + this.play['colour' + clip.side]);
                        if (line.length < clip.range1) {
                            clip.moving = false;
                            clip.lastRange = 1;
                        }
                    }
                }

                if (clip.level > clip.shotCount) {
                    //shot, shoot again!
                    clip.postCount = 0;
                    clip.preCount = 1;
                } else {
                    clip.postCount++;
                }

                clip.rotatedTarget = undefined;
            }
        };

        UnitManager.prototype.tankWalk = function (clip) {
            if (clip.walkCount >= clip.walkVar) {
                clip.preCount++;
                clip.moving = false;
                clip.animation.stop();
                clip.legs.animation.stop();
            } else {
                clip.walkCount++;
            }
            if (clip.rotatedDir != 0) {
                var rotationMet = false;

                //if (!this.play.tankRotateSFX.isPlaying) this.play.audioManager.playSFX(this.play.tankRotateSFX);
                clip.rotation += clip.rotatedSpeed * clip.rotatedDir;
                var a = clip.rotation;
                if (a < 0)
                    a += Math.PI * 2;
                if (clip.rotatedDir == 1) {
                    if (a >= clip.targetRotation)
                        rotationMet = true;
                } else {
                    //if (a > Math.PI * 2) a += Math.PI * 2;
                    if (a <= clip.targetRotation)
                        rotationMet = true;
                }

                if (rotationMet)
                    clip.rotatedDir = 0;
            }
        };

        //check to see if anyone in front
        UnitManager.prototype.traffic = function (clip) {
            //"jam" is the array of traffic items
            clip.jam = [];

            //get point in front of clip
            var gap = 50;
            var range = 50;
            if (clip.name == 'apc') {
                gap = this.play.parameters.APC_TRAFFIC_DISTANCE;
                range = this.play.parameters.APC_TRAFFIC_RADIUS;
            } else {
                //tank
                gap = this.play.parameters.TANK_TRAFFIC_DISTANCE;
                range = this.play.parameters.TANK_TRAFFIC_RADIUS;
            }
            var tx = clip.returnX() - this.play.returnHOffsetX(gap, clip.legs.rotation);
            var ty = clip.returnY() + this.play.returnHOffsetY(gap, clip.legs.rotation);
            var a = new Array();
            for (var i = 0; i < this.play['vehicles' + clip.side].length; i++) {
                var v = this.play['vehicles' + clip.side][i];
                if (v.visible && v != clip) {
                    var line = new Kiwi.Geom.Line(tx, ty, v.returnX(), v.returnY());
                    if (line.length < range) {
                        if (!this.inJamList(v, clip)) {
                            a.push(v);
                        }
                    }
                }
            }
            clip.jam = a;
            if (a.length > 0)
                return true;
            return false;
        };

        UnitManager.prototype.inJamList = function (clip, myTarget) {
            for (var i = 0; i < clip.jam.length; i++) {
                if (clip.jam[i] == myTarget)
                    return true;
            }
            return false;
        };

        UnitManager.prototype.endTankMoveCycle = function (clip) {
            //end of cycle: set rotation back to normal
            if (clip.lastRange > 1) {
                if (!this.traffic(clip))
                    clip.moving = true;
            }
            clip.walkCount = 0;
            clip.preCount = 0;
            clip.postCount = 0;
            clip.shotCount = 0;

            //console.log('end cycle, move again?',clip.moving)
            clip.rotatedTarget = undefined;
            if (!this.boundaryReached(clip) && clip.moving) {
                //need to wobble the tank too
                clip.animation.playAt(0, 'turret_walk_tank_' + this.play['colour' + clip.side]);
                clip.animation.play();
                clip.legs.animation.play();
            }

            if (clip.rotation < 0)
                clip.rotation += Math.PI * 2;
            var clipRotation = clip.rotation;

            //set up reverse rotation
            clip.targetRotation = clip.walkRotation;

            var diff = clip.targetRotation - clipRotation;
            if (diff > Math.PI) {
                clip.rotatedDir = -1;
            } else if (diff != 0) {
                clip.rotatedDir = 1;
            } else {
                clip.rotatedDir = 0;
            }
        };

        //SNIPER
        //-------------------
        UnitManager.prototype.updateSniperMovement = function (clip) {
            var boundaryReached = this.boundaryReached(clip);
            if (clip.visible) {
                switch (clip.animation.currentAnimation.name) {
                    case 'digDown_' + this.play['colour' + clip.side]:
                        if (clip.animation.frameIndex >= 5) {
                            clip.digCount = 0;
                            clip.visible = false;
                        }
                        break;
                    case 'digUp_' + this.play['colour' + clip.side]:
                        if (clip.animation.frameIndex >= 5) {
                            clip.preCount = 0;
                            clip.postCount = 0;
                            clip.shotCount = 1;
                            clip.animation.switchTo('shoot_sniper_' + this.play['colour' + clip.side]);
                            clip.animation.stop();
                            clip.animation.switchTo(5);
                        }
                        break;
                    case 'shoot_sniper_' + this.play['colour' + clip.side]:
                        if (clip.postCount > 0) {
                            clip.postCount++;
                            if (clip.postCount >= clip.postVar) {
                                //fire repeatedly depending on level
                                var targetNode = clip.myTarget;
                                var oppSide = this.play.getOppSide(clip.side);
                                var myTarget = this.getPriorityTarget(clip, this.getWithinRange(clip));

                                //var myTarget = this.returnClosestByLine(clip.x, clip.y, clip.rotation, clip.leeway, oppSide);
                                if (clip.level > clip.shotCount) {
                                    //multi
                                    if (myTarget != -1) {
                                        clip.shotCount++;
                                        clip.postCount = 0;
                                        this.shootTarget(clip, myTarget);
                                        clip.animation.switchTo(0, true);
                                        clip.animation.play();
                                    } else {
                                        if (targetNode != undefined || boundaryReached) {
                                            //at build node, dont dig, but wait instead.
                                            //clip.postCount = 0;
                                            clip.shotCount++;
                                            clip.nodeCount = 0;
                                            clip.preCount = 0;
                                            clip.nodeCount = 0;
                                            clip.postCount = 0;
                                            clip.animation.stop();
                                            clip.animation.switchTo(5);
                                        } else {
                                            clip.animation.playAt(0, 'digDown_' + this.play['colour' + clip.side]);
                                            this.play.audioManager.playSFX(this.play.sniperDigDownSFX);
                                        }
                                    }
                                } else {
                                    //level 1 post shot
                                    //if(myTarget == -1){
                                    if (targetNode != undefined || boundaryReached) {
                                        //at build node, dont dig, but wait instead.
                                        clip.nodeCount++;
                                        if (clip.nodeCount >= clip.nodeVar) {
                                            clip.postCount = 0;
                                            clip.preCount = 0;
                                            clip.shotCount = 0;
                                            clip.nodeCount = 0;
                                            clip.myTarget = undefined;
                                        }
                                    } else {
                                        clip.animation.playAt(0, 'digDown_' + this.play['colour' + clip.side]);
                                        this.play.audioManager.playSFX(this.play.sniperDigDownSFX);
                                    }
                                }
                            }
                        } else if (clip.preCount < clip.preVar) {
                            clip.preCount++;
                        } else if (clip.preCount >= clip.preVar) {
                            //at end of pre fire
                            if (clip.animation.currentAnimation.isPlaying) {
                                if (clip.animation.frameIndex >= 5) {
                                    clip.animation.stop();
                                    clip.animation.switchTo(5);

                                    //after shot, post count is incremented, triggers post code
                                    clip.postCount++;
                                }
                            } else {
                                //stopped animation, now find a target
                                if (boundaryReached && clip.nodeCount < clip.nodeVar) {
                                    clip.nodeCount++;
                                } else {
                                    var oppSide = this.play.getOppSide(clip.side);
                                    myTarget = this.getPriorityTarget(clip, this.getWithinRange(clip));

                                    //myTarget = this.returnClosestByLine(clip.x, clip.y, clip.rotation, clip.leeway, oppSide);
                                    if (myTarget == -1) {
                                        if (clip.myTarget != undefined)
                                            myTarget = clip.myTarget;
                                    }
                                    if (myTarget != -1 && myTarget != undefined) {
                                        this.shootTarget(clip, myTarget);
                                        clip.animation.switchTo(0, true);
                                        clip.animation.play();
                                    } else {
                                        clip.postCount = 1;
                                    }
                                }
                            }
                        }
                        break;
                    default:
                        console.log('Error: no animation set for sniper');
                        break;
                }
            } else {
                clip.digCount++;

                //if someone is above, dont dig up
                if (clip.digCount >= clip.digMax) {
                    if (this.checkWithinProximity(clip, clip.digProximity)) {
                        clip.digCount -= 10;
                    } else {
                        clip.visible = true;
                        clip.animation.playAt(0, 'digUp_' + this.play['colour' + clip.side]);
                        this.play.audioManager.playSFX(this.play.sniperDigUpSFX);
                    }
                }
            }
        };

        //APC
        UnitManager.prototype.dropAPCChar = function (apc) {
            var gap = -48;
            var dx = this.play.returnHOffsetX(gap, apc.legs.rotation);
            var dy = -this.play.returnHOffsetY(gap, apc.legs.rotation);
            if (apc.level <= 1) {
                var texture = this.play.textures['rifleman' + this.play['colour' + apc.side]];

                this.releaseAPCCharacter(apc.returnX() + dx, apc.returnY() + dy, apc);
            } else {
                this.releaseAPCFormation(apc);
            }
            apc.releaseVar = 0;
        };

        //drop a character from the APC
        UnitManager.prototype.releaseAPCCharacter = function (dx, dy, apc) {
            this.play.statManager.updateStat('spawnInfantry', 1, apc.side);
            this.play.statManager.updateStat('spawnRifleman', 1, apc.side);
            var soldier = new StandOffEntities.rifleman(this.play, apc.legs.rotation, dx, dy, apc.side, 0);
            soldier.updateSoldier();
            soldier.tx = Math.floor(soldier.my_x / this.play.parameters.TILE_WIDTH);
            soldier.ty = Math.floor(soldier.my_y / this.play.parameters.TILE_HEIGHT);
            this.play['soldiers' + apc.side].push(soldier);
            this.addLegs(soldier, soldier.contentType);
            this.play.units.addChild(soldier);
            this.play.movingContent.push(soldier);
        };

        UnitManager.prototype.releaseAPCFormation = function (apc) {
            var r = apc.legs.rotation;

            //need to add the rot stuff
            var gap = -48;
            var dx = this.play.returnHOffsetX(gap, apc.legs.rotation);
            var dy = -this.play.returnHOffsetY(gap, apc.legs.rotation);

            //outward gap
            var sidewaysGap = 15;

            var p2x = this.play.returnHOffsetX(sidewaysGap, r + Math.PI / 2);
            var p2y = this.play.returnHOffsetY(sidewaysGap, r + Math.PI / 2);

            //console.log(sidewaysGap, "Sideways Gap", r, "r", r + Math.PI / 2, "r + Math.PI / 2", p2x, p2y, "p2x, p2y");
            this.releaseAPCCharacter(apc.returnX() - p2x + dx, apc.returnY() + p2y + dy, apc);
            this.releaseAPCCharacter(apc.returnX() + p2x + dx, apc.returnY() - p2y + dy, apc);

            if (apc.level == 3) {
                var leaderGap = -60;
                var lx = this.play.returnHOffsetX(leaderGap, apc.legs.rotation);
                var ly = -this.play.returnHOffsetY(leaderGap, apc.legs.rotation);
                this.releaseAPCCharacter(apc.returnX() + lx, apc.returnY() + ly, apc);
            }
        };

        UnitManager.prototype.updateAPCMovement = function (clip) {
            //turret
            //shoot
            if (clip.walkCount >= clip.walkVar) {
                if (this.traffic(clip)) {
                    clip.walkCount -= 20;
                    return;
                }
                clip.walkCount = 0;

                //fire!
                clip.moving = true;
                clip.legs.animation.play();
                var oppSide = this.play.getOppSide(clip.side);
                var myTarget = this.returnClosestByLine(clip.x, clip.y, clip.rotation, Math.PI * 2, oppSide);
                if (myTarget != -1 && myTarget != undefined) {
                    this.shootTarget(clip, myTarget);
                    var line = new Kiwi.Geom.Line(clip.returnX(), clip.returnY(), myTarget.returnX(), myTarget.returnY());
                    if (line.length < clip.range1) {
                        clip.moving = false;
                        clip.legs.animation.stop();
                    }
                }
            } else {
                clip.walkCount++;
            }

            //drop
            if (clip.legs.animation.currentAnimation.name != 'drop_apc_' + this.play['colour' + clip.side]) {
                clip.releaseVar++;
                if (clip.releaseVar >= clip.releaseDelay) {
                    clip.spawned = false;
                    clip.legs.animation.playAt(0, 'drop_apc_' + this.play['colour' + clip.side]);
                    this.play.audioManager.playSFX(this.play.APCOpenSFX);
                    clip.releaseVar = 0;
                    clip.moving = false;
                }
            } else {
                if (!clip.legs.animation.currentAnimation.isPlaying) {
                    clip.legs.animation.play();
                }
                if (clip.legs.animation.currentAnimation.frameIndex == 3 && !clip.spawned) {
                    this.play.unitManager.dropAPCChar(clip);
                    clip.spawned = true;
                } else if (clip.legs.animation.currentAnimation.frameIndex >= 5) {
                    clip.legs.animation.playAt(0, 'walk_apc_' + this.play['colour' + clip.side], true);
                    if (!clip.moving) {
                        clip.legs.animation.stop();
                    }
                } else {
                    //clip.legs.animation.switchTo(clip.legs.animation.frameIndex + 1);
                }
            }
        };

        //PEOW PEOW
        UnitManager.prototype.attack = function (char) {
            //check if its cool to fire
            if (char.contentType == 1 && char.type == 0)
                return;
            char.shootVar++;
            if (char.shootVar >= char.shootDelay) {
                //sniper tank custom
                if (char.contentType == 1 && char.type == 1) {
                    return;
                } else {
                    char.closest = 2000;
                    var enemyArray = this.getWithinRange(char);

                    /*if (char.contentType == 0 && char.type == 2) {
                    var fireArray = this.returnFireTargets(enemyArray);
                    //console.log('catch not on fire!');
                    if (fireArray.length > 0) {
                    //console.log('flame on!');
                    enemyArray = fireArray;
                    }
                    }*/
                    if (enemyArray.length == 0) {
                        char.moving = true;
                        if (char.legs != undefined && (char.xVelocity != 0 || char.yVelocity != 0)) {
                            char.legs.rotation = char.walkRotation;
                            char.legs.animation.play();
                        }
                    } else {
                        var myTarget = this.getPriorityTarget(char, enemyArray);
                        if (myTarget != -1) {
                            this.shootTarget(char, myTarget);

                            //if (char.legs != undefined) char.legs.animation.stop();
                            if (char.closest < char.range1) {
                                if (char.legs != undefined) {
                                    if (char.contentType == 0) {
                                        char.legs.rotation = char.rotation;
                                    }
                                    char.legs.animation.stop();
                                }
                            }
                        } else {
                            char.moving = true;
                            if (char.legs != undefined && (char.xVelocity != 0 || char.yVelocity != 0)) {
                                char.legs.animation.play();
                            }
                        }
                    }
                }
            }
        };

        //targeting
        UnitManager.prototype.returnFireTargets = function (checkArray) {
            var a = new Array();
            for (var i = 0; i < checkArray.length; i++) {
                var char = checkArray[i];
                if (char.fireVar == 0)
                    a.push(char);
            }
            return a;
        };

        UnitManager.prototype.checkWithinProximity = function (char, prox) {
            for (var j = 1; j <= 2; j++) {
                for (var i = 0; i < this.play['soldiers' + j].length; i++) {
                    var e = this.play['soldiers' + j][i];
                    if (char != e) {
                        var line = new Kiwi.Geom.Line(char.returnX(), char.returnY(), e.returnX(), e.returnY());
                        if (line.length < prox) {
                            return true;
                        }
                    }
                }
                for (var i = 0; i < this.play['vehicles' + j].length; i++) {
                    var e = this.play['vehicles' + j][i];
                    if (char != e) {
                        var line = new Kiwi.Geom.Line(char.returnX(), char.returnY(), e.returnX(), e.returnY());
                        if (line.length < prox) {
                            return true;
                        }
                    }
                }
            }
            return false;
        };

        UnitManager.prototype.getWithinRange = function (char) {
            var a = new Array();
            var oppSide = this.play.getOppSide(char.side);
            for (var i = 0; i < this.play['soldiers' + oppSide].length; i++) {
                var e = this.play['soldiers' + oppSide][i];
                var line = new Kiwi.Geom.Line(char.returnX(), char.returnY(), e.returnX(), e.returnY());
                if (line.length < char.range3) {
                    a.push(e);
                    if (line.length < char.closest)
                        char.closest = line.length;
                }
            }
            for (var i = 0; i < this.play['vehicles' + oppSide].length; i++) {
                var e = this.play['vehicles' + oppSide][i];
                if (e.visible) {
                    var line = new Kiwi.Geom.Line(char.returnX(), char.returnY(), e.returnX(), e.returnY());
                    if (line.length < char.range3) {
                        a.push(e);
                        if (line.length < char.closest)
                            char.closest = line.length;
                    }
                }
            }
            return a;
        };

        UnitManager.prototype.getPriorityTarget = function (char, enemyArray) {
            //find the most important target
            var p = 99;
            var d = char.range3;
            var priorityCell = 99;

            //target
            var t = -1;
            var highestVal = 0;
            for (var i = 0; i < enemyArray.length; i++) {
                var e = enemyArray[i];
                var val = char[e.constructor.name + 'Att'];

                //sniper value
                if (char.contentType == 1) {
                    if (char.type == 1) {
                        val = this.getSniperValue(char, e);
                    } else if (char.type == 2) {
                        val = this.getTankValue(char, e);
                    }
                }

                //based on who you hurt most
                if (val > highestVal) {
                    t = e;
                    highestVal = val;
                } else if (highestVal == val) {
                    //see whos furthest along
                    if (char.side == 1) {
                        if (e.y > t.y)
                            t = e;
                    } else {
                        if (e.y < t.y)
                            t = e;
                    }
                }
            }
            return t;
        };

        UnitManager.prototype.setBoundaryTarget = function (clip) {
            //find closest opposition node, thats alive.
            var oppSide = this.play.getOppSide(clip.side);
            var dist = 9999;
            var t;
            for (var i = 0; i < 6; i++) {
                var n = this.play.nodeButtons.getChildByName('node' + oppSide + '_' + i);
                if (n != undefined) {
                    if (n.alive) {
                        var line = new Kiwi.Geom.Line(clip.returnX(), clip.returnY(), n.returnX(), n.returnY());
                        if (line.length < dist) {
                            clip.myTarget = n;
                            t = n;
                            dist = line.length;
                        }
                    }
                }
            }
            if (t != undefined) {
                var line = new Kiwi.Geom.Line(clip.returnX(), clip.returnY(), t.returnX(), t.returnY());
                clip.walkRotation = -line.angle;
                clip.rotation = -line.angle;

                if (clip.contentType == 0) {
                    //infantry change direction
                    clip.setVelocity();
                    this.play.UIManager.showWarning(oppSide, true);
                } else {
                    clip.xVelocity = 0;
                    clip.yVelocity = 0;
                    if (clip.legs != undefined) {
                        clip.legs.rotation = clip.rotation;
                        clip.legs.animation.stop();
                    }
                }
            }
        };

        UnitManager.prototype.getTankValue = function (char, e) {
            var num = e.type;
            if (e.contentType == 1)
                num += 3;
            for (var i = 0; i < char.priorityArray.length; i++) {
                if (char.priorityArray[i] == num) {
                    return 7 - i;
                }
            }
            return 0;
        };

        UnitManager.prototype.getSniperValue = function (char, e) {
            var num = e.type;
            if (e.contentType == 1)
                return 0;
            for (var i = 0; i < char.priorityArray.length; i++) {
                if (char.priorityArray[i] == num) {
                    return 4 - i;
                }
            }
            return 0;
        };

        //get closest enemy via line
        UnitManager.prototype.returnClosestByLine = function (cx, cy, cr, leeway, oppSide) {
            var t = -1;
            var d = 5000;
            for (var i = 0; i < this.play['soldiers' + oppSide].length; i++) {
                var soldier = this.play['soldiers' + oppSide][i];
                var line = new Kiwi.Geom.Line(cx, cy, soldier.x, soldier.y);
                var r = line.angle;
                if (r < 0)
                    r += Math.PI * 2;
                if (line.length < d) {
                    //if (r > cr - leeway && r < cr + leeway) {
                    //within line of sight, if line.length < shortest, set new target
                    t = soldier;
                    d = line.length;
                    //}
                }
            }
            for (var i = 0; i < this.play['vehicles' + oppSide].length; i++) {
                var vehicle = this.play['vehicles' + oppSide][i];
                if (vehicle.visible) {
                    var line = new Kiwi.Geom.Line(cx, cy, vehicle.x, vehicle.y);
                    var r = line.angle;
                    if (r < 0)
                        r += Math.PI * 2;
                    if (line.length < d) {
                        //if (r > cr - leeway && r < cr + leeway) {
                        //within line of sight, if line.length < shortest, set new target
                        t = vehicle;
                        d = line.length;
                        //}
                    }
                }
            }
            return t;
        };

        UnitManager.prototype.shootTarget = function (char, e) {
            //stop moving
            var line = new Kiwi.Geom.Line(char.returnX(), char.returnY(), e.returnX(), e.returnY());
            var dist = line.length;
            if (dist < char.range1) {
                char.moving = false;
                if (char.legs != undefined) {
                    if (char.legs.animation.currentAnimation.name != 'drop')
                        char.legs.animation.stop();
                }
            }

            if (char.contentType == 0) {
                char.gotoAndPlay('shoot_' + this.play.getName(char) + '_' + this.play['colour' + char.side]);
            }
            char.rotateByCentre(-line.angle);

            var hit = this.checkHit(char, line);
            this.shootEffect(char, e, line, hit);

            //character specific shooting logic
            var dam = char[e.constructor.name + 'Att'];

            //char.damage * e['def' + char.attackType];
            if (char.contentType == 0) {
                switch (char.type) {
                    case 0:
                        if (hit) {
                            this.hurtChar(e, dam);
                        }
                        break;
                    case 1:
                        //bazooka
                        //fire bullet
                        this.fireBazooka(char, e, line, hit);
                        break;
                    case 2:
                        //if (hit) this.burnChar(e, dam);
                        if (hit) {
                            this.hurtChar(e, dam);
                            if (e.health <= 0) {
                                e.fireVar = 1;
                            }
                        }
                        break;
                    default:
                        console.log('incorrect char type:', char.type);
                        break;
                }
                this.play.audioManager.playSFX(this.play['infShotSFX' + (char.type + 1)]);
            } else {
                if (char.type == 2) {
                    var arr = this.play.getSideWithinRadius(e.returnX(), e.returnY(), e.side, this.play.parameters.TANK_SPLASH);

                    for (var i = 0; i < arr.length; i++) {
                        var e = arr[i];

                        //console.log('hurt e:', char[e.constructor.name + 'Att']);
                        this.hurtChar(e, char[e.constructor.name + 'Att']);
                    }
                } else {
                    if (hit) {
                        this.hurtChar(e, dam);
                    }
                }
                this.play.audioManager.playSFX(this.play['vehShotSFX' + (char.type + 1)]);
            }

            char.shootVar = 0;
        };

        UnitManager.prototype.checkHit = function (char, line) {
            //get ranged acc
            var acc = 0;
            if (line.length <= char.range1) {
                acc = char.acc1;
            } else if (line.length <= char.range2) {
                acc = char.acc2;
            } else if (line.length <= char.range3) {
                acc = char.acc3;
            }

            //check hit
            var rand = Math.random();
            if (rand > acc)
                return false;

            return true;
        };

        UnitManager.prototype.fireBazooka = function (char, e, line, hit) {
            var muzzleOffsetX = -13;
            var muzzleOffsetY = 30;
            var p1x = this.play.returnHOffsetX(muzzleOffsetY, line.angle);
            var p1y = this.play.returnHOffsetY(muzzleOffsetY, line.angle);
            var p2x = this.play.returnHOffsetX(muzzleOffsetX, line.angle + Math.PI / 2);
            var p2y = this.play.returnHOffsetY(muzzleOffsetX, line.angle + Math.PI / 2);
            var offsetX = p1x + p2x;
            var offsetY = p1y + p2y;

            var cx = char.returnX();
            var cy = char.returnY();
            var muzzleX = cx + offsetX;
            var muzzleY = cy + offsetY;

            var shellX = muzzleX;
            var shellY = muzzleY - 7;
            var speed = 10;
            var bxVelocity = this.play.returnHOffsetX(speed, line.angle);
            var byVelocity = this.play.returnHOffsetY(speed, Math.PI - line.angle);
            var shellTicks = Math.floor(line.length / speed);

            var bullet = new StandOffEntities.bazookaShell(this.play, this.play.textures['effects' + this.play['colour' + char.side]], shellX, shellY, char.side);
            bullet.animation.play('bazookaBullet');
            bullet.setBox();
            bullet.transform.rotPointX = bullet.box.bounds.width / 2;
            bullet.transform.rotPointY = bullet.box.bounds.height;
            bullet.x -= bullet.box.bounds.width / 2;
            bullet.y -= bullet.box.bounds.height;
            bullet.rotation = Math.PI * 2 - line.angle;
            bullet.xVelocity = bxVelocity;
            bullet.yVelocity = byVelocity;

            bullet.count = shellTicks;
            if (hit && e.contentType == 1)
                bullet.target = e;
            this.play['effects' + char.side].addChild(bullet);
            this.play.bullets.push(bullet);
        };

        UnitManager.prototype.explodeBazooka = function (b) {
            //console.log('bazooka target:', b.target);
            //effect
            this.play.audioManager.playSFX(this.play.explosionMediumSFX);

            if (b.target != undefined) {
                //direct hit tank
                var bombEffect = new StandOffEntities.effect(this.play, this.play.textures['effects' + this.play['colour' + b.side]], 0, b.returnX() - 20, b.returnY());
                bombEffect.animation.play('bazookaDirectImpact');
                bombEffect.transform.rotPointY = 0;
                bombEffect.rotation = b.rotation - Math.PI;
                this.play['effects' + b.side].addChild(bombEffect);
                this.hurtChar(b.target, b[b.target.constructor.name + 'Att']);
                return;
            }

            var bombEffect = new StandOffEntities.effect(this.play, this.play.textures['effects' + this.play['colour' + b.side]], 0, b.returnX() - 50, b.returnY() - 50);
            bombEffect.animation.play('bazookaImpact');
            this.play['effects' + b.side].addChild(bombEffect);

            //splash damage
            var arr = this.play.getSideWithinRadius(b.returnX(), b.returnY(), this.play.getOppSide(b.side), 50);
            for (var i = 0; i < arr.length; i++) {
                var char = arr[i];
                this.hurtChar(char, b[char.constructor.name + 'Splash']);
            }
        };

        UnitManager.prototype.shootEffect = function (char, e, line, hit) {
            var dist = line.length;
            var col = this.play['colour' + char.side];
            var cx = char.returnX();
            var cy = char.returnY();
            var myAngle = line.angle;

            //(Math.PI * 2) PLUS?? line.angle;
            //var bline = new Kiwi.Geom.Line(0, 0, 0, 100); //-> 0
            //var bline = new Kiwi.Geom.Line(0, 0, 100, 100); //-> 0.7853981633974483
            //var bline = new Kiwi.Geom.Line(0, 0, -100, 100); //-> -0.7853981633974483
            if (char.contentType == 0) {
                switch (char.type) {
                    case 0:
                        //calculate exact muzzle offset
                        var muzzleOffsetX = -3;
                        var muzzleOffsetY = 22.5;
                        var p1x = this.play.returnHOffsetX(muzzleOffsetY, myAngle);
                        var p1y = this.play.returnHOffsetY(muzzleOffsetY, myAngle);
                        var p2x = this.play.returnHOffsetX(muzzleOffsetX, myAngle + Math.PI / 2);
                        var p2y = this.play.returnHOffsetY(muzzleOffsetX, myAngle + Math.PI / 2);
                        var offsetX = p1x + p2x;
                        var offsetY = p1y + p2y;

                        //streak
                        var streakNum = 0;
                        var streakLength = 80;
                        if (dist > 150) {
                            streakNum = 3;
                            streakLength = 150;
                        } else if (dist > 113) {
                            streakNum = 2;
                            streakLength = 113;
                        } else if (dist > 75) {
                            streakNum = 1;
                        }

                        var muzzleX = cx + offsetX;
                        var muzzleY = cy + offsetY;

                        //console.log('char', char.transform.rotPointX, char.transform.rotPointY, char.width, char.height)
                        if (streakNum > 0) {
                            var streak = new StandOffEntities.effect(this.play, this.play.textures['effects' + col], 0, muzzleX, muzzleY);
                            streak.animation.play('riflemanStreak' + streakNum);
                            streak.x -= streak.box.bounds.width / 2;
                            streak.y -= streak.box.bounds.height;
                            streak.transform.rotPointY = streak.box.bounds.height;
                            streak.rotation = Math.PI - myAngle;

                            //this.play.addChildBefore(streak, this.play.supportBase1);
                            this.play['effects' + char.side].addChild(streak);
                        }

                        var muzzle = new StandOffEntities.effect(this.play, this.play.textures['effects' + col], 0, muzzleX, muzzleY);
                        muzzle.animation.play('riflemanMuzzle');
                        muzzle.x -= (muzzle.box.bounds.width / 2);
                        muzzle.transform.rotPointY = 0;
                        muzzle.rotation = -myAngle;

                        //this.play.addChildBefore(muzzle, this.play.supportBase1);
                        this.play['effects' + char.side].addChild(muzzle);

                        if (hit) {
                            var impactOffset = 20;
                            var ex = e.returnX();
                            var ey = e.returnY();
                            var p1x = this.play.returnHOffsetX(impactOffset, line.angle - Math.PI);
                            var p1y = this.play.returnHOffsetY(impactOffset, line.angle - Math.PI);
                            var impactX = ex + p1x;
                            var impactY = ey + p1y;
                            var impact = new StandOffEntities.effect(this.play, this.play.textures['effects' + col], 0, impactX, impactY);
                            impact.animation.play('riflemanImpact');
                            impact.x -= (impact.box.bounds.width / 2);
                            impact.y -= (impact.box.bounds.height / 2);

                            //impact.transform.rotation = line.angle - Math.PI;
                            //this.play.addChildBefore(impact, this.play.supportBase1);
                            this.play.audioManager.playSFX(this.play.explosionSmallSFX);
                            this.play['effects' + char.side].addChild(impact);
                        }
                        break;

                    case 1:
                        var muzzleOffsetX = -10;
                        var muzzleOffsetY = 5;
                        var p1x = this.play.returnHOffsetX(muzzleOffsetY, line.angle);
                        var p1y = this.play.returnHOffsetY(muzzleOffsetY, line.angle);
                        var p2x = this.play.returnHOffsetX(muzzleOffsetX, line.angle + Math.PI / 2);
                        var p2y = this.play.returnHOffsetY(muzzleOffsetX, line.angle + Math.PI / 2);
                        var offsetX = p1x + p2x;
                        var offsetY = p1y + p2y;

                        var muzzleX = cx + offsetX;
                        var muzzleY = cy + offsetY;
                        var muzzle = new StandOffEntities.effect(this.play, this.play.textures['effects' + col], 0, muzzleX, muzzleY);
                        muzzle.animation.play('bazookaMuzzle');
                        muzzle.x -= (muzzle.box.bounds.width / 2);
                        muzzle.y -= (muzzle.box.bounds.height / 2);
                        muzzle.transform.rotPointX = (muzzle.box.bounds.width / 2);
                        muzzle.transform.rotPointY = (muzzle.box.bounds.height / 2);
                        muzzle.rotation = Math.PI - line.angle;

                        //this.play.addChildBefore(muzzle, this.play.supportBase1);
                        this.play['effects' + char.side].addChild(muzzle);

                        break;

                    case 2:
                        var muzzleOffsetX = 0;
                        var muzzleOffsetY = 18;
                        var p1x = this.play.returnHOffsetX(muzzleOffsetY, line.angle);
                        var p1y = this.play.returnHOffsetY(muzzleOffsetY, line.angle);
                        var p2x = this.play.returnHOffsetX(muzzleOffsetX, line.angle + Math.PI / 2);
                        var p2y = this.play.returnHOffsetY(muzzleOffsetX, line.angle + Math.PI / 2);
                        var offsetX = p1x + p2x;
                        var offsetY = p1y + p2y;
                        var muzzleX = cx + offsetX;
                        var muzzleY = cy + offsetY;
                        var muzzle = new StandOffEntities.effect(this.play, this.play.textures['effects' + col], 0, muzzleX, muzzleY);
                        muzzle.animation.play('flame');
                        muzzle.x -= muzzle.box.bounds.width / 2;
                        muzzle.y -= muzzle.box.bounds.height;
                        muzzle.transform.rotPointX = (muzzle.box.bounds.width / 2);
                        muzzle.transform.rotPointY = muzzle.box.bounds.height;
                        muzzle.rotation = Math.PI - line.angle;

                        //this.play.addChildBefore(muzzle, this.play.supportBase1);
                        this.play['effects' + char.side].addChild(muzzle);
                        break;
                }
            } else {
                switch (char.type) {
                    case 0:
                        //calculate exact muzzle offset
                        var muzzleOffsetX = -3;
                        var muzzleOffsetY = 22;
                        var p1x = this.play.returnHOffsetX(muzzleOffsetY, line.angle);
                        var p1y = this.play.returnHOffsetY(muzzleOffsetY, line.angle);
                        var p2x = this.play.returnHOffsetX(muzzleOffsetX, line.angle + Math.PI / 2);
                        var p2y = this.play.returnHOffsetY(muzzleOffsetX, line.angle + Math.PI / 2);
                        var offsetX = p1x + p2x;
                        var offsetY = p1y + p2y;

                        //streak
                        var streakNum = 0;
                        var streakLength = 80;
                        if (dist > 150) {
                            streakNum = 3;
                            streakLength = 150;
                        } else if (dist > 113) {
                            streakNum = 2;
                            streakLength = 113;
                        } else if (dist > 75) {
                            streakNum = 1;
                        }

                        var muzzleX = cx + offsetX;
                        var muzzleY = cy + offsetY;

                        if (streakNum > 0) {
                            var streak = new StandOffEntities.effect(this.play, this.play.textures['effects' + col], 0, muzzleX, muzzleY);
                            streak.animation.play('apcStreak' + streakNum);
                            streak.x -= streak.box.bounds.width / 2;
                            streak.y -= streak.box.bounds.height;
                            streak.transform.rotPointY = streak.box.bounds.height;
                            streak.rotation = Math.PI - line.angle;
                            this.play['effects' + char.side].addChild(streak);
                        }

                        var muzzle = new StandOffEntities.effect(this.play, this.play.textures['effects' + col], 0, muzzleX, muzzleY);
                        muzzle.animation.play('apcMuzzle');
                        muzzle.x -= muzzle.box.bounds.width / 2;
                        muzzle.transform.rotPointY = 0;
                        muzzle.rotation = Math.PI * 2 - line.angle;
                        this.play['effects' + char.side].addChild(muzzle);

                        if (hit) {
                            var impactOffset = 20;
                            var ex = e.returnX();
                            var ey = e.returnY();
                            var p1x = this.play.returnHOffsetX(impactOffset, line.angle - Math.PI);
                            var p1y = this.play.returnHOffsetY(impactOffset, line.angle - Math.PI);
                            var impactX = ex + p1x;
                            var impactY = ey + p1y;
                            var impact = new StandOffEntities.effect(this.play, this.play.textures['effects' + col], 0, impactX, impactY);
                            impact.animation.play('apcImpact');
                            impact.x -= (impact.box.bounds.width / 2);

                            impact.transform.rotPointX = (impact.box.bounds.width / 2);
                            impact.transform.rotPointY = 0;
                            impact.transform.rotation = line.angle - Math.PI;

                            this.play['effects' + char.side].addChild(impact);
                        }
                        break;

                    case 1:
                        var muzzleOffset = 45;
                        var muzzleX = cx + this.play.returnHOffsetX(muzzleOffset, line.angle);
                        var muzzleY = cy + this.play.returnHOffsetY(muzzleOffset, line.angle);
                        var muzzle = new StandOffEntities.effect(this.play, this.play.textures['effects' + col], 0, muzzleX, muzzleY);
                        muzzle.animation.play('sniperMuzzle');
                        muzzle.x -= (muzzle.box.bounds.width / 2);
                        muzzle.y -= (muzzle.box.bounds.height);
                        muzzle.transform.rotPointX = (muzzle.box.bounds.width / 2);
                        muzzle.transform.rotPointY = muzzle.box.bounds.height;
                        muzzle.transform.rotation = Math.PI - line.angle;
                        this.play['effects' + char.side].addChild(muzzle);

                        var streak = new StandOffEntities.effect(this.play, this.play.textures['effects' + col], 0, muzzleX, muzzleY);
                        streak.animation.play('sniperBullet');
                        streak.transform.rotPointY = streak.height;
                        streak.x -= streak.transform.rotPointX;
                        streak.y -= streak.transform.rotPointY;
                        streak.transform.scaleY = (line.length - muzzleOffset) / streak.box.bounds.height;
                        streak.rotation = Math.PI - line.angle;

                        this.play['effects' + char.side].addChild(streak);

                        var impactOffset = 20;
                        var ex = e.returnX();
                        var ey = e.returnY();
                        var p1x = this.play.returnHOffsetX(impactOffset, line.angle - Math.PI);
                        var p1y = this.play.returnHOffsetY(impactOffset, line.angle - Math.PI);
                        var impactX = ex + p1x;
                        var impactY = ey + p1y;
                        var impact = new StandOffEntities.effect(this.play, this.play.textures['effects' + col], 0, impactX, impactY);
                        impact.animation.play('sniperImpact');
                        impact.x -= (impact.box.bounds.width / 2);
                        impact.y -= (impact.box.bounds.height / 2);

                        impact.transform.rotPointX = (impact.box.bounds.width / 2);
                        impact.transform.rotPointY = 0;
                        impact.transform.rotation = line.angle - Math.PI;

                        this.play['effects' + char.side].addChild(impact);

                        this.play.audioManager.playSFX(this.play.explosionSmallSFX);
                        break;

                    case 2:
                        var muzzleOffsetX = 0;
                        var muzzleOffsetY = 40;
                        var p1x = this.play.returnHOffsetX(muzzleOffsetY, line.angle);
                        var p1y = this.play.returnHOffsetY(muzzleOffsetY, line.angle);
                        var p2x = this.play.returnHOffsetX(muzzleOffsetX, line.angle + Math.PI / 2);
                        var p2y = this.play.returnHOffsetY(muzzleOffsetX, line.angle + Math.PI / 2);
                        var offsetX = p1x + p2x;
                        var offsetY = p1y + p2y;

                        //streak
                        var streakNum = 0;
                        var streakLength = 80;
                        if (dist > 150) {
                            streakNum = 3;
                            streakLength = 150;
                        } else if (dist > 113) {
                            streakNum = 2;
                            streakLength = 113;
                        } else if (dist > 75) {
                            streakNum = 1;
                        }

                        var muzzleX = cx + offsetX;
                        var muzzleY = cy + offsetY;

                        if (streakNum > 0) {
                            var streak = new StandOffEntities.effect(this.play, this.play.textures['effects' + col], 0, muzzleX, muzzleY);
                            streak.animation.play('tankStreak' + streakNum);
                            streak.x -= streak.box.bounds.width / 2;
                            streak.y -= streak.box.bounds.height;
                            streak.transform.rotPointX = streak.box.bounds.width / 2;
                            streak.transform.rotPointY = streak.box.bounds.height;
                            streak.rotation = Math.PI - line.angle;
                            this.play['effects' + char.side].addChild(streak);
                        }

                        var muzzle = new StandOffEntities.effect(this.play, this.play.textures['effects' + col], 0, muzzleX, muzzleY);
                        muzzle.animation.play('tankMuzzle');
                        muzzle.x -= (muzzle.box.bounds.width / 2);
                        muzzle.transform.rotPointX = muzzle.box.bounds.width / 2;
                        muzzle.transform.rotPointY = 0;
                        muzzle.rotation = Math.PI * 2 - line.angle;
                        this.play['effects' + char.side].addChild(muzzle);

                        var impact = new StandOffEntities.effect(this.play, this.play.textures['effects' + col], 0, e.returnX(), e.returnY());
                        impact.animation.play('tankImpact');
                        impact.x -= (impact.box.bounds.width / 2);
                        impact.y -= (impact.box.bounds.height / 2);
                        this.play['effects' + char.side].addChild(impact);
                        break;
                }
            }
        };

        UnitManager.prototype.hurtChar = function (e, amount) {
            if (!e.visible)
                return;
            if (e.clickType == 'buildNode') {
                e.haltVar += amount;
            } else {
                if (e.health > 0) {
                    e.health -= amount;
                    if (e.health <= 0) {
                        e.health = 0;
                        this.play.deathArray.push(e);
                    } else {
                        this.play.healthBar(e);
                    }
                }
            }
        };

        UnitManager.prototype.burnChar = function (e, amount) {
            /*if (e.clickType == 'buildNode') {
            e.haltVar += amount;
            } else {
            if (e.fireVar < amount) e.fireVar = amount;
            }*/
        };

        UnitManager.prototype.healChar = function (char, amount) {
            char.health += amount;
            if (char.health > char.baseHealth)
                char.health = char.baseHealth;
            this.play.healthBar(char);
        };

        UnitManager.prototype.clear = function () {
            for (var i = this.play.movingContent.length - 1; i >= 0; i--) {
                var clip = this.play.movingContent[i];
                if (clip != undefined)
                    this.play.removeClip(clip);
            }
        };

        UnitManager.prototype.kill = function (clip) {
            var oppSide = this.play.getOppSide(clip.side);
            var val = this.play.parameters['REWARD_' + clip.contentType + '_' + clip.type];
            this.play.gainCredits(val, oppSide);
            var name = this.play.getName(clip);
            if (name != null && clip.exists) {
                var deathAnim;

                //console.log('kill:',clip)
                if (clip.contentType == 0) {
                    deathAnim = new StandOffEntities.effect(this.play, this.play.textures.infantryDeaths, 0, clip.returnX(), clip.returnY());

                    //death_1_rifleman_4
                    //this.play.textures[name + this.play['colour' + clip.side] + 'death']
                    var rand = Math.ceil((Math.random() * 3));
                    deathAnim.animation.play('death_' + rand + '_' + name + '_' + this.play['colour' + clip.side]);
                    deathAnim.x -= deathAnim.box.bounds.width / 2;
                    deathAnim.y -= deathAnim.box.bounds.height / 2;
                    deathAnim.transform.rotPointX = deathAnim.box.bounds.width / 2;
                    deathAnim.transform.rotPointY = deathAnim.box.bounds.height / 2;
                    deathAnim.rotation = clip.rotation;

                    if (clip.fireVar > 0) {
                        var burnFX = new StandOffEntities.effect(this.play, this.play.textures['effects' + this.play['colour' + oppSide]], 0, clip.returnX(), clip.returnY());
                        burnFX.animation.play('flamerImpact' + rand);
                        burnFX.x -= burnFX.box.bounds.width / 2;
                        burnFX.y -= burnFX.box.bounds.height / 2;
                        burnFX.transform.rotPointX = burnFX.box.bounds.width / 2;
                        burnFX.transform.rotPointY = burnFX.box.bounds.height / 2;
                        burnFX.rotation = clip.rotation;
                    }
                    if (clip.myTarget != undefined) {
                        clip.alive = false;
                        clip.myTarget = undefined;
                        this.play.UIManager.checkWarning(oppSide);
                    }
                    this.play.infantryDeaths.addChild(deathAnim);
                    if (burnFX != undefined)
                        this.play.infantryDeaths.addChild(burnFX);
                } else {
                    deathAnim = new StandOffEntities.effect(this.play, this.play.textures.vehicleDeaths, 0, clip.returnX(), clip.returnY());
                    deathAnim.animation.play('death_' + clip.name + '_' + this.play['colour' + clip.side]);
                    deathAnim.x -= deathAnim.box.bounds.width / 2;
                    deathAnim.y -= deathAnim.box.bounds.height / 2;
                    deathAnim.transform.rotPointX = deathAnim.box.bounds.width / 2;
                    deathAnim.transform.rotPointY = deathAnim.box.bounds.height / 2;
                    deathAnim.rotation = clip.rotation;
                    this.play.audioManager.playSFX(this.play['vehDieSFX' + (clip.type + 1)]);
                    this.play.vehicleDeaths.addChild(deathAnim);
                }
            }
            this.play.removeClip(clip);
        };
        return UnitManager;
    })();
    Managers.UnitManager = UnitManager;
})(Managers || (Managers = {}));
var Managers;
(function (Managers) {
    var CannonManager = (function () {
        function CannonManager(play, game) {
            this.canAutoFire = false;
            this.autoCannonRange = 1;
            this.autoCannonDuration = 1;
            this.autoFiring = false;
            this.play = play;
            this.game = game;
        }
        CannonManager.prototype.addCannon = function (side, num, r, auto) {
            //side 1 vars
            var cx = this.play.parameters.CANNON_X;
            var cy = this.play.parameters.CANNON_Y_1;
            if (side == 2)
                cy = this.play.parameters.CANNON_Y_2;

            this.play['cannon' + side] = new StandOffEntities.cannon(this.play, this.play.textures, side, num, false);
            this.play.nodeButtons.addChild(this.play['cannon' + side]);
            this.play['cannon' + side].transform.x = cx;
            this.play['cannon' + side].transform.y = cy;
            this.play['cannon' + side].build();
            this.play['cannon' + side].rotation = r;

            this.play['clickables' + side].push(this.play['cannon' + side]);
        };

        CannonManager.prototype.removeCannon = function (side) {
            var cannon = this.play.nodeButtons.getChildByName('cannon' + side);
            this.play.removeClickable(cannon, side);
        };

        CannonManager.prototype.autoFireToggle = function () {
            if (this.canAutoFire) {
                this.canAutoFire = false;
                var cannon = this.play.nodeButtons.getChildByName('cannon' + 2);
                cannon.charge = 0;
                cannon.rotation = 0;
            } else if (!this.canAutoFire && this.play.cannon2.active) {
                this.canAutoFire = true;
                this.setAutoCannonTween();
                var cannon = this.play.nodeButtons.getChildByName('cannon' + 2);
                cannon.charge = 0;
            }
        };

        CannonManager.prototype.turnOnAutoCannon = function (fireTime, onTime, range) {
            this.autoCannonRange = range;
            this.autoCannonDuration = fireTime;
            this.autoCannonTime = onTime;
            if (this.timer != undefined) {
                this.timer.stop();
            }
            this.timer = this.game.time.clock.createTimer('cannonOnTimer', onTime, 0, false);
            this.timer.createTimerEvent(Kiwi.Time.TimerEvent.TIMER_STOP, this.stopAutoCannon, this);

            this.timer.start();
        };
        CannonManager.prototype.stopAutoCannon = function () {
            this.canAutoFire = false;
            this.play.cannon2.active = false;
        };

        CannonManager.prototype.setAutoCannonTween = function () {
            ///
            //check duration and set tween to match
            if (this.autoCannonDuration < 1000) {
                //create the tweens
                this.autoRight1 = this.game.tweens.create(this.play.cannon2);

                //set the tweens up
                this.play.cannon2.rotation = 0 + (Math.PI / 3);
                this.autoRight1.to({ rotation: 0 - (Math.PI / 3) }, Math.floor(1000), Kiwi.Animations.Tweens.Easing.Sinusoidal.InOut, false);
                this.autoRight1.onComplete(this.autoFireToggle, this);
                this.autoRight1.start();
            } else if (this.autoCannonDuration >= 1000 && this.autoCannonDuration < 2000) {
                //create the tweens
                this.autoLeft1 = this.game.tweens.create(this.play.cannon2);
                this.autoRight1 = this.game.tweens.create(this.play.cannon2);

                //set the tweens up
                this.play.cannon2.rotation = 0 - (Math.PI / 3);
                this.autoLeft1.to({ rotation: 0 + (Math.PI / 3) }, Math.floor(1000), Kiwi.Animations.Tweens.Easing.Sinusoidal.InOut, false);
                this.autoRight1.to({ rotation: 0 - (Math.PI / 3) }, Math.floor(1000), Kiwi.Animations.Tweens.Easing.Sinusoidal.InOut, false);
                this.autoRight1.onComplete(this.autoFireToggle, this);

                //set the order that they will execute one after the other in.
                this.autoLeft1.chain(this.autoRight1);
                this.autoLeft1.start();
            } else if (this.autoCannonDuration >= 2000) {
                //create the tweens
                this.autoLeft1 = this.game.tweens.create(this.play.cannon2);
                this.autoLeft2 = this.game.tweens.create(this.play.cannon2);
                this.autoRight1 = this.game.tweens.create(this.play.cannon2);
                this.autoRight2 = this.game.tweens.create(this.play.cannon2);
                this.autoZeroAngle = this.game.tweens.create(this.play.cannon2);

                //set the tweens up
                this.autoLeft1.to({ rotation: 0 + (Math.PI / 3) }, Math.floor(500), Kiwi.Animations.Tweens.Easing.Sinusoidal.InOut, false);
                this.autoLeft2.to({ rotation: 0 + (Math.PI / 3) }, Math.floor(1000), Kiwi.Animations.Tweens.Easing.Sinusoidal.InOut, false);
                this.autoRight1.to({ rotation: 0 - (Math.PI / 3) }, Math.floor(1000), Kiwi.Animations.Tweens.Easing.Sinusoidal.InOut, false);
                this.autoRight2.to({ rotation: 0 - (Math.PI / 3) }, Math.floor(1000), Kiwi.Animations.Tweens.Easing.Sinusoidal.InOut, false);
                this.autoZeroAngle.to({ rotation: 0 }, Math.floor(500), Kiwi.Animations.Tweens.Easing.Sinusoidal.InOut, false);
                this.autoZeroAngle.onComplete(this.autoFireToggle, this);

                //set the order that they will execute one after the other in.
                this.autoLeft1.chain(this.autoRight1);
                this.autoRight1.chain(this.autoLeft2);
                this.autoLeft2.chain(this.autoRight2);
                this.autoRight2.chain(this.autoZeroAngle);
                this.autoLeft1.start();
            }
        };
        CannonManager.prototype.shootAutoCannon = function () {
            if (this.canAutoFire) {
                //modifies the fire rate of the auto cannon.
                if (this.game.time.now() % 3 == 0) {
                    this.fireCannon(2);
                }
            }
        };

        CannonManager.prototype.autoFireCannon = function () {
            var cannon = this.play.nodeButtons.getChildByName('cannon2');
            cannon.frequencyVar = cannon.frequency;
            switch (cannon.type) {
                case 0:
                    //machine gun
                    //find closest, and if within half, shoot!
                    var char = this.play.returnClosestByY(1);
                    if (char != -1 && char.y < Math.floor(this.play.parameters.HALFWAY * this.autoCannonRange)) {
                        //aim at char
                        var line = new Kiwi.Geom.Line(cannon.returnX(), cannon.returnY(), char.returnX(), char.returnY());
                        var ang = Math.PI - line.angle;
                        cannon.rotation = cannon.returnAutoAngle(ang);
                        this.fireCannon(2);
                    }
                    break;
                case 1:
                    //cannon
                    var char = this.play.returnClosestByY(1);
                    if (char != -1) {
                        //aim at char
                        var line = new Kiwi.Geom.Line(cannon.returnX(), cannon.returnY(), char.returnX(), char.returnY());
                        var ang = Math.PI - line.angle;
                        cannon.rotation = cannon.returnAutoAngle(ang);
                        cannon.distance = cannon.returnAutoDist(line.length);
                        this.fireCannon(2);
                        cannon.charge = 0;
                    }
                    break;
                default:
                    console.log('ERROR: no auto cannon type selected');
                    break;
            }
        };

        CannonManager.prototype.rotateCannon = function (num, device) {
            var cannon = this.play.nodeButtons.getChildByName('cannon' + num);
            if (cannon.ready && !cannon.cooling) {
                var mx = (device.x);
                var my = (device.y);
                if (num == 1) {
                    if (my < this.play.parameters.HALFWAY) {
                        this.releaseCannon(num);
                        return;
                    }
                } else {
                    if (my > this.play.parameters.HALFWAY) {
                        this.releaseCannon(num);
                        return;
                    }
                }
                var line = new Kiwi.Geom.Line(this.play['mouseStartX' + num], this.play['mouseStartY' + num], mx, my);
                var r = line.angle;
                if (r < 0)
                    r += Math.PI * 2;
                if (num == 1) {
                    if (r > Math.PI / 2 && r < Math.PI * 1.5)
                        return;
                } else {
                    if (r < Math.PI / 2 || r > Math.PI * 1.5)
                        return;
                }
                cannon.rotation = Math.PI - r;
                cannon.device = device;
                cannon.isDown = true;
            }
        };

        ///             --------------- TOUCH INTERGRATION
        CannonManager.prototype.updateCannons = function () {
            //Checks to see if cannon if auto firing. Then decides if it should fire
            if (this.canAutoFire) {
                this.shootAutoCannon();
            } else if (!this.canAutoFire && this.play.players == 1) {
                var cannon = this.play.nodeButtons.getChildByName('cannon' + 2);
                cannon.rotation = 0;
                if (cannon.ready) {
                    for (var i = 0; i < this.play.soldiers1.length; i++) {
                        if (this.play.soldiers1[i].y < this.play.parameters.HALFWAY * this.autoCannonRange && !this.canAutoFire) {
                            this.autoFireToggle();
                            break;
                        }
                    }
                }
            }
            for (var i = 1; i <= 2; i++) {
                var cannon = this.play.nodeButtons.getChildByName('cannon' + i);
                if (cannon == null)
                    return;
                if (!cannon.active)
                    return;

                //start cannon after animation
                if (this.play['finger' + i] !== null) {
                    cannon.device = this.play['finger' + i];
                } else if (this.play.mouse != null) {
                    cannon.device = this.play.mouse;
                }

                var clip = cannon.getChildByName('cannonClip');
                if (clip == null)
                    continue;
                switch (cannon.type) {
                    case 1:
                        switch (clip.animation.currentAnimation.name) {
                            case 'cannon_warmup_1':
                                cannon.returnToCentre();
                                if (clip.animation.frameIndex == 0) {
                                    if (cannon.pullback.animation.currentAnimation.name != 'cannonOverlayInactive') {
                                        cannon.pullback.animation.play('cannonOverlayInactive');
                                    }
                                    if (cannon.charge <= this.play.parameters.CANNON_MG_WARM_TIME) {
                                        cannon.charge++;
                                        cannon.updateProgress((cannon.charge / this.play.parameters.CANNON_MG_WARM_TIME) * 100);
                                        if (cannon.charge >= this.play.parameters.CANNON_MG_WARM_TIME) {
                                            clip.animation.play();
                                            cannon.updateProgress(100);
                                            this.play.audioManager.playSFX(this.play.cannonChargedSFX);
                                        }
                                        this.play.UIManager.setCannonButtons(cannon.side);
                                    }
                                } else if (clip.animation.frameIndex >= 6) {
                                    //cannon.charge = this.parameters.CANNON_MG_TIME;
                                    clip.animation.switchTo('cannon1', false);
                                    clip.animation.switchTo(6);
                                    cannon.cooling = false;
                                    cannon.ready = true;
                                    //console.log('updateCannons set .ready to true')
                                }
                                break;
                            case 'cannon_backward_1':
                                if (clip.animation.frameIndex >= 5) {
                                    clip.animation.switchTo('cannon1', false);
                                    clip.animation.switchTo(6);
                                } else if (cannon.isDown) {
                                    var fr = clip.animation.frameIndex;
                                    clip.animation.switchTo('cannon1', false);
                                    clip.animation.switchTo(11 - fr);
                                }
                                break;
                            case 'cannon_cooldown_1':
                                cannon.ready = false;
                                if (clip.animation.frameIndex >= 5) {
                                    clip.animation.switchTo('cannon_warmup_1', false);
                                    clip.animation.switchTo(0);
                                } else {
                                    cannon.charge++;
                                    cannon.updateProgress((cannon.charge / this.play.parameters.CANNON_MG_WARM_TIME) * 100);
                                    this.play.UIManager.setCannonButtons(cannon.side);
                                }
                                cannon.returnToCentre();
                                break;
                            default:
                                //case 'default':
                                if (cannon.isDown) {
                                    var overlay = this.play.nodeButtons.getChildByName('canonOverlay_' + cannon.side);
                                    overlay.visible = true;
                                    if (cannon.device == undefined) {
                                        continue;
                                    }
                                    var mx = cannon.device.x;
                                    var my = cannon.device.y;
                                    cannon.updatePullback(mx, my);
                                    var fr = 22;
                                    if (cannon.charge1.animation.frameIndex >= fr) {
                                        //shoot
                                        if (cannon.charge > this.play.parameters.CANNON_MG_TIME) {
                                            cannon.charge = this.play.parameters.CANNON_MG_TIME;
                                        }
                                        if (!cannon.firing) {
                                            cannon.charge = this.play.parameters.CANNON_MG_TIME;
                                        }
                                        cannon.firing = true;
                                        if (cannon.machineGunCount <= 0) {
                                            this.fireCannon(i);
                                            cannon.firing = true;
                                            cannon.machineGunCount = this.play.parameters.CANNON_MG_DELAY;
                                        } else {
                                            cannon.machineGunCount--;
                                        }
                                    }
                                } else {
                                    //return to first pullback frame
                                    cannon.returnToCentre();
                                    var fr = clip.animation.frameIndex;
                                    if (cannon.charge > this.play.parameters.CANNON_MG_WARM_TIME) {
                                        cannon.charge++;
                                        this.play.UIManager.setCannonButtons(cannon.side);
                                    }
                                    if (fr > 6) {
                                        clip.animation.switchTo('cannon_backward_1');
                                        clip.animation.switchTo(11 - fr, true);
                                    } else {
                                        if (cannon.pullback.animation.currentAnimation.name != 'cannonOverlayReady') {
                                            cannon.pullback.animation.switchTo('cannonOverlayReady');
                                            cannon.pullback.animation.play();
                                        }
                                    }
                                }
                                break;
                        }

                        //progress
                        if (cannon.firing) {
                            cannon.charge--;

                            //stop firing, cooldown
                            if (cannon.charge <= 0) {
                                cannon.charge = 0;
                                cannon.firing = false;
                                cannon.cooling = true;
                                clip.animation.switchTo('cannon_cooldown_1', true);
                                cannon.pullback.animation.play('cannonOverlayInactive');

                                cannon.charge1.animation.switchTo(0);
                                cannon.charge2.animation.switchTo(0);
                                this.play.audioManager.playSFX(this.play.cannonEmptySFX);
                            }
                            var perc = ((cannon.charge / this.play.parameters.CANNON_MG_TIME) * 100);
                            cannon.updateProgress(perc);
                            this.play.UIManager.setCannonButtons(cannon.side);
                        }
                        break;
                    case 2:
                    case 3:
                        //shell
                        //flare
                        var warmVar = this.play.parameters.CANNON_SHELL_WARM_TIME;
                        if (cannon.type == 3)
                            warmVar = this.play.parameters.CANNON_FLARE_WARM_TIME;

                        switch (clip.animation.currentAnimation.name) {
                            case 'cannon_warmup_' + cannon.type:
                                cannon.charge++;
                                this.play.UIManager.setCannonButtons(cannon.side);
                                if (cannon.charge <= warmVar) {
                                    cannon.updateProgress((cannon.charge / warmVar) * 100);
                                    cannon.warming = true;
                                } else {
                                    //console.log('frame:', clip.animation.currentAnimation.name, clip.animation.frameIndex, cannon.charge, warmVar)
                                    if (clip.animation.frameIndex >= 5) {
                                        clip.animation.switchTo('cannon' + cannon.type);
                                        clip.animation.switchTo(6);
                                        clip.animation.stop();
                                        cannon.ready = true;
                                        cannon.cooling = false;
                                        cannon.pullback.animation.switchTo('cannonOverlayReady');
                                        cannon.pullback.animation.play();
                                        if (cannon.warming && cannon.type == 2) {
                                            this.play.audioManager.playSFX(this.play.cannonChargedSFX);
                                        }
                                        cannon.warming = false;
                                    } else {
                                        if (!clip.animation.isPlaying) {
                                            clip.animation.play();
                                        }
                                        //clip.animation.switchTo(clip.animation.frameIndex + 1);
                                    }
                                }
                                cannon.returnToCentre();
                                break;
                            case 'cannon_backward_' + cannon.type:
                                //console.log('BACK:', clip.animation.frameIndex)
                                if (clip.animation.frameIndex >= 5) {
                                    clip.animation.switchTo('cannon' + cannon.type, false);
                                    clip.animation.switchTo(6);
                                    cannon.ready = true;
                                    cannon.cooling = false;
                                }
                                break;
                            case 'cannon_shoot_' + cannon.type:
                                //console.log('SHOOT:', clip.animation.frameIndex)
                                if (clip.animation.frameIndex >= 5) {
                                    clip.animation.switchTo('cannon_cooldown_' + cannon.type, true);
                                    cannon.pullback.animation.switchTo('cannonOverlayInactive');
                                }
                                break;
                            case 'cannon_cooldown_' + cannon.type:
                                //console.log('COOL:', clip.animation.frameIndex)
                                if (clip.animation.frameIndex >= 5) {
                                    clip.animation.stop();
                                    if (cannon.charge < warmVar) {
                                        cannon.charge++;
                                        cannon.updateProgress((cannon.charge / warmVar) * 100);
                                        this.play.UIManager.setCannonButtons(cannon.side);
                                        if (cannon.charge >= warmVar) {
                                            clip.animation.playAt(0, 'cannon_warmup_' + cannon.type);
                                        }
                                    }
                                    //cannon.animation.switchTo('cooldown', false);
                                }
                                cannon.returnToCentre();
                                break;
                            default:
                                //console.log('default cannon:', clip.animation.currentAnimation.name)
                                if (cannon.isDown) {
                                    if (cannon.device == undefined)
                                        continue;
                                    var mx = cannon.device.x;
                                    var my = cannon.device.y;
                                    var overlay = this.play.nodeButtons.getChildByName('canonOverlay_' + cannon.side);
                                    overlay.visible = true;
                                    cannon.updatePullback(mx, my);
                                } else {
                                    cannon.charge++;
                                    cannon.updateProgress((cannon.charge / warmVar) * 100);
                                    this.play.UIManager.setCannonButtons(cannon.side);
                                }
                                break;
                        }
                        break;
                    default:
                        break;
                }

                //flare countdown
                var f = this.play['flare' + i];
                if (f != undefined) {
                    f.count--;
                    if (f.count <= 0) {
                        f.exists = false;
                        f.destroy();
                        this.play['flare' + i] = undefined;
                    }
                }
            }
        };

        CannonManager.prototype.releaseCannon = function (side) {
            this.play['cannonTime' + side] = this.play.game.time.now();
            var cannon = this.play.nodeButtons.getChildByName('cannon' + side);

            //console.log('fire cannon', side, this['clickTarget' + side], cannon.type);
            cannon.isDown = false;
            var overlay = this.play.nodeButtons.getChildByName('canonOverlay_' + cannon.side);
            overlay.visible = false;
            var clip = cannon.getChildByName('cannonClip');
            switch (cannon.type) {
                case 1:
                    if (cannon.ready) {
                        cannon.cannonClip.animation.switchTo('cannon1');
                    } else {
                        this.play.audioManager.playSFX(this.play.cannonErrorSFX);
                    }

                    cannon.charge1.animation.switchTo(0);
                    cannon.charge2.animation.switchTo(0);
                    break;
                case 2:
                case 3:
                    //shell boom
                    //flare
                    //console.log('release cannon!', cannon.cannonClip.animation.currentAnimation.name)
                    //this.fireCannon(side);
                    if (cannon.cannonClip.animation.currentAnimation.name == 'cannon' + cannon.type) {
                        var f = cannon.cannonClip.animation.frameIndex;
                        if (cannon.returnProgress() >= 100 && cannon.distance >= 20) {
                            cannon.cannonClip.animation.switchTo('cannon_shoot_' + cannon.type, true);
                            this.fireCannon(side);
                            cannon.firing = true;
                            cannon.ready = false;
                            cannon.charge = 0;
                            cannon.updateProgress(0);
                            this.play.UIManager.setCannonButtons(cannon.side);
                            cannon.pullback.animation.switchTo('cannonOverlayInactive', true);
                            this.play.audioManager.playSFX(this.play.cannonEmptySFX);
                        } else {
                            //Release cannon without firing
                            var tweenToPos = this.game.tweens.create(this.play['cannon' + side]);
                            if (side == 2) {
                                tweenToPos.to({ rotation: 0 }, 250, Kiwi.Animations.Tweens.Easing.Sinusoidal.InOut, false);
                            } else if (this.play['cannon' + side].rotation > 0) {
                                tweenToPos.to({ rotation: Math.PI }, 250, Kiwi.Animations.Tweens.Easing.Sinusoidal.InOut, false);
                            } else {
                                tweenToPos.to({ rotation: -Math.PI }, 250, Kiwi.Animations.Tweens.Easing.Sinusoidal.InOut, false);
                            }

                            tweenToPos.start();

                            //cannon.rotation = 0;
                            cannon.cannonClip.animation.switchTo('cannon_backward_' + cannon.type);
                            this.play.audioManager.playSFX(this.play.cannonErrorSFX);
                        }

                        cannon.charge1.animation.switchTo(0);
                        cannon.charge2.animation.switchTo(0);
                        cannon.cannonClip.animation.switchTo(11 - f, true);
                    } else {
                        this.play.audioManager.playSFX(this.play.cannonErrorSFX);
                    }
                    break;
            }
        };

        CannonManager.prototype.cancelCannon = function (side) {
            var cannon = this.play.nodeButtons.getChildByName('cannon' + side);
            switch (cannon.type) {
                case 1:
                    if (cannon.ready) {
                        //cannon.cannonClip.animation.switchTo('cannonOverlayReady');
                    }

                    cannon.charge1.animation.switchTo(0);
                    cannon.charge2.animation.switchTo(0);
                    if (cannon.pullback.animation.currentAnimation.name != 'cannonOverlayInactive') {
                        cannon.pullback.animation.switchTo('cannonOverlayReady');
                        cannon.pullback.animation.switchTo(0);
                    }
                    break;
                case 2:
                case 3:
                    //shell boom
                    //flare
                    //console.log('release cannon!')
                    //this.fireCannon(side);
                    if (cannon.cannonClip.animation.currentAnimation.name == 'cannon' + cannon.type) {
                        var f = cannon.cannonClip.animation.frameIndex;

                        //cannon.cannonClip.animation.switchTo('backward');
                        cannon.charge1.animation.switchTo(0);
                        cannon.charge2.animation.switchTo(0);
                        cannon.cannonClip.animation.switchTo(11);
                        if (cannon.pullback.animation.currentAnimation.name != 'cannonOverlayInactive') {
                            cannon.pullback.animation.switchTo('cannonOverlayReady');
                            cannon.pullback.animation.switchTo(0);
                        }
                    }
                    break;
            }
        };

        CannonManager.prototype.fireCannon = function (side) {
            var cannon = this.play.nodeButtons.getChildByName('cannon' + side);
            cannon.firing = true;
            var dist = cannon.distance / 5;
            if (dist > 28)
                dist = 28;

            //muzzle effect positioning
            var muzzleX = 0;
            var muzzleY = 0;
            var bulletX = 0;
            var bulletY = 0;
            var bulletTexture = 'cannonMGBullet';
            var type = 'machineGun';
            var texture = 'cannonMGMuzzle';
            var bullet;
            switch (cannon.type) {
                case 1:
                    //boolean toggle l/r turret fire
                    if (cannon.turret) {
                        var muzzleOffsetX = -19;
                        cannon.turret = false;
                    } else {
                        var muzzleOffsetX = 16;
                        cannon.turret = true;
                    }
                    var muzzleOffsetY = 60;
                    var p1x = this.play.returnHOffsetX(muzzleOffsetY, cannon.rotation);
                    var p1y = this.play.returnHOffsetY(muzzleOffsetY, cannon.rotation);
                    var p2x = this.play.returnHOffsetX(muzzleOffsetX, cannon.rotation + Math.PI / 2);
                    var p2y = this.play.returnHOffsetY(muzzleOffsetX, cannon.rotation + Math.PI / 2);
                    var offsetX = p1x + p2x;
                    var offsetY = p1y + p2y;

                    muzzleX = cannon.returnX() - offsetX;
                    muzzleY = cannon.returnY() + offsetY;

                    bulletX = muzzleX;
                    bulletY = muzzleY;

                    //bullet
                    dist = 12;
                    bullet = new StandOffEntities.machineGunBullet(this.play, this.play.textures['effects' + this.play['colour' + cannon.side]], bulletX, bulletY, cannon.side);
                    bullet.animation.switchTo(bulletTexture);
                    bullet.setBox();
                    this.play.audioManager.playSFX(this.play.cannonMGSFX);
                    break;
                case 2:
                    bulletTexture = 'cannonSHShell';
                    type = 'shell';
                    var bulletOffset = 88;
                    var bulletOffsetX = this.play.returnHOffsetX(bulletOffset, cannon.rotation);
                    var bulletOffsetY = this.play.returnHOffsetY(bulletOffset, cannon.rotation);
                    bulletX = cannon.returnX() - bulletOffsetX;
                    bulletY = cannon.returnY() + bulletOffsetY;

                    //need to calculate max and min for bullet throwing
                    var dist = cannon.distance / 4;

                    //if (dist > 28) dist = 28;
                    var muzzleOffset = 100;
                    var muzzleOffsetX = this.play.returnHOffsetX(muzzleOffset, cannon.rotation);
                    var muzzleOffsetY = this.play.returnHOffsetY(muzzleOffset, cannon.rotation);
                    muzzleX = cannon.returnX() - muzzleOffsetX;
                    muzzleY = cannon.returnY() + muzzleOffsetY;
                    texture = 'cannonSHMuzzle';
                    dist *= -1;
                    bullet = new StandOffEntities.cannonShell(this.play, this.play.textures['effects' + this.play['colour' + cannon.side]], bulletX, bulletY, cannon.side);
                    bullet.animation.switchTo(bulletTexture);
                    bullet.setBox();
                    bullet.count = dist;
                    this.play.audioManager.playSFX(this.play.artillarySFX);
                    break;
                case 3:
                    //remove current flare to let soldiers reset themselves between flares
                    var prev = this.play['effects' + cannon.side].getChildByName('flare' + cannon.side);
                    if (prev != undefined) {
                        console.log('remove!');
                        prev.exists = false;
                        prev.destroy();
                    }

                    bulletTexture = 'cannonTFShell';
                    type = 'flare';
                    var bulletOffset = 88;
                    var bulletOffsetX = this.play.returnHOffsetX(bulletOffset, cannon.rotation);
                    var bulletOffsetY = this.play.returnHOffsetY(bulletOffset, cannon.rotation);
                    bulletX = cannon.returnX() - bulletOffsetX;
                    bulletY = cannon.returnY() + bulletOffsetY;

                    //need to calculate max and min for bullet throwing
                    var dist = cannon.distance / 5;

                    //if (dist > this.processVar(55)) dist = this.processVar(55);
                    var muzzleOffset = 100;
                    var muzzleOffsetX = this.play.returnHOffsetX(muzzleOffset, cannon.rotation);
                    var muzzleOffsetY = this.play.returnHOffsetY(muzzleOffset, cannon.rotation);
                    muzzleX = cannon.returnX() - muzzleOffsetX;
                    muzzleY = cannon.returnY() + muzzleOffsetY;
                    texture = 'cannonTFMuzzle';
                    dist *= -1;
                    bullet = new StandOffEntities.bullet(this.play, this.play.textures['effects' + this.play['colour' + cannon.side]], bulletX, bulletY, cannon.side, type);
                    bullet.animation.switchTo(bulletTexture);
                    bullet.setBox();
                    break;
                default:
                    return;
            }
            var bxVelocity = this.play.returnHOffsetX(dist, cannon.rotation);
            var byVelocity = this.play.returnHOffsetY(dist, cannon.rotation);

            if (cannon.type > 1) {
                bullet.count = -dist;
                bxVelocity = this.play.returnHOffsetX(-16, cannon.rotation);
                byVelocity = this.play.returnHOffsetY(-16, cannon.rotation);
            }

            //this.processImage(bullet, true);
            bullet.x -= bullet.box.bounds.width / 2;
            bullet.y -= bullet.box.bounds.height / 2;
            bullet.transform.rotPointX = bullet.box.bounds.width / 2;
            bullet.transform.rotPointY = bullet.box.bounds.height / 2;
            bullet.rotation = cannon.rotation + Math.PI;
            bullet.xVelocity = bxVelocity;
            bullet.yVelocity = byVelocity;

            //type, count, xVelocity, yVelocity
            this.play.bullets.push(bullet);

            var muzzle = new StandOffEntities.effect(this.play, this.play.textures['effects' + this.play['colour' + cannon.side]], 0, muzzleX, muzzleY);
            muzzle.animation.switchTo(texture, true);
            switch (cannon.type) {
                case 1:
                    muzzle.x -= muzzle.box.bounds.width / 2;
                    muzzle.y -= muzzle.box.bounds.height;
                    muzzle.transform.rotPointX = muzzle.box.bounds.width / 2;
                    muzzle.transform.rotPointY = muzzle.box.bounds.height;
                    muzzle.rotation = cannon.rotation + Math.PI;
                    break;
                case 2:
                case 3:
                    //shell
                    muzzle.x -= muzzle.box.bounds.width / 2;
                    muzzle.y -= muzzle.box.bounds.height / 2;
                    muzzle.transform.rotPointX = muzzle.box.bounds.width / 2;
                    muzzle.transform.rotPointY = muzzle.box.bounds.height / 2;
                    muzzle.rotation = cannon.rotation;
                    break;
                default:
                    break;
            }
            this.play['effects' + cannon.side].addChild(muzzle);
            this.play['effects' + cannon.side].addChild(bullet);

            //this.play.sendAction('fireCannon' + side);
            this.play.actionManager.receiveCallback('fireCannon');
        };
        return CannonManager;
    })();
    Managers.CannonManager = CannonManager;
})(Managers || (Managers = {}));
var Managers;
(function (Managers) {
    var CommodityManager = (function () {
        function CommodityManager(game) {
            this._hasElite = false;
            this._creditsAva = 0;
            this._creditsSpent = 0;
            this.game = game;

            //Check to see if we have elite or not.
            if (this.game.saveManager.exists('hasElite')) {
                this.unlockElitePurchaseable();
            }

            //If we don't, then make a request of some kind and really check!
            //Get initial amount of credits.
            if (this.game.saveManager.exists('creditsAvailable')) {
                this._creditsAva = this.game.saveManager.getData('creditsAvailable');
            } else {
                this.setCredits(1000); //Set default amount
            }

            if (this.game.saveManager.exists('creditsSpent')) {
                this._creditsSpent = this.game.saveManager.getData('creditsSpent');
            } else {
                this.game.saveManager.add('creditsSpent', this._creditsSpent, true);
            }
        }
        Object.defineProperty(CommodityManager.prototype, "hasElite", {
            get: function () {
                return this._hasElite;
            },
            enumerable: true,
            configurable: true
        });

        CommodityManager.prototype.unlockElitePurchaseable = function () {
            this._hasElite = true;
            this.game.saveManager.add('hasElite', true, true);
        };

        CommodityManager.prototype.setCredits = function (amount) {
            this._creditsAva = amount; //Caution, can override other values.
            this.game.saveManager.add('creditsAvailable', this._creditsAva, true);

            return this._creditsAva;
        };

        CommodityManager.prototype.convertCreditsToString = function (amount) {
            var credString = amount.toString();

            if (credString.length > 5) {
                credString = '99999';
                return credString;
            }

            while (credString.length < 5) {
                credString = '0' + credString;
            }

            return credString;
        };

        Object.defineProperty(CommodityManager.prototype, "credits", {
            get: function () {
                return this._creditsAva;
            },
            enumerable: true,
            configurable: true
        });

        Object.defineProperty(CommodityManager.prototype, "creditsString", {
            get: function () {
                return this.convertCreditsToString(this.credits);
            },
            enumerable: true,
            configurable: true
        });

        Object.defineProperty(CommodityManager.prototype, "spentCredits", {
            get: function () {
                return this._creditsSpent;
            },
            enumerable: true,
            configurable: true
        });

        Object.defineProperty(CommodityManager.prototype, "spentCreditsString", {
            get: function () {
                return this.convertCreditsToString(this._creditsSpent);
            },
            enumerable: true,
            configurable: true
        });

        //Purchase Credits Here...Add them that is...
        CommodityManager.prototype.increaseCredits = function (amount) {
            if (amount < 0)
                return;

            this._creditsAva += amount;
            this._updateCredits();
        };

        CommodityManager.prototype.useCredits = function (amount) {
            //Make sure its a positive amount. We dont want to give out credits
            if (amount < 0)
                return false;

            //Make sure enough is available, in this case we will just r
            if (this._creditsAva - amount < 0)
                amount = this._creditsAva;

            this._creditsAva -= amount;
            this._creditsSpent += amount;

            //Update Storage Systems.
            this._updateCredits();

            return true;
        };

        CommodityManager.prototype._updateCredits = function () {
            this.game.saveManager.edit('creditsAvailable', this._creditsAva, false);
            this.game.saveManager.edit('creditsSpent', this._creditsSpent, false);
            this.game.saveManager.save();
        };
        return CommodityManager;
    })();
    Managers.CommodityManager = CommodityManager;
})(Managers || (Managers = {}));
var MenuEntities;
(function (MenuEntities) {
    var twoPlayerSetupPanel = (function (_super) {
        __extends(twoPlayerSetupPanel, _super);
        function twoPlayerSetupPanel(state, side, color, defaultUser) {
            _super.call(this, state);
            //static
            this.pos = 0;
            this.side = 0;
            this.isDown = false;
            this.isClicked = false;
            this.clickType = 'buildNodeBase';
            this.auto = false;
            this.readyToStart = false;
            this.scrolling = false;
            this.scrollPointer = null;
            this.lastY = 92;
            this.initY = 0;
            this.scrollCoords = {
                min: 92,
                max: 293
            };
            this.side = side;
            this.state = state;
            this.colour = color;
            this.side = side;
            this.readyToStart = false;

            this.selectedUser = defaultUser;

            //Objects
            var panel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.halfPanel, 0, 0);
            var smallPanel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.bottomSetupPanel, 0, 0);
            smallPanel.y = panel.height - smallPanel.height;
            this.buttonLeft = new MenuEntities.MenuButton(this.state, this.state.textures.colorSelectButtonsLeft, 325, 366);
            this.buttonRight = new MenuEntities.MenuButton(this.state, this.state.textures.colorSelectButtonsRight, 600, 366);
            this.colorButton = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.colourButton, 448, 362);
            var selectAccountPanel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.selectAccountPanel, 180, 62);
            this.readyButton = new MenuEntities.MenuButton(this.state, this.state.textures.readyButton, 400, 200);
            this.readyButton.x = panel.width - this.readyButton.width - 10;
            this.readyButton.y = panel.height - this.readyButton.height - 10;
            var usernameBlock = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.selectedPlayerBlock, 20, 445);

            this.waitingOverlay = new Kiwi.GameObjects.StaticImage(this.state, this.state.textures.waitingForOpponent, 0, 0);
            this.waitingOverlay.visible = false;
            this.waitingOverlay.alpha = 0;

            //Scrollbar
            this.scrollBar = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.scrollbar, 0, this.scrollCoords.min);
            this.scrollBar.x = 184 + 392 + 2; //X Location of user choice + width of the user choice + padding.

            this.selectedUserText = new Kiwi.GameObjects.Textfield(this.state, this.selectedUser.name.toUpperCase(), 90, 448, '#000', 18);
            this.userGroup = new Kiwi.Group(this.state);

            this.addChild(panel);
            this.addChild(smallPanel);
            this.addChild(this.buttonLeft);
            this.addChild(this.buttonRight);
            this.addChild(selectAccountPanel);
            this.addChild(usernameBlock);
            usernameBlock.alpha = 0;
            this.addChild(this.selectedUserText);
            this.addChild(this.userGroup);
            this.addChild(this.scrollBar);
            this.addChild(this.waitingOverlay);
            this.addChild(this.readyButton);

            this.colorButton.alpha = 0;
            this.addChild(this.colorButton);

            this.game.input.onDown.add(this.pressedInput, this);
            this.game.input.onUp.add(this.releasedInput, this);

            this.updateUserList();
        }
        twoPlayerSetupPanel.prototype.pressedInput = function (x, y, timeUp, timeDown, duration, pointer) {
            //Not currently scrolling and allow to continue
            if (this.scrolling == true)
                return;
            if (this.state.overlayActive)
                return;
            if (this.readyToStart)
                return;

            //Overlaps the scrollbar?
            if (this.scrollBar.box.worldHitbox.contains(x, y)) {
                this.startScrolling(pointer);
                return;
            }

            //Does the pointer intersect any userchoice?
            var members = this.userGroup.members;
            var member = null;
            for (var i = 0; i < members.length; i++) {
                member = members[i];

                if (member.visible && member.background.box.worldHitbox.contains(x, y)) {
                    //Allow the drag
                    this.startScrolling(pointer);
                    break;
                }
            }
        };

        twoPlayerSetupPanel.prototype.releasedInput = function (x, y, timeUp, timeDown, duration, pointer) {
            this.stopScrolling(pointer);

            //Did the user scroll at all? Was the duration held for longer than 500 millisecond and did it move at all?
            if (pointer.duration > 500 || Kiwi.Utils.GameMath.difference(pointer.startPoint.y, pointer.endPoint.y) > 50)
                return;

            if (!this.readyToStart) {
                //Does it overlap any
                var members = this.userGroup.members;
                var member = null;
                for (var i = 0; i < members.length; i++) {
                    member = members[i];
                    if (member.visible && member.background.box.worldHitbox.contains(x, y)) {
                        this.choosenPlayer(member);
                        return;
                    }
                }
            }

            if (this.readyButton.box.worldHitbox.contains(x, y)) {
                this.readyHit();
                return;
            }

            if (this.state.overlayActive || this.readyToStart)
                return;

            if (this.buttonLeft.box.worldHitbox.contains(x, y)) {
                this.buttonLeftHit();
                return;
            }

            if (this.buttonRight.box.worldHitbox.contains(x, y)) {
                this.buttonRightHit();
                return;
            }
            if (this.colorButton.box.worldHitbox.contains(x, y)) {
                this.buttonRightHit();
                return;
            }
        };

        twoPlayerSetupPanel.prototype.startScrolling = function (pointer) {
            this.scrolling = true;
            this.scrollPointer = pointer;
            this.initY = this.scrollPointer.y;
            this.lastY = this.scrollBar.y;
        };

        twoPlayerSetupPanel.prototype.stopScrolling = function (pointer) {
            if (this.scrollPointer && pointer.id == this.scrollPointer.id) {
                this.scrolling = false;
                this.scrollPointer = null;
            }
        };

        twoPlayerSetupPanel.prototype.update = function () {
            _super.prototype.update.call(this);

            if (this.waitingOverlay.visible && this.waitingOverlay.alpha < 1) {
                this.waitingOverlay.alpha += 0.05;
            }

            if (this.scrolling) {
                var mouseMovementY = -(this.scrollPointer.y - this.initY);

                //Movement
                this.scrollBar.y = this.lastY;
                this.scrollBar.y += (this.side == 1) ? mouseMovementY : -mouseMovementY;

                //Constraints
                if (this.scrollBar.y < this.scrollCoords.min) {
                    this.scrollBar.y = this.scrollCoords.min;
                } else if (this.scrollBar.y > this.scrollCoords.max) {
                    this.scrollBar.y = this.scrollCoords.max;
                }

                //Update
                this.repositionUserList();
            }

            this.updateAnimations(); //Perhaps only update when the color is switched, that way its a lot less processing each frame!
        };

        twoPlayerSetupPanel.prototype.repositionUserList = function () {
            var members = this.userGroup.members;
            var y = this.scrollCoords.min;
            var spacing = 2;
            var maxMembers = 7;

            //Get the scrollbars y...
            //Get its percentage in the scrollbar its at.
            var percent = (this.scrollBar.y - this.scrollCoords.min) / (this.scrollCoords.max - this.scrollCoords.min);

            //Convert its percentage on-screen into which part of the user list to view.
            var start = Math.max(0, Math.round((members.length - maxMembers) * percent));
            var end = Math.min(start + maxMembers, start + members.length);
            var member = null;

            var sub = 0;
            for (var i = 0; i < members.length; i++) {
                member = members[i];

                if (i >= start && i < end) {
                    member.y = sub * (member.background.height + spacing) + y;
                    member.visible = true;
                    sub++;
                } else {
                    member.visible = false;
                }
            }
        };

        twoPlayerSetupPanel.prototype.updateUserList = function () {
            var users = this.game.userManager.users;
            var x = 184;

            this.userGroup.removeChildren(0, this.userGroup.numChildren(), true);

            for (var i = 0; i < users.length; i++) {
                //UserChoice
                var userChoice = new MenuEntites.UserChoice(this.state, 0, 0, i + 1, users[i]);

                userChoice.visible = false;
                userChoice.x = x;
                userChoice.setColor(this.state['side' + this.side + 'Colour']);
                this.userGroup.addChild(userChoice);
            }

            this.repositionUserList();
        };

        twoPlayerSetupPanel.prototype.choosenPlayer = function (option) {
            if (!option.visible)
                return;
            if (this.scrolling)
                return;
            if (this.state.overlayActive)
                return;
            if (this.readyToStart)
                return;

            var user = option.user;

            //Guest account or is valid then allow
            if (user.guest || user.isValid) {
                this.selectedUser = user;
                this.selectedUserText.text = this.selectedUser.name.toUpperCase();
                //If not valid then login
            } else if (!user.isValid) {
                if (this.game.webview.available) {
                    this.state.overlayActive = true;
                    this.state.sideToLogin = this;

                    this.game.webview.showLogin(this.state.webviewCallback, this.state, 'Player ' + this.side + ': Login', user.name);
                } else {
                    //Complete lies....
                    console.log('Sorry we couldn\'t launch the login screen at this moment. Please re-launch the app to try again.');
                }
            }
        };

        twoPlayerSetupPanel.prototype.readyHit = function () {
            if (this.scrolling)
                return;
            if (this.state.overlayActive)
                return;

            this.game.menuSFX.playSuccess();
            if (!this.readyToStart) {
                this.readyToStart = true;
                this.waitingOverlay.visible = true;
                this.readyButton.animation.switchTo((this.state['side' + this.side + 'Colour'] + 4) * 2);
            } else {
                this.readyToStart = false;
                this.waitingOverlay.visible = false;
                this.waitingOverlay.alpha = 0;
                this.readyButton.animation.switchTo(this.state['side' + this.side + 'Colour']);
            }
            this.state.checkReadyStatus();
        };
        twoPlayerSetupPanel.prototype.buttonLeftHit = function () {
            if (this.scrolling)
                return;
            if (this.state.overlayActive)
                return;
            if (!this.readyToStart)
                this.state.colourLeft(this.side);
        };
        twoPlayerSetupPanel.prototype.buttonRightHit = function () {
            if (this.scrolling)
                return;
            if (this.state.overlayActive)
                return;
            if (!this.readyToStart)
                this.state.colourRight(this.side);
        };
        twoPlayerSetupPanel.prototype.updateAnimations = function () {
            //back panel
            this.getChildAt(0).animation.switchTo(this.state['side' + this.side + 'Colour']);

            //bottom panel
            this.getChildAt(1).animation.switchTo(this.state['side' + this.side + 'Colour']);

            //left button
            this.getChildAt(2).animation.switchTo(this.state['side' + this.side + 'Colour'] * 2);

            //right button
            this.getChildAt(3).animation.switchTo(this.state['side' + this.side + 'Colour'] * 2);

            //select account panel
            this.getChildAt(4).animation.switchTo(this.state['side' + this.side + 'Colour']);

            //ready button
            if (!this.readyToStart) {
                this.readyButton.animation.switchTo(this.state['side' + this.side + 'Colour'] * 2);
            } else {
                this.readyButton.animation.switchTo((this.state['side' + this.side + 'Colour'] + 4) * 2);
            }

            //usernameBlock
            this.getChildAt(5).animation.switchTo(this.state['side' + this.side + 'Colour']);

            this.scrollBar.animation.switchTo(this.state['side' + this.side + 'Colour']);

            //Loop through the user choices
            this.userGroup.forEach(this, function (child) {
                if (this.selectedUser && child.user.name == this.selectedUser.name || !this.selectedUser && child.user.guest) {
                    child.setColor((this.state['side' + this.side + 'Colour'] + 4));
                } else {
                    child.setColor(this.state['side' + this.side + 'Colour']);
                }
            });
        };
        return twoPlayerSetupPanel;
    })(Kiwi.Group);
    MenuEntities.twoPlayerSetupPanel = twoPlayerSetupPanel;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var twoPlayerSettingsPanel = (function (_super) {
        __extends(twoPlayerSettingsPanel, _super);
        function twoPlayerSettingsPanel(state, side, color) {
            _super.call(this, state);
            //static
            this.pos = 0;
            this.side = 0;
            this.isDown = false;
            this.isClicked = false;
            this.clickType = 'buildNodeBase';
            this.auto = false;
            this.side = side;
            this.state = state;
            this.color = color;
            this.side = side;
            switch (color) {
                case 0:
                    //blue
                    this.fontColor = '#0052c4';
                    break;
                case 1:
                    //red;
                    this.fontColor = '#ff0000';
                    break;
                case 2:
                    //green
                    this.fontColor = '#008900';
                    break;
                case 3:
                    //purple
                    this.fontColor = '#a800ff';
                    break;
                default:
                    this.fontColor = '#0052c4';
            }

            //Objects
            var panel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.halfPanel, 0, 0);
            panel.animation.switchTo(color);
            var smallPanel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.settingsPanel, 0, 70);
            smallPanel.animation.switchTo(color);

            //map
            var map = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.maps, 18, 139);
            map.name = 'map';

            //maptext
            var mapText = new Kiwi.GameObjects.Textfield(this.state, 'Map Name', 163, 462, this.fontColor, 18, 'normal', 'venusRisingFont');
            mapText.name = 'mapText';
            mapText.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;

            //t1Round
            var roundText = new Kiwi.GameObjects.Textfield(this.state, '1', 638, 145, this.fontColor, 25, 'normal', 'venusRisingFont');
            roundText.name = 'roundText';
            mapText.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;

            //slot1
            var slot1Text = new Kiwi.GameObjects.Textfield(this.state, 'Slot1', 660, 212, this.fontColor, 25, 'normal', 'venusRisingFont');
            slot1Text.name = 'slot1Text';
            slot1Text.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;

            //s2
            var slot2Text = new Kiwi.GameObjects.Textfield(this.state, 'Slot2', 660, 281, this.fontColor, 25, 'normal', 'venusRisingFont');
            slot2Text.name = 'slot2Text';
            slot2Text.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;

            //s3
            var slot3Text = new Kiwi.GameObjects.Textfield(this.state, 'Slot3', 660, 355, this.fontColor, 25, 'normal', 'venusRisingFont');
            slot3Text.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;
            slot3Text.name = 'slot3Text';

            var readyButton = new MenuEntities.MenuButton(this.state, this.state.textures.readyButton, 400, 200);

            readyButton.animation.switchTo(color * 2);
            readyButton.x = panel.width - readyButton.width - 10;
            readyButton.y = panel.height - readyButton.height - 10;

            var leftButton = new MenuEntities.MenuButtonIncrement(this.state, this.state.textures.leftArrow, 17, 387, this.color * 2);
            var rightButton = new MenuEntities.MenuButtonIncrement(this.state, this.state.textures.rightArrow, 258, 387, this.color * 2);
            leftButton.animation.switchTo(this.color * 2);
            rightButton.animation.switchTo(this.color * 2);

            /*
            if (!(<StandOffGame>this.game).commodityManager.hasElite) {
            leftButton.cellIndex = 10;
            rightButton.cellIndex = 10;
            leftButton.upFrame = 10;
            rightButton.upFrame = 10;
            }
            */
            leftButton.input.onUp.add(this.leftButtonHit, this);
            rightButton.input.onUp.add(this.rightButtonHit, this);

            this.addChild(panel);
            this.addChild(smallPanel);

            this.addChild(map);
            this.addChild(mapText);
            this.addChild(roundText);
            this.addChild(slot1Text);
            this.addChild(slot2Text);
            this.addChild(slot3Text);
            this.addChild(leftButton);
            this.addChild(rightButton);

            this.addChild(readyButton);

            readyButton.input.onUp.add(this.readyHit, this);
        }
        twoPlayerSettingsPanel.prototype.update = function () {
            _super.prototype.update.call(this);

            var mapAni = this.getChildByName('map');

            var temp = this.getChildByName('mapText');

            if (mapAni.animation.frameIndex == 6) {
                if (this.game.commodityManager.hasElite) {
                    temp.text = 'Random Map';
                } else {
                    temp.text = 'Upgrade to use';
                }
            } else {
                temp.text = this.state.parameters.MAP_NAMES[mapAni.animation.frameIndex];
            }

            temp = this.getChildByName('roundText');
            temp.text = "1";

            temp = this.getChildByName('slot1Text');
            temp.text = this.state.side2.slot1.quantity + "";
            temp = this.getChildByName('slot2Text');
            temp.text = this.state.side2.slot2.quantity + "";
            temp = this.getChildByName('slot3Text');
            temp.text = this.state.side2.slot3.quantity + "";
        };
        twoPlayerSettingsPanel.prototype.rightButtonHit = function () {
            if (this.game.commodityManager.hasElite) {
                var temp = this.getChildByName('map');
                temp.animation.nextFrame();
                this.state.selectedMap = temp.animation.frameIndex;
                this.game.menuSFX.playSuccess();

                //If Random *and not wanted* then do it again!
                if (temp.animation.frameIndex == 6) {
                    temp.animation.nextFrame();
                    this.state.selectedMap = temp.animation.frameIndex;
                }
            } else {
                //Error Sound
                var temp = this.getChildByName('map');
                if (temp.animation.frameIndex == 6) {
                    temp.animation.switchTo(0);
                } else {
                    temp.animation.switchTo(6);
                }
                this.game.menuSFX.playSuccess();
            }
        };
        twoPlayerSettingsPanel.prototype.leftButtonHit = function () {
            if (this.game.commodityManager.hasElite) {
                var temp = this.getChildByName('map');
                temp.animation.prevFrame();
                this.state.selectedMap = temp.animation.frameIndex;
                this.game.menuSFX.playSuccess();

                //If Random *and not wanted* then do it again!
                if (temp.animation.frameIndex == 6) {
                    temp.animation.prevFrame();
                    this.state.selectedMap = temp.animation.frameIndex;
                }
            } else {
                //Error Sound
                var temp = this.getChildByName('map');
                if (temp.animation.frameIndex == 6) {
                    temp.animation.switchTo(0);
                } else {
                    temp.animation.switchTo(6);
                }
                this.game.menuSFX.playSuccess();
            }
        };

        twoPlayerSettingsPanel.prototype.readyHit = function () {
            this.game.menuSFX.playSuccess();
            var temp = this.getChildByName('map');
            if (this.game.commodityManager.hasElite || temp.animation.frameIndex == 0) {
                this.state.startSettings();
            } else {
                this.game.menuSFX.playError();
            }
        };

        twoPlayerSettingsPanel.prototype.registerHit = function () {
        };
        return twoPlayerSettingsPanel;
    })(Kiwi.Group);
    MenuEntities.twoPlayerSettingsPanel = twoPlayerSettingsPanel;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var twoPlayerSettingsTop = (function (_super) {
        __extends(twoPlayerSettingsTop, _super);
        function twoPlayerSettingsTop(state, side, color) {
            _super.call(this, state);
            //static
            this.pos = 0;
            this.side = 0;
            this.isDown = false;
            this.isClicked = false;
            this.clickType = 'buildNodeBase';
            this.auto = false;
            this.side = side;
            this.state = state;
            this.color = color;
            this.side = side;

            //Objects
            var panel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.halfPanel, 0, 0);
            panel.rotation = Math.PI;
            panel.animation.switchTo(4);
            var tokensAndCallinsPanel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.tokensAndCallinsPanel, 2, 1);

            var buyMore = new MenuEntities.MenuButton(this.state, this.state.textures.buyMore, 395, 17);
            buyMore.input.onEntered.add(function () {
                buyMore.cellIndex = 1;
            }, this);
            buyMore.input.onDown.add(function () {
                buyMore.cellIndex = 1;
            }, this);
            buyMore.input.onUp.add(function () {
                buyMore.cellIndex = 0;
                this.game.menuSFX.playSuccess();
                this.state.toTheStore();
            }, this);
            buyMore.input.onLeft.add(function () {
                buyMore.cellIndex = 0;
            }, this);

            this.slot1 = new MenuEntities.TwoPlayerSettingsCallinPanel(this, 0, 0, 280, 150, 9);
            this.slot2 = new MenuEntities.TwoPlayerSettingsCallinPanel(this, 1, 0, 440, 150, 8);
            this.slot3 = new MenuEntities.TwoPlayerSettingsCallinPanel(this, 2, 0, 600, 150, 6);

            this.intelligence = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.intelligence, 33, 161);

            this.spentCredits = new Kiwi.GameObjects.Textfield(this.state, this.game.commodityManager.spentCreditsString, 179, 44, '#f2b831', 25, 'normal', 'venusRisingFont');
            this.avaCredits = new Kiwi.GameObjects.Textfield(this.state, this.game.commodityManager.creditsString, 364, 44, '#f2b831', 25, 'normal', 'venusRisingFont');
            this.spentCredits.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_RIGHT;
            this.avaCredits.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_RIGHT;

            this.credits = this.game.commodityManager.credits;
            this.spent = this.game.commodityManager.spentCredits;
            this.updateCredits();

            this.addChild(panel);
            this.addChild(tokensAndCallinsPanel);

            this.addChild(buyMore);
            this.addChild(this.slot1);
            this.addChild(this.slot2);
            this.addChild(this.slot3);
            this.addChild(this.spentCredits);
            this.addChild(this.avaCredits);

            this.addChild(this.intelligence);

            this.setDefaults();
        }
        twoPlayerSettingsTop.prototype.setDefaults = function () {
            var i = 0;
            var enoughCredits = false;
            while (i < 3) {
                this.slot1.increaseQuantity(false);
                this.slot2.increaseQuantity(false);
                this.slot3.increaseQuantity(false);

                i++;
            }
        };

        twoPlayerSettingsTop.prototype.checkQuanities = function () {
            if (this.credits - this.creditsBeingUsed >= 0) {
                return true;
            } else {
                return false;
            }
        };

        Object.defineProperty(twoPlayerSettingsTop.prototype, "creditsBeingUsed", {
            get: function () {
                return this.slot1.creditsUsed + this.slot2.creditsUsed + this.slot3.creditsUsed;
            },
            enumerable: true,
            configurable: true
        });

        twoPlayerSettingsTop.prototype.updateCredits = function () {
            this.avaCredits.text = this.game.commodityManager.convertCreditsToString(this.credits - this.creditsBeingUsed);
            this.spentCredits.text = this.game.commodityManager.convertCreditsToString(this.creditsBeingUsed);
        };

        twoPlayerSettingsTop.prototype.update = function () {
            _super.prototype.update.call(this);
            this.updateCredits();
        };

        twoPlayerSettingsTop.prototype.readyHit = function () {
            this.state.startSettings();
        };
        twoPlayerSettingsTop.prototype.registerHit = function () {
        };
        twoPlayerSettingsTop.prototype.updateIntelligence = function (frame) {
            this.intelligence.animation.switchTo(frame);
        };
        return twoPlayerSettingsTop;
    })(Kiwi.Group);
    MenuEntities.twoPlayerSettingsTop = twoPlayerSettingsTop;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var TwoPlayerSettingsCallinPanel = (function (_super) {
        __extends(TwoPlayerSettingsCallinPanel, _super);
        function TwoPlayerSettingsCallinPanel(settingsTop, type, quantity, x, y, cost) {
            _super.call(this, settingsTop.state);
            //static
            this.isClicked = false;
            this.clickType = 'buildNodeBase';
            this.auto = false;
            this.creditsUsed = 0;
            this.cost = 0;
            this.settingsTop = settingsTop;
            this.type = type;
            this.quantity = quantity;
            this.x = x;
            this.y = y;
            this.cost = cost;

            //Objects
            var leftButton = new MenuEntities.MenuButtonIncrement(this.state, this.state.textures.leftArrow, 15, 10, 8);
            var rightButton = new MenuEntities.MenuButtonIncrement(this.state, this.state.textures.rightArrow, 85, 10, 8);
            leftButton.animation.switchTo(8);
            rightButton.animation.switchTo(8);

            var plusButton = new MenuEntities.MenuButtonIncrement(this.state, this.state.textures.plus, 85, 171, 8);
            var minusButton = new MenuEntities.MenuButtonIncrement(this.state, this.state.textures.minus, 15, 171, 8);
            plusButton.animation.switchTo(8);
            minusButton.animation.switchTo(8);

            var typeSprite = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.callinsSpriteSheet, 25, 95);
            typeSprite.name = 'typeSprite';
            this.addChild(typeSprite);

            var creditIcon = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.tokenSymbol, 95, 144);
            this.addChild(creditIcon);

            var typeText = new Kiwi.GameObjects.Textfield(this.state, '0', 80, 77, '#edb61c', 11, 'normal', 'venusRisingFont');
            var costText = new Kiwi.GameObjects.Textfield(this.state, this.cost.toString(), 137, 136, '#edb61c', 25, 'normal', 'venusRisingFont');
            var quantityText = new Kiwi.GameObjects.Textfield(this.state, 'xxx', 80, 267, '#edb61c', 30, 'normal', 'venusRisingFont');

            //var slot3Textfield = new Kiwi.GameObjects.Textfield(this.state, '0', 650, 250, '#FFFFFF', 18, 'normal', 'playFont');
            typeText.name = 'typeText';
            quantityText.name = 'quantityText';

            //slot3Textfield.name = 'slot3Textfield';
            typeText.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;

            costText.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_RIGHT;
            quantityText.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;

            var updateIntelButton = new MenuEntities.MenuButtonIncrement(this.state, this.state.textures.displayInfo, 90, 95, 0);

            this.addChild(plusButton);
            this.addChild(minusButton);

            //these buttons are for switching callin types
            //this.addChild(leftButton);
            //this.addChild(rightButton);
            this.addChild(typeText);
            this.addChild(quantityText);
            this.addChild(costText);
            this.addChild(updateIntelButton);

            if (this.game.commodityManager.hasElite) {
                minusButton.input.onDown.add(this.minusButtonHit, this);
                plusButton.input.onDown.add(this.plusButtonHit, this);
            } else {
                /*
                plusButton.cellIndex = 10;
                minusButton.cellIndex = 10;
                plusButton.upFrame = 10;
                minusButton.upFrame = 10;
                */
                minusButton.input.onDown.add(this.purchaseElite, this);
                plusButton.input.onDown.add(this.purchaseElite, this);
            }

            updateIntelButton.input.onDown.add(function () {
                this.game.menuSFX.playSuccess();
                this.updateIntelHit();
            }, this);
            //leftButton.input.onDown.add(this.leftButtonHit, this);
            //rightButton.input.onDown.add(this.rightButtonHit, this);
        }
        TwoPlayerSettingsCallinPanel.prototype.update = function () {
            _super.prototype.update.call(this);
            var temp = this.getChildByName('typeText');
            switch (this.type) {
                case 0:
                    temp.text = 'Alpha Team';
                    break;

                case 1:
                    temp.text = 'Airstrike';
                    break;

                case 2:
                    temp.text = 'Heal Beam';
                    break;

                default:
                    temp.text = 'Out of range';
            }

            temp = this.getChildByName('quantityText');
            temp.text = this.quantity + "";
            temp = this.getChildByName('typeSprite');
            temp.animation.switchTo(this.type);
        };

        TwoPlayerSettingsCallinPanel.prototype.updateCreditsUsed = function () {
            this.creditsUsed = this.quantity * this.cost;
        };

        TwoPlayerSettingsCallinPanel.prototype.purchaseElite = function () {
            this.game.menuSFX.playError();
            this.updateIntelHit();
        };

        TwoPlayerSettingsCallinPanel.prototype.minusButtonHit = function () {
            this.updateIntelHit();
            this.decreaseQuantity();
        };

        TwoPlayerSettingsCallinPanel.prototype.plusButtonHit = function () {
            this.updateIntelHit();
            this.increaseQuantity();
        };

        TwoPlayerSettingsCallinPanel.prototype.decreaseQuantity = function (sound) {
            if (typeof sound === "undefined") { sound = true; }
            //If it can be decreased, then decrease it
            if (this.quantity - 1 >= 0) {
                this.quantity--;
                this.updateCreditsUsed(); //HORID WAY OF DOING IT.... Should check before hand...

                if (this.settingsTop.checkQuanities() == false) {
                    this.quantity++;
                    this.updateCreditsUsed();
                    if (!sound)
                        this.game.menuSFX.playError();
                } else {
                    if (!sound)
                        this.game.menuSFX.playSuccess();
                }
            }
        };

        TwoPlayerSettingsCallinPanel.prototype.increaseQuantity = function (sound) {
            if (typeof sound === "undefined") { sound = true; }
            //Can the quantity be increased?
            if (this.quantity + 1 <= this.state.parameters.CALL_IN_MAXIMUM) {
                this.quantity++;
                this.updateCreditsUsed();

                //Do we have enough credits?
                if (this.settingsTop.checkQuanities() == false) {
                    this.quantity--;
                    this.updateCreditsUsed();
                    if (!sound)
                        this.game.menuSFX.playError();
                } else {
                    if (!sound)
                        this.game.menuSFX.playSuccess();
                }
            }
        };

        TwoPlayerSettingsCallinPanel.prototype.leftButtonHit = function () {
            this.type--;
            if (this.type < 0) {
                this.type = 2;
            }
        };
        TwoPlayerSettingsCallinPanel.prototype.rightButtonHit = function () {
            this.type++;
            if (this.type > 2) {
                this.type = 0;
            }
        };

        TwoPlayerSettingsCallinPanel.prototype.updateIntelHit = function () {
            this.settingsTop.updateIntelligence(this.type + 1);
        };
        return TwoPlayerSettingsCallinPanel;
    })(Kiwi.Group);
    MenuEntities.TwoPlayerSettingsCallinPanel = TwoPlayerSettingsCallinPanel;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var trainingSetupTop = (function (_super) {
        __extends(trainingSetupTop, _super);
        function trainingSetupTop(state, side, color) {
            _super.call(this, state);
            //static
            this.pos = 0;
            this.side = 0;
            this.isDown = false;
            this.isClicked = false;
            this.clickType = 'buildNodeBase';
            this.auto = false;
            this.side = side;
            this.state = state;
            this.color = color;
            this.side = side;

            //Objects
            var panel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.halfPanel, 0, 0);
            panel.rotation = Math.PI;
            panel.animation.switchTo(4);
            var tokensAndCallinsPanel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.tokenSpecialsPanel, 2, 1);
            var productImage = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.productImage, 46, 152);

            this.spentCredits = new Kiwi.GameObjects.Textfield(this.state, '00000', 179, 44, '#f2b831', 25, 'normal', 'venusRisingFont');
            this.avaCredits = new Kiwi.GameObjects.Textfield(this.state, this.game.commodityManager.creditsString, 364, 44, '#f2b831', 25, 'normal', 'venusRisingFont');

            this.spentCredits.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_RIGHT;
            this.avaCredits.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_RIGHT;

            var buyMore = new MenuEntities.MenuButton(this.state, this.state.textures.buyMore, 395, 17);
            buyMore.input.onEntered.add(function () {
                buyMore.cellIndex = 1;
            }, this);
            buyMore.input.onDown.add(function () {
                buyMore.cellIndex = 1;
            }, this);
            buyMore.input.onUp.add(function () {
                buyMore.cellIndex = 0;
                this.game.menuSFX.playSuccess();
                this.state.toTheStore();
            }, this);
            buyMore.input.onLeft.add(function () {
                buyMore.cellIndex = 0;
            }, this);

            this.addChild(panel);
            this.addChild(tokensAndCallinsPanel);
            this.addChild(productImage);
            this.addChild(this.spentCredits);
            this.addChild(this.avaCredits);

            this.addChild(buyMore);
        }
        trainingSetupTop.prototype.update = function () {
            _super.prototype.update.call(this);
        };
        return trainingSetupTop;
    })(Kiwi.Group);
    MenuEntities.trainingSetupTop = trainingSetupTop;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var trainingSetupBottom = (function (_super) {
        __extends(trainingSetupBottom, _super);
        function trainingSetupBottom(state, side, color, defaultUser) {
            _super.call(this, state);
            //Static
            this.pos = 0;
            this.side = 0;
            this.isDown = false;
            this.isClicked = false;
            this.clickType = 'buildNodeBase';
            this.auto = false;
            this.readyToStart = false;
            this.scrolling = false;
            this.scrollPointer = null;
            this.lastY = 92;
            this.initY = 0;
            this.scrollCoords = {
                min: 92,
                max: 293
            };
            this.side = side;
            this.state = state;
            this.color = color;
            this.side = side;
            this.readyToStart = false;

            this.selectedUser = defaultUser;

            //Objects
            var panel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.halfPanel, 0, 0);
            var smallPanel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.bottomSetupPanel, 0, 0);
            smallPanel.y = panel.height - smallPanel.height;
            this.buttonLeft = new MenuEntities.MenuButton(this.state, this.state.textures.colorSelectButtonsLeft, 325, 366);
            this.buttonRight = new MenuEntities.MenuButton(this.state, this.state.textures.colorSelectButtonsRight, 600, 366);
            this.colorButton = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.colourButton, 448, 362);
            var selectAccountPanel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.selectAccountPanel, 180, 62);
            this.readyButton = new MenuEntities.MenuButton(this.state, this.state.textures.readyButton, 400, 200);
            this.readyButton.x = panel.width - this.readyButton.width - 10;
            this.readyButton.y = panel.height - this.readyButton.height - 10;
            var usernameBlock = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.selectedPlayerBlock, 20, 445);
            usernameBlock.alpha = 0;
            var username;
            var notRegisteredButton;
            var playerNumberText;

            this.addChild(panel);
            this.addChild(smallPanel);
            this.addChild(this.buttonLeft);
            this.addChild(this.buttonRight);
            this.addChild(selectAccountPanel);
            this.addChild(this.readyButton);
            this.addChild(usernameBlock);

            this.colorButton.alpha = 0;
            this.addChild(this.colorButton);

            this.selectedUserText = new Kiwi.GameObjects.Textfield(this.state, this.selectedUser.name.toUpperCase(), 90, 448, '#000', 18);
            this.addChild(this.selectedUserText);

            //User Names and such
            this.userGroup = new Kiwi.Group(this.state);
            this.addChild(this.userGroup);

            this.scrollBar = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.scrollbar, 0, this.scrollCoords.min);
            this.scrollBar.x = 184 + 392 + 2; //X Location of user choice + width of the user choice + padding.
            this.addChild(this.scrollBar);

            this.updateUserList();

            this.game.input.onDown.add(this.pressedInput, this);
            this.game.input.onUp.add(this.releasedInput, this);
        }
        trainingSetupBottom.prototype.pressedInput = function (x, y, timeUp, timeDown, duration, pointer) {
            //Not currently scrolling and allow to continue
            if (this.scrolling == true)
                return;
            if (this.state.overlayActive)
                return;
            if (this.readyToStart)
                return;

            //Overlaps the scrollbar?
            if (this.scrollBar.box.worldHitbox.contains(x, y)) {
                this.startScrolling(pointer);
                return;
            }

            //Does the pointer intersect any userchoice?
            var members = this.userGroup.members;
            var member = null;
            for (var i = 0; i < members.length; i++) {
                member = members[i];

                if (member.visible && member.background.box.worldHitbox.contains(x, y)) {
                    //Allow the drag
                    this.startScrolling(pointer);
                    break;
                }
            }
        };

        trainingSetupBottom.prototype.releasedInput = function (x, y, timeUp, timeDown, duration, pointer) {
            this.stopScrolling(pointer);

            //Did the user scroll at all? Was the duration held for longer than 500 millisecond and did it move at all?
            if (pointer.duration > 500 || Kiwi.Utils.GameMath.difference(pointer.startPoint.y, pointer.endPoint.y) > 50)
                return;

            if (!this.readyToStart) {
                //Does it overlap any
                var members = this.userGroup.members;
                var member = null;
                for (var i = 0; i < members.length; i++) {
                    member = members[i];
                    if (member.visible && member.background.box.worldHitbox.contains(x, y)) {
                        this.choosenPlayer(member);
                        return;
                    }
                }
            }

            if (this.readyButton.box.worldHitbox.contains(x, y)) {
                this.readyHit();
                return;
            }

            if (this.state.overlayActive || this.readyToStart)
                return;

            if (this.buttonLeft.box.worldHitbox.contains(x, y)) {
                this.buttonLeftHit();
                return;
            }

            if (this.buttonRight.box.worldHitbox.contains(x, y)) {
                this.buttonRightHit();
                return;
            }
            if (this.colorButton.box.worldHitbox.contains(x, y)) {
                this.buttonRightHit();
                return;
            }
        };

        trainingSetupBottom.prototype.startScrolling = function (pointer) {
            this.scrolling = true;
            this.scrollPointer = pointer;
            this.initY = this.scrollPointer.y;
            this.lastY = this.scrollBar.y;
        };

        trainingSetupBottom.prototype.stopScrolling = function (pointer) {
            if (this.scrollPointer && pointer.id == this.scrollPointer.id) {
                this.scrolling = false;
                this.scrollPointer = null;
            }
        };

        trainingSetupBottom.prototype.update = function () {
            _super.prototype.update.call(this);

            if (this.scrolling) {
                var mouseMovementY = -(this.scrollPointer.y - this.initY);

                //Movement
                this.scrollBar.y = this.lastY;
                this.scrollBar.y += (this.side == 1) ? mouseMovementY : -mouseMovementY;

                //Constraints
                if (this.scrollBar.y < this.scrollCoords.min) {
                    this.scrollBar.y = this.scrollCoords.min;
                } else if (this.scrollBar.y > this.scrollCoords.max) {
                    this.scrollBar.y = this.scrollCoords.max;
                }

                //Update
                this.repositionUserList();
            }

            this.updateAnimations();
        };

        trainingSetupBottom.prototype.repositionUserList = function () {
            var members = this.userGroup.members;
            var y = this.scrollCoords.min;
            var spacing = 2;
            var maxMembers = 7;

            //Get the scrollbars y...
            //Get its percentage in the scrollbar its at.
            var percent = (this.scrollBar.y - this.scrollCoords.min) / (this.scrollCoords.max - this.scrollCoords.min);

            //Convert its percentage on-screen into which part of the user list to view.
            var start = Math.max(0, Math.round((members.length - maxMembers) * percent));
            var end = Math.min(start + maxMembers, start + members.length);
            var member = null;

            var sub = 0;
            for (var i = 0; i < members.length; i++) {
                member = members[i];

                if (i >= start && i < end) {
                    member.y = sub * (member.background.height + spacing) + y;
                    member.visible = true;
                    sub++;
                } else {
                    member.visible = false;
                }
            }
        };

        trainingSetupBottom.prototype.updateUserList = function () {
            var users = this.game.userManager.users;
            var x = 184;

            this.userGroup.removeChildren(0, this.userGroup.numChildren(), true);

            for (var i = 0; i < users.length; i++) {
                //UserChoice
                var userChoice = new MenuEntites.UserChoice(this.state, 0, 0, i + 1, users[i]);
                userChoice.visible = false;
                userChoice.x = x;
                userChoice.y = 1000;
                userChoice.setColor(this.state['side' + this.side + 'Colour']);
                this.userGroup.addChild(userChoice);
            }

            this.repositionUserList();
        };

        trainingSetupBottom.prototype.choosenPlayer = function (option) {
            if (!option.visible)
                return;
            if (this.state.overlayActive)
                return;

            var user = option.user;

            //Guest account or is valid then allow
            if (user.guest || user.isValid) {
                this.selectedUser = user;
                this.selectedUserText.text = this.selectedUser.name.toUpperCase();
                //If not valid then login
            } else if (!user.isValid) {
                if (this.game.webview.available) {
                    this.state.overlayActive = true;

                    //Is the webview avaiable?
                    this.game.webview.showLogin(this.state.webviewCallback, this.state, 'Login', user.name);
                } else {
                    //Complete lies....
                    console.log('Sorry we couldn\'t launch the login screen at this moment. Please re-launch the app to try again.');
                }
            }
        };
        trainingSetupBottom.prototype.readyHit = function () {
            this.readyToStart = true;
            this.game.menuSFX.playSuccess();
            this.state.startSettings();
        };
        trainingSetupBottom.prototype.buttonLeftHit = function () {
            if (this.state.overlayActive)
                return;
            this.state.colourLeft(this.side);
        };
        trainingSetupBottom.prototype.buttonRightHit = function () {
            if (this.state.overlayActive)
                return;
            this.state.colourRight(this.side);
        };
        trainingSetupBottom.prototype.updateAnimations = function () {
            //back panel
            this.getChildAt(0).animation.switchTo(this.state['side' + this.side + 'Colour']);

            //bottom panel
            this.getChildAt(1).animation.switchTo(this.state['side' + this.side + 'Colour']);

            //left button
            this.getChildAt(2).animation.switchTo(this.state['side' + this.side + 'Colour'] * 2);

            //right button
            this.getChildAt(3).animation.switchTo(this.state['side' + this.side + 'Colour'] * 2);

            //select account panel
            this.getChildAt(4).animation.switchTo(this.state['side' + this.side + 'Colour']);

            //ready button
            this.getChildAt(5).animation.switchTo(this.state['side' + this.side + 'Colour'] * 2);

            //usernameBlock
            this.getChildAt(6).animation.switchTo(this.state['side' + this.side + 'Colour']);

            //Loop through the user choices
            this.userGroup.forEach(this, function (child) {
                if (this.selectedUser && child.user.name == this.selectedUser || !this.selectedUser && child.user.guest) {
                    child.setColor(this.state['side' + this.side + 'Colour'] + 4);
                } else {
                    child.setColor(this.state['side' + this.side + 'Colour']);
                }
            });
            this.scrollBar.animation.switchTo(this.state['side' + this.side + 'Colour']);
        };
        return trainingSetupBottom;
    })(Kiwi.Group);
    MenuEntities.trainingSetupBottom = trainingSetupBottom;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var trainingSettingsTop = (function (_super) {
        __extends(trainingSettingsTop, _super);
        function trainingSettingsTop(state, side, color) {
            _super.call(this, state);
            //static
            this.pos = 0;
            this.side = 0;
            this.isDown = false;
            this.isClicked = false;
            this.clickType = 'buildNodeBase';
            this.auto = false;
            this.side = side;
            this.state = state;
            this.color = color;
            this.side = side;

            //Objects
            var panel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.halfPanel, 0, 0);
            panel.rotation = Math.PI;
            panel.animation.switchTo(4);
            var tokensAndCallinsPanel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.tokensAndCallinsPanel, 2, 1);

            var buyMore = new MenuEntities.MenuButton(this.state, this.state.textures.buyMore, 395, 17);
            buyMore.input.onEntered.add(function () {
                buyMore.cellIndex = 1;
            }, this);
            buyMore.input.onDown.add(function () {
                buyMore.cellIndex = 1;
            }, this);
            buyMore.input.onUp.add(function () {
                buyMore.cellIndex = 0;
                this.game.menuSFX.playSuccess();
                this.state.toTheStore();
            }, this);
            buyMore.input.onLeft.add(function () {
                buyMore.cellIndex = 0;
            }, this);

            this.slot1 = new MenuEntities.TrainingSettingsCallinPanel(this, 0, 0, 280, 150, 9);
            this.slot2 = new MenuEntities.TrainingSettingsCallinPanel(this, 1, 0, 440, 150, 8);
            this.slot3 = new MenuEntities.TrainingSettingsCallinPanel(this, 2, 0, 600, 150, 6);

            this.intelligence = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.intelligence, 33, 161);

            this.spentCredits = new Kiwi.GameObjects.Textfield(this.state, this.game.commodityManager.spentCreditsString, 179, 44, '#f2b831', 25, 'normal', 'venusRisingFont');
            this.avaCredits = new Kiwi.GameObjects.Textfield(this.state, this.game.commodityManager.creditsString, 364, 44, '#f2b831', 25, 'normal', 'venusRisingFont');

            this.spentCredits.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_RIGHT;
            this.avaCredits.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_RIGHT;

            this.credits = this.game.commodityManager.credits;
            this.spent = this.game.commodityManager.spentCredits;
            this.updateCredits();

            this.addChild(panel);
            this.addChild(tokensAndCallinsPanel);
            this.addChild(buyMore);
            this.addChild(this.slot1);
            this.addChild(this.slot2);
            this.addChild(this.slot3);
            this.addChild(this.spentCredits);
            this.addChild(this.avaCredits);

            this.addChild(this.intelligence);

            this.setDefaults();
        }
        trainingSettingsTop.prototype.setDefaults = function () {
            var i = 0;
            var enoughCredits = false;
            while (i < 3) {
                this.slot1.increaseQuantity(false);
                this.slot2.increaseQuantity(false);
                this.slot3.increaseQuantity(false);

                i++;
            }
        };

        trainingSettingsTop.prototype.checkQuanities = function () {
            if (this.credits - this.creditsBeingUsed >= 0) {
                return true;
            } else {
                return false;
            }
        };

        Object.defineProperty(trainingSettingsTop.prototype, "creditsBeingUsed", {
            get: function () {
                return this.slot1.creditsUsed + this.slot2.creditsUsed + this.slot3.creditsUsed;
            },
            enumerable: true,
            configurable: true
        });

        trainingSettingsTop.prototype.updateCredits = function () {
            this.avaCredits.text = this.game.commodityManager.convertCreditsToString(this.credits - this.creditsBeingUsed);
            this.spentCredits.text = this.game.commodityManager.convertCreditsToString(this.creditsBeingUsed);
        };

        trainingSettingsTop.prototype.update = function () {
            _super.prototype.update.call(this);
            this.updateCredits();
        };
        trainingSettingsTop.prototype.readyHit = function () {
            this.state.startSettings();
        };
        trainingSettingsTop.prototype.updateIntelligence = function (frame) {
            this.intelligence.animation.switchTo(frame);
        };
        return trainingSettingsTop;
    })(Kiwi.Group);
    MenuEntities.trainingSettingsTop = trainingSettingsTop;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var trainingSettingsBottom = (function (_super) {
        __extends(trainingSettingsBottom, _super);
        function trainingSettingsBottom(state, side, color) {
            _super.call(this, state);
            //static
            this.pos = 0;
            this.side = 0;
            this.isDown = false;
            this.isClicked = false;
            this.clickType = 'buildNodeBase';
            this.auto = false;
            this.side = side;
            this.state = state;
            this.color = color;
            this.side = side;
            switch (color) {
                case 0:
                    //blue
                    this.fontColor = '#0052c4';
                    break;
                case 1:
                    //red;
                    this.fontColor = '#ff0000';
                    break;
                case 2:
                    //green
                    this.fontColor = '#008900';
                    break;
                case 3:
                    //purple
                    this.fontColor = '#a800ff';
                    break;
                default:
                    this.fontColor = '#0052c4';
            }

            //Objects
            var panel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.halfPanel, 0, 0);
            panel.animation.switchTo(color);
            var smallPanel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.trainingSettingsPanel, 0, 70);
            smallPanel.animation.switchTo(color);

            //slot1
            var slot1Text = new Kiwi.GameObjects.Textfield(this.state, 'Slot1', 660, 212, this.fontColor, 25, 'normal', 'venusRisingFont');
            slot1Text.name = 'slot1Text';
            slot1Text.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;

            //s2
            var slot2Text = new Kiwi.GameObjects.Textfield(this.state, 'Slot2', 660, 281, this.fontColor, 25, 'normal', 'venusRisingFont');
            slot2Text.name = 'slot2Text';
            slot2Text.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;

            //s3
            var slot3Text = new Kiwi.GameObjects.Textfield(this.state, 'Slot3', 660, 355, this.fontColor, 25, 'normal', 'venusRisingFont');
            slot3Text.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;
            slot3Text.name = 'slot3Text';

            var readyButton = new MenuEntities.MenuButton(this.state, this.state.textures.readyButton, 400, 200);

            readyButton.animation.switchTo(color * 2);
            readyButton.x = panel.width - readyButton.width - 10;
            readyButton.y = panel.height - readyButton.height - 10;

            var tutorialOnOff = new MenuEntities.MenuButton(this.state, this.state.textures.tutorialOnOff, 104, 457);
            tutorialOnOff.animation.switchTo(this.color * 2);
            tutorialOnOff.name = 'tutorialOnOff';

            this.addChild(panel);
            this.addChild(smallPanel);

            this.addChild(slot1Text);
            this.addChild(slot2Text);
            this.addChild(slot3Text);
            this.addChild(tutorialOnOff);

            this.addChild(readyButton);

            readyButton.input.onUp.add(this.readyHit, this);

            tutorialOnOff.input.onUp.add(this.toggleTut, this);
        }
        trainingSettingsBottom.prototype.create = function () {
            if (this.state.game.saveManager.exists('playTutorial') == true) {
                this.state.game.playTutorial = false;
            }
        };
        trainingSettingsBottom.prototype.update = function () {
            _super.prototype.update.call(this);

            var temp = this.getChildByName('slot1Text');
            temp.text = this.state.side2.slot1.quantity + "";
            temp = this.getChildByName('slot2Text');
            temp.text = this.state.side2.slot2.quantity + "";
            temp = this.getChildByName('slot3Text');
            temp.text = this.state.side2.slot3.quantity + "";

            temp = this.getChildByName('tutorialOnOff');
            if (this.state.game.playTutorial) {
                temp.animation.switchTo(this.color * 4);
            } else {
                temp.animation.switchTo(this.color * 4 + 2);
            }
        };
        trainingSettingsBottom.prototype.readyHit = function () {
            this.game.menuSFX.playSuccess();
            this.state.startSettings();
        };
        trainingSettingsBottom.prototype.registerHit = function () {
        };
        trainingSettingsBottom.prototype.toggleTut = function () {
            this.game.menuSFX.playSuccess();
            this.state.game.playTutorial = !this.state.game.playTutorial;
        };
        return trainingSettingsBottom;
    })(Kiwi.Group);
    MenuEntities.trainingSettingsBottom = trainingSettingsBottom;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var TrainingSettingsCallinPanel = (function (_super) {
        __extends(TrainingSettingsCallinPanel, _super);
        function TrainingSettingsCallinPanel(training, type, quantity, x, y, cost) {
            _super.call(this, training.state);
            //static
            this.isClicked = false;
            this.clickType = 'buildNodeBase';
            this.auto = false;
            this.cost = 5;
            this.trainingPanel = training;
            this.type = type;
            this.quantity = quantity;
            this.x = x;
            this.y = y;
            this.cost = cost;

            this.updateCreditsUsed();

            //Objects
            var leftButton = new MenuEntities.MenuButtonIncrement(this.state, this.state.textures.leftArrow, 15, 10, 8);
            var rightButton = new MenuEntities.MenuButtonIncrement(this.state, this.state.textures.rightArrow, 85, 10, 8);
            leftButton.animation.switchTo(8);
            rightButton.animation.switchTo(8);

            var plusButton = new MenuEntities.MenuButtonIncrement(this.state, this.state.textures.plus, 85, 171, 8);
            var minusButton = new MenuEntities.MenuButtonIncrement(this.state, this.state.textures.minus, 15, 171, 8);
            plusButton.animation.switchTo(8);
            minusButton.animation.switchTo(8);

            var typeSprite = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.callinsSpriteSheet, 25, 95);
            typeSprite.name = 'typeSprite';
            this.addChild(typeSprite);

            var creditIcon = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.tokenSymbol, 95, 144);
            this.addChild(creditIcon);

            var typeText = new Kiwi.GameObjects.Textfield(this.state, '0', 80, 77, '#edb61c', 11, 'normal', 'venusRisingFont');
            var costText = new Kiwi.GameObjects.Textfield(this.state, this.cost.toString(), 137, 136, '#edb61c', 25, 'normal', 'venusRisingFont');
            var quantityText = new Kiwi.GameObjects.Textfield(this.state, 'xxx', 80, 267, '#edb61c', 30, 'normal', 'venusRisingFont');

            //var slot3Textfield = new Kiwi.GameObjects.Textfield(this.state, '0', 650, 250, '#FFFFFF', 18, 'normal', 'playFont');
            typeText.name = 'typeText';
            quantityText.name = 'quantityText';

            //slot3Textfield.name = 'slot3Textfield';
            typeText.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;

            costText.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_RIGHT;
            quantityText.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;

            var updateIntelButton = new MenuEntities.MenuButtonIncrement(this.state, this.state.textures.displayInfo, 90, 95, 0);

            this.addChild(plusButton);
            this.addChild(minusButton);

            //these buttons are for switching callin types
            // this.addChild(leftButton);
            // this.addChild(rightButton);
            this.addChild(typeText);
            this.addChild(quantityText);
            this.addChild(costText);
            this.addChild(updateIntelButton);

            if (this.game.commodityManager.hasElite) {
                minusButton.input.onDown.add(this.minusButtonHit, this);
                plusButton.input.onDown.add(this.plusButtonHit, this);
            } else {
                /*
                plusButton.cellIndex = 10;
                minusButton.cellIndex = 10;
                plusButton.upFrame = 10;
                minusButton.upFrame = 10;
                */
                minusButton.input.onDown.add(this.purchaseElite, this);
                plusButton.input.onDown.add(this.purchaseElite, this);
            }

            updateIntelButton.input.onDown.add(function () {
                this.updateIntelHit();
                this.game.menuSFX.playSuccess();
            }, this);
            //leftButton.input.onDown.add(this.leftButtonHit, this);
            //rightButton.input.onDown.add(this.rightButtonHit, this);
        }
        TrainingSettingsCallinPanel.prototype.update = function () {
            _super.prototype.update.call(this);
            var temp = this.getChildByName('typeText');
            switch (this.type) {
                case 0:
                    temp.text = 'Alpha Team';
                    break;

                case 1:
                    temp.text = 'Airstrike';
                    break;

                case 2:
                    temp.text = 'Heal Beam';
                    break;

                default:
                    temp.text = 'Out of range';
            }

            temp = this.getChildByName('quantityText');
            temp.text = this.quantity + "";
            temp = this.getChildByName('typeSprite');
            temp.animation.switchTo(this.type);
        };

        TrainingSettingsCallinPanel.prototype.updateCreditsUsed = function () {
            this.creditsUsed = this.quantity * this.cost;
        };

        TrainingSettingsCallinPanel.prototype.purchaseElite = function () {
            this.game.menuSFX.playError();
            this.updateIntelHit();
        };

        TrainingSettingsCallinPanel.prototype.minusButtonHit = function () {
            this.updateIntelHit();
            this.decreaseQuantity();
        };

        TrainingSettingsCallinPanel.prototype.plusButtonHit = function () {
            this.updateIntelHit();
            this.increaseQuantity();
        };

        TrainingSettingsCallinPanel.prototype.decreaseQuantity = function (sound) {
            if (typeof sound === "undefined") { sound = true; }
            //If it can be decreased, then decrease it
            if (this.quantity - 1 >= 0) {
                this.quantity--;
                this.updateCreditsUsed(); //HORID WAY OF DOING IT.... Should check before hand...

                if (this.trainingPanel.checkQuanities() == false) {
                    this.quantity++;
                    this.updateCreditsUsed();
                    if (!sound)
                        this.game.menuSFX.playError();
                } else {
                    if (!sound)
                        this.game.menuSFX.playSuccess();
                }
            }
        };

        TrainingSettingsCallinPanel.prototype.increaseQuantity = function (sound) {
            if (typeof sound === "undefined") { sound = true; }
            //Can the quantity be increased?
            if (this.quantity + 1 <= this.state.parameters.CALL_IN_MAXIMUM) {
                this.quantity++;
                this.updateCreditsUsed();

                //Do we have enough credits?
                if (this.trainingPanel.checkQuanities() == false) {
                    this.quantity--;
                    this.updateCreditsUsed();

                    //if(!sound) //Play error sound
                    this.game.menuSFX.playError();
                } else {
                    //if (!sound) //Play success sound
                    this.game.menuSFX.playSuccess();
                }
            }
        };

        TrainingSettingsCallinPanel.prototype.leftButtonHit = function () {
            this.type--;
            if (this.type < 0) {
                this.type = 2;
            }
        };
        TrainingSettingsCallinPanel.prototype.rightButtonHit = function () {
            this.type++;
            if (this.type > 2) {
                this.type = 0;
            }
        };
        TrainingSettingsCallinPanel.prototype.updateIntelHit = function () {
            this.trainingPanel.updateIntelligence(this.type + 1);
        };
        return TrainingSettingsCallinPanel;
    })(Kiwi.Group);
    MenuEntities.TrainingSettingsCallinPanel = TrainingSettingsCallinPanel;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var storeBottom = (function (_super) {
        __extends(storeBottom, _super);
        function storeBottom(state, side, color) {
            _super.call(this, state);
            //static
            this.pos = 0;
            this.side = 0;
            this.isDown = false;
            this.isClicked = false;
            this.clickType = 'buildNodeBase';
            this.auto = false;
            this.side = side;
            this.state = state;
            this.color = color;
            this.side = side;

            //Objects
            var panel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.halfPanel, 0, 0);
            var storeBottomPanel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.storeBottomPanel, -1, 75);

            this.upgradeToElite = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.productImage, 44, 140);
            this.upgradedToElite = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.productThanks, 44, 140);

            this.addChild(panel);
            this.addChild(storeBottomPanel);
            this.addChild(this.upgradeToElite);
            this.addChild(this.upgradedToElite);

            this.eliteStatus();
        }
        storeBottom.prototype.update = function () {
            _super.prototype.update.call(this);
            this.eliteStatus();
        };

        storeBottom.prototype.eliteStatus = function () {
            if (this.game.commodityManager.hasElite) {
                this.upgradedToElite.visible = true;
                this.upgradeToElite.visible = false;
            } else {
                this.upgradedToElite.visible = false;
                this.upgradeToElite.visible = true;
            }
        };
        return storeBottom;
    })(Kiwi.Group);
    MenuEntities.storeBottom = storeBottom;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var storeTop = (function (_super) {
        __extends(storeTop, _super);
        function storeTop(state, purchaseManager, side, color) {
            _super.call(this, state);
            //static
            this.pos = 0;
            this.side = 0;
            this.isDown = false;
            this.isClicked = false;
            this.clickType = 'buildNodeBase';
            this.auto = false;
            this.side = side;
            this.state = state;
            this.color = color;
            this.side = side;

            this.purchaseManager = purchaseManager;

            //Objects
            var panel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.halfPanel, 0, 0);
            panel.rotation = Math.PI;
            panel.animation.switchTo(4);
            var storeTopPanel = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.storeTopPanel, 149, 17);

            this.product1 = new MenuEntities.StoreProduct(this.state, this.state.textures.product3, this.purchaseManager.productIds[0], 151, 152, this.purchaseInvander, this);
            this.product2 = new MenuEntities.StoreProduct(this.state, this.state.textures.product1, this.purchaseManager.productIds[1], 311, 152, this.purchaseConqueror, this);
            this.product3 = new MenuEntities.StoreProduct(this.state, this.state.textures.product2, this.purchaseManager.productIds[2], 471, 152, this.purchaseRaider, this);

            this.credits = new Kiwi.GameObjects.Textfield(this.state, '', 458, 60, '#f2b831', 25, 'normal', 'venusRisingFont');
            this.credits.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_RIGHT;
            this.updateCredits();

            this.addChild(panel);
            this.addChild(storeTopPanel);
            this.addChild(this.credits);

            this.addChild(this.product1);
            this.addChild(this.product2);
            this.addChild(this.product3);

            /**
            * Only add them when validated
            **/
            this.purchaseManager.getValidProducts(function (success, products) {
                //Failure, they need an internet connection or better things...
                if (success == false)
                    return;

                var currentProd = null;

                for (var i = 0; i < products.length; i++) {
                    currentProd = products[i];

                    if (currentProd.productId == this.product1.productId) {
                        this.product1.assign(currentProd);
                        continue;
                    }

                    if (currentProd.productId == this.product2.productId) {
                        this.product2.assign(currentProd);
                        continue;
                    }

                    if (currentProd.productId == this.product3.productId) {
                        this.product3.assign(currentProd);
                        continue;
                    }
                }
            }, this);
        }
        storeTop.prototype.purchaseInvander = function () {
            //Purchase this one!
            this.game.menuSFX.playSuccess();
            this.purchaseManager.purchase(this.product1.product, function (success, purchase) {
                if (success && this.game) {
                    this.updateCredits();
                }
            }, this);
        };

        storeTop.prototype.purchaseConqueror = function () {
            this.game.menuSFX.playSuccess();
            this.purchaseManager.purchase(this.product2.product, function (success, purchase) {
                if (success && this.game) {
                    this.updateCredits();
                }
            }, this);
        };

        storeTop.prototype.purchaseRaider = function () {
            this.game.menuSFX.playSuccess();
            this.purchaseManager.purchase(this.product3.product, function (success, purchase) {
                if (success && this.game) {
                    this.updateCredits();
                }
            }, this);
        };

        storeTop.prototype.updateCredits = function () {
            this.credits.text = this.game.commodityManager.creditsString;
        };

        storeTop.prototype.update = function () {
            _super.prototype.update.call(this);
            this.updateCredits();
        };
        return storeTop;
    })(Kiwi.Group);
    MenuEntities.storeTop = storeTop;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var StorePanel = (function (_super) {
        __extends(StorePanel, _super);
        function StorePanel(state, type, x, y) {
            _super.call(this, state);
            //static
            this.isClicked = false;
            this.clickType = 'buildNodeBase';
            this.auto = false;
            this.state = state;
            this.type = type;
            this.x = x;
            this.y = y;

            //Objects
            var leftButton = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.leftArrow, 15, 10);
            var rightButton = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.rightArrow, 85, 10);
            leftButton.animation.switchTo(8);
            rightButton.animation.switchTo(8);

            var plusButton = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.plus, 85, 171);
            var minusButton = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.minus, 15, 171);
            plusButton.animation.switchTo(8);
            minusButton.animation.switchTo(8);

            var typeSprite = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.callinsSpriteSheet, 25, 95);
            typeSprite.name = 'typeSprite';
            this.addChild(typeSprite);

            var creditIcon = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.tokenSymbol, 105, 144);
            this.addChild(creditIcon);

            var typeText = new Kiwi.GameObjects.Textfield(this.state, '0', 82, 75, '#edb61c', 12, 'normal', 'venusRisingFont');
            var costText = new Kiwi.GameObjects.Textfield(this.state, '5', 141, 144, '#edb61c', 18, 'normal', 'venusRisingFont');
            var quantityText = new Kiwi.GameObjects.Textfield(this.state, 'xxx', 130, 275, '#edb61c', 18, 'normal', 'venusRisingFont');

            //var slot3Textfield = new Kiwi.GameObjects.Textfield(this.state, '0', 650, 250, '#FFFFFF', 18, 'normal', 'playFont');
            typeText.name = 'typeText';
            quantityText.name = 'quantityText';

            //slot3Textfield.name = 'slot3Textfield';
            typeText.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_CENTER;

            costText.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_RIGHT;
            quantityText.textAlign = Kiwi.GameObjects.Textfield.TEXT_ALIGN_RIGHT;

            this.addChild(plusButton);
            this.addChild(minusButton);

            this.addChild(leftButton);
            this.addChild(rightButton);

            this.addChild(typeText);
            this.addChild(quantityText);
            this.addChild(costText);

            minusButton.input.onDown.add(this.minusButtonHit, this);
            plusButton.input.onDown.add(this.plusButtonHit, this);
            leftButton.input.onDown.add(this.leftButtonHit, this);
            rightButton.input.onDown.add(this.rightButtonHit, this);
        }
        StorePanel.prototype.update = function () {
            _super.prototype.update.call(this);
            var temp = this.getChildByName('typeText');
            switch (this.type) {
                case 0:
                    temp.text = 'Alpha Team';
                    break;

                case 1:
                    temp.text = 'Airstrike';
                    break;

                case 2:
                    temp.text = 'Heal Beam';
                    break;

                default:
                    temp.text = 'Out of range';
            }

            temp = this.getChildByName('quantityText');
            temp.text = this.quantity + "";
            temp = this.getChildByName('typeSprite');
            temp.animation.switchTo(this.type);
        };
        StorePanel.prototype.minusButtonHit = function () {
            this.quantity--;
            if (this.quantity < 0) {
                this.quantity = this.state.parameters.CALL_IN_MAXIMUM;
            }
        };
        StorePanel.prototype.plusButtonHit = function () {
            this.quantity++;
            if (this.quantity > this.state.parameters.CALL_IN_MAXIMUM) {
                this.quantity = 0;
            }
        };

        StorePanel.prototype.leftButtonHit = function () {
            this.type--;
            if (this.type < 0) {
                this.type = 2;
            }
        };
        StorePanel.prototype.rightButtonHit = function () {
            this.type++;
            if (this.type > 2) {
                this.type = 0;
            }
        };
        return StorePanel;
    })(Kiwi.Group);
    MenuEntities.StorePanel = StorePanel;
})(MenuEntities || (MenuEntities = {}));
var MenuEntites;
(function (MenuEntites) {
    var AnimatedBackground = (function (_super) {
        __extends(AnimatedBackground, _super);
        function AnimatedBackground(state) {
            _super.call(this, state);
            //static
            this.pos = 0;
            this.side = 0;
            this.isDown = false;
            this.isClicked = false;
            this.clickType = 'buildNodeBase';
            this.auto = false;
            this.state = state;
        }
        AnimatedBackground.prototype.update = function () {
            _super.prototype.update.call(this);
        };
        AnimatedBackground.prototype.changeColorUp = function () {
            console.log("Hit Zach");
        };
        AnimatedBackground.prototype.changeColorDown = function () {
        };
        AnimatedBackground.prototype.readyHit = function () {
        };
        AnimatedBackground.prototype.registerHit = function () {
        };
        return AnimatedBackground;
    })(Kiwi.Group);
    MenuEntites.AnimatedBackground = AnimatedBackground;
})(MenuEntites || (MenuEntites = {}));
var MenuEntities;
(function (MenuEntities) {
    var MenuButton = (function (_super) {
        __extends(MenuButton, _super);
        //this['mouseStartX' + num], this['mouseStartY' + num], line.angle, num, type, level, formBool
        function MenuButton(state, textureID, x, y) {
            _super.call(this, state, textureID, x, y);
            //static
            this.contentType = 0;
            this.type = 0;
            this.level = 0;
            this.side = 0;
            this.switchedToUp = false;
            this.state = state;

            // this.x = x;
            //this.y = y;
            this.input.onDown.add(this.down, this);
            this.input.onUp.add(this.up, this);
            this.input.onLeft.add(this.left, this);
        }
        MenuButton.prototype.update = function () {
            _super.prototype.update.call(this);
        };
        MenuButton.prototype.down = function () {
            this.animation.switchTo(this.animation.frameIndex + 1);
            this.switchedToUp = false;
        };

        MenuButton.prototype.up = function () {
            if (this.input.isDown && !this.switchedToUp) {
                this.animation.switchTo(this.animation.frameIndex - 1);
            }
        };

        MenuButton.prototype.left = function () {
            if (this.input.isDown) {
                this.animation.switchTo(this.animation.frameIndex - 1);
                this.switchedToUp = true;
                //this.input.isDown = false;
            }
        };
        return MenuButton;
    })(Kiwi.GameObjects.Sprite);
    MenuEntities.MenuButton = MenuButton;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var backgroundShip = (function (_super) {
        __extends(backgroundShip, _super);
        //this['mouseStartX' + num], this['mouseStartY' + num], line.angle, num, type, level, formBool
        function backgroundShip(state, textureID, x, y, size) {
            _super.call(this, state, textureID, x, y);
            //static
            this.contentType = 0;
            this.type = 0;
            this.level = 0;
            this.side = 0;
            this.switchedToUp = false;
            this.state = state;

            // this.x = x;
            //this.y = y;
            this.x = Math.random() * this.game.stage.width;
            this.y = Math.random() * this.game.stage.height;
            this.animation.play();

            if (textureID.name == 'destroyerClose' || textureID.name == 'destroyerMedium' || textureID.name == 'destroyerDistant') {
                this.animation.add('fly', [0, 1, 2], 0.05, true);
            } else {
                this.animation.add('fly', [0, 1, 2, 3, 4, 5], 0.05, true);
            }
            this.animation.play('fly');

            switch (size) {
                case 0:
                    //Small
                    //speed
                    this.xSpeed = Math.random() * 1 + 1;
                    this.ySpeed = this.xSpeed / 3;

                    break;
                case 1:
                    //medium
                    this.xSpeed = Math.random() * 2 + 2;
                    this.ySpeed = this.xSpeed / 3;
                    break;
                case 2:
                    //big
                    this.xSpeed = Math.random() * 4 + 4;
                    this.ySpeed = this.xSpeed / 3;

                    break;
            }
        }
        backgroundShip.prototype.update = function () {
            _super.prototype.update.call(this);
            if (this.x < -600) {
                this.resetShip();
            }
            this.x -= this.xSpeed;
            this.y += this.ySpeed;
        };
        backgroundShip.prototype.resetShip = function () {
            this.x = this.state.game.stage.width + 300;
            this.y = Math.random() * (this.state.game.stage.height);
        };
        return backgroundShip;
    })(Kiwi.GameObjects.Sprite);
    MenuEntities.backgroundShip = backgroundShip;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var backgroundClouds = (function (_super) {
        __extends(backgroundClouds, _super);
        //this['mouseStartX' + num], this['mouseStartY' + num], line.angle, num, type, level, formBool
        function backgroundClouds(state, textureID, x, y, size) {
            _super.call(this, state, textureID, x, y);
            //static
            this.contentType = 0;
            this.type = 0;
            this.level = 0;
            this.side = 0;
            this.switchedToUp = false;
            this.state = state;

            // this.x = x;
            //this.y = y;
            this.x = 0 - Math.random() * this.game.stage.width;
            this.y = 450 + (Math.random() * this.game.stage.height * 0.5);

            this.xSpeed = -0.4;
            this.ySpeed = -0.2;

            switch (size) {
                case 0:
                    //Small
                    //speed
                    this.xSpeed = -0.2;
                    this.ySpeed = 0.1;

                    break;
                case 1:
                    //medium
                    this.xSpeed = -0.4;
                    this.ySpeed = -0.2;
                    break;
            }
        }
        backgroundClouds.prototype.update = function () {
            _super.prototype.update.call(this);
            if (this.x > 1024) {
                this.resetShip();
            }

            this.x -= this.xSpeed;
            this.y += this.ySpeed;
        };
        backgroundClouds.prototype.resetShip = function () {
            this.x = 0 - 1024;
            this.y = 450 + (Math.random() * this.game.stage.height * 0.5);
        };
        return backgroundClouds;
    })(Kiwi.GameObjects.Sprite);
    MenuEntities.backgroundClouds = backgroundClouds;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var backgroundAnimations = (function (_super) {
        __extends(backgroundAnimations, _super);
        function backgroundAnimations(state) {
            _super.call(this, state);
            this.masterWiggleX = 0;
            this.masterWiggleY = 0;
            this.maximumWiggle1 = 2;
            this.maximumWiggle2 = 5;
            this.maximumWiggle3 = 10;
            this.maximumWhirl = 0.5;
            this.shipAmount = 2;
            this.state = state;
            this.shipsD = new Kiwi.Group(this.state);
            this.shipsM = new Kiwi.Group(this.state);
            this.shipsC = new Kiwi.Group(this.state);

            this.wigglePrime = [0.0002879, 0.0002897, 0.0003203, 0.0003121, 0.0002621, 0.000563];

            this.background = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.spaceBlack, 0, 0);
            this.backgroundGroup1 = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.spaceBlueNebula, 0, 0);

            this.backgroundGroup2 = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.spacePinkNebula, 250, 250);
            this.backgroundGroup3 = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.spacePinkClouds, 500, 600);
            this.backgroundGroup3.alpha = 0.7;
            this.backgroundStars = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.spaceStar, -3, -17);
            this.planet = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.spacePlanet, 400, 400);

            //this.state.addChild(this.background);
            this.state.addChild(this.backgroundStars);
            this.state.addChild(this.backgroundGroup1);
            this.state.addChild(this.shipsD);
            this.state.addChild(this.backgroundGroup2);
            this.state.addChild(this.planet);
            this.state.addChild(this.shipsM);
            this.state.addChild(this.backgroundGroup3);

            this.state.addChild(this.shipsC);

            for (var i = 0; i <= this.shipAmount; i++) {
                var texture;
                switch (i) {
                    case 0:
                        texture = 'bomber';
                        break;
                    case 1:
                        texture = 'helicopter';
                        break;
                    case 2:
                        texture = 'destroyer';
                        break;
                }

                var tempShip = new MenuEntities.backgroundShip(this.state, this.state.textures[texture + 'Close'], 0, 0, 2);
                this.shipsC.addChild(tempShip);
                tempShip = new MenuEntities.backgroundShip(this.state, this.state.textures[texture + 'Medium'], 0, 0, 1);
                this.shipsM.addChild(tempShip);
                tempShip = new MenuEntities.backgroundShip(this.state, this.state.textures[texture + 'Distant'], 0, 0, 0);
                this.shipsD.addChild(tempShip);
            }
        }
        backgroundAnimations.prototype.update = function () {
            _super.prototype.update.call(this);
            this.masterWiggleX = Math.cos(Date.now() * this.wigglePrime[0]) * Math.cos(Date.now() * this.wigglePrime[1]) * Math.cos(Date.now() * this.wigglePrime[2]);
            this.masterWiggleY = Math.sin(Date.now() * this.wigglePrime[3]) * Math.sin(Date.now() * this.wigglePrime[4]) * Math.sin(Date.now() * this.wigglePrime[5]);
            this.backgroundGroup1.x = this.masterWiggleX * this.maximumWiggle1;
            this.backgroundGroup1.y = this.masterWiggleY * this.maximumWiggle1;

            this.backgroundGroup2.x = this.masterWiggleX * this.maximumWiggle2 + 100;
            this.backgroundGroup2.y = this.masterWiggleY * this.maximumWiggle2 + 150;

            this.backgroundGroup3.x = this.masterWiggleX * this.maximumWiggle3 + 200;
            this.backgroundGroup3.y = this.masterWiggleY * this.maximumWiggle3 + 350;
            //this.backgroundGroup1.rotation = this.maximumWhirl * this.masterWiggleX;
            //console.log(this.masterWiggle, Date.now());
        };
        return backgroundAnimations;
    })(Kiwi.Group);
    MenuEntities.backgroundAnimations = backgroundAnimations;
})(MenuEntities || (MenuEntities = {}));
var MenuEntites;
(function (MenuEntites) {
    var UserChoice = (function (_super) {
        __extends(UserChoice, _super);
        function UserChoice(state, x, y, userNum, user) {
            _super.call(this, state);
            this.x = x;
            this.y = y;

            this.user = user;

            this.background = new Kiwi.GameObjects.Sprite(this.state, this.state.textures.accountNameBlock, 0, 0);
            this.addChild(this.background);

            this.text = new Kiwi.GameObjects.Textfield(this.state, this.user.name.toUpperCase(), 40, 5, '#000', 18);
            this.numberText = new Kiwi.GameObjects.Textfield(this.state, userNum + '.', 5, 5, '#000', 18);

            this.addChild(this.numberText);
            this.addChild(this.text);

            this.input = this.background.input;
        }
        UserChoice.prototype.setColor = function (side) {
            this.background.cellIndex = side;
        };
        return UserChoice;
    })(Kiwi.Group);
    MenuEntites.UserChoice = UserChoice;
})(MenuEntites || (MenuEntites = {}));
var MenuEntities;
(function (MenuEntities) {
    var MenuButtonIncrement = (function (_super) {
        __extends(MenuButtonIncrement, _super);
        //this['mouseStartX' + num], this['mouseStartY' + num], line.angle, num, type, level, formBool
        function MenuButtonIncrement(state, textureID, x, y, upFrame) {
            _super.call(this, state, textureID, x, y);
            //static
            this.contentType = 0;
            this.type = 0;
            this.level = 0;
            this.side = 0;
            this.state = state;
            this.upFrame = upFrame;

            // this.x = x;
            //this.y = y;
            this.input.onDown.add(this.down, this);
            this.input.onUp.add(this.up, this);
            this.input.onLeft.add(this.up, this);
            this.input.onEntered.add(this.down, this);
        }
        MenuButtonIncrement.prototype.update = function () {
            _super.prototype.update.call(this);
        };
        MenuButtonIncrement.prototype.down = function () {
            this.animation.switchTo(this.upFrame + 1);
        };

        MenuButtonIncrement.prototype.up = function () {
            this.animation.switchTo(this.upFrame);
        };

        MenuButtonIncrement.prototype.left = function () {
            this.animation.switchTo(this.upFrame);
        };
        return MenuButtonIncrement;
    })(Kiwi.GameObjects.Sprite);
    MenuEntities.MenuButtonIncrement = MenuButtonIncrement;
})(MenuEntities || (MenuEntities = {}));
var MenuEntities;
(function (MenuEntities) {
    var BuyCreditsButton = (function (_super) {
        __extends(BuyCreditsButton, _super);
        function BuyCreditsButton(state, x, y) {
            _super.call(this, state, state.textures.buyButton, x, y);

            this.input.onDown.add(function () {
                this.cellIndex = 1;
            }, this);

            this.input.onUp.add(function () {
                this.cellIndex = 0;
            }, this);

            this.input.onEntered.add(function () {
                this.cellIndex = 1;
            }, this);

            this.input.onLeft.add(function () {
                this.cellIndex = 0;
            }, this);
        }
        return BuyCreditsButton;
    })(Kiwi.GameObjects.Sprite);
    MenuEntities.BuyCreditsButton = BuyCreditsButton;
})(MenuEntities || (MenuEntities = {}));
var Tiles;
(function (Tiles) {
    var Tile0 = (function (_super) {
        __extends(Tile0, _super);
        function Tile0(state, cacheID, x, y, num) {
            _super.call(this, state, cacheID, x, y, num);
        }
        return Tile0;
    })(Tiles.Tile);
    Tiles.Tile0 = Tile0;
})(Tiles || (Tiles = {}));
var Tiles;
(function (Tiles) {
    var Tile1 = (function (_super) {
        __extends(Tile1, _super);
        function Tile1(state, cacheID, x, y, num) {
            _super.call(this, state, cacheID, x, y, num);
            this.solid = true;
        }
        return Tile1;
    })(Tiles.Tile);
    Tiles.Tile1 = Tile1;
})(Tiles || (Tiles = {}));
var Tiles;
(function (Tiles) {
    var Tile2 = (function (_super) {
        __extends(Tile2, _super);
        function Tile2(state, cacheID, x, y, num) {
            _super.call(this, state, cacheID, x, y, num);
            this.friction = 0.5;
        }
        return Tile2;
    })(Tiles.Tile);
    Tiles.Tile2 = Tile2;
})(Tiles || (Tiles = {}));
var Tiles;
(function (Tiles) {
    var Tile3 = (function (_super) {
        __extends(Tile3, _super);
        function Tile3(state, cacheID, x, y, num) {
            _super.call(this, state, cacheID, x, y, num);
            this.death = true;
        }
        return Tile3;
    })(Tiles.Tile);
    Tiles.Tile3 = Tile3;
})(Tiles || (Tiles = {}));
var Tiles;
(function (Tiles) {
    var Tile4 = (function (_super) {
        __extends(Tile4, _super);
        function Tile4(state, cacheID, x, y, num) {
            _super.call(this, state, cacheID, x, y, num);
            this.trench = true;
            this.occupied = false;
        }
        return Tile4;
    })(Tiles.Tile);
    Tiles.Tile4 = Tile4;
})(Tiles || (Tiles = {}));
var Levels;
(function (Levels) {
    var Level1 = (function () {
        /*
        map
        text(???) one off pictures
        props
        set acc of cannon
        set freq of cannon
        set type of cannon
        set type of node
        set wait for node release
        set angle for node, count [[[0,3],[1,3],[90,1]],false]
        set leeway of node 0=no leeway, PI = go fucking nuts
        general wait var
        release zorb thing
        dynamic call in
        place assets x,y
        set starting cash
        set player nodes inactive
        set player node active
        timer - with clock?
        player 1 perks - customized
        soft pop 1 player [img, y]
        set cpu colour
        custom wait: wait til cannon has fired, wait til target has been desroyed, etc
        */
        function Level1(levelData) {
            this.myLevelData = [
                [1, 2],
                [
                    ['wait', 0.01],
                    ['activateCannon', 1, false],
                    ['activateCallins', 1, false],
                    ['activateCannon', 2, false],
                    ['activateCallins', 2, false],
                    ['wait', 0.1],
                    ['doText', 'WAVE 1', 'WAVE 1'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'The ship took heavy damage, you need to buy the engineers time to get systems operational.'],
                    ['wait', 0.5],
                    ['doText', 'CDR. Murkington', 'BUILD A RIFLE INFANTRY FACTORY. @ Take \'em out.'],
                    ['activateCallins', 1, false],
                    ['tutorial'],
                    ['removeNode', 0, 1],
                    ['removeNode', 1, 1],
                    ['removeNode', 2, 1],
                    ['removeNode', 3, 1],
                    ['removeNode', 4, 1],
                    ['removeNode', 5, 1],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['lock', 'Vehicles'],
                    ['unlock', 'Soldiers'],
                    ['setNodeTypeAvailable', 0, 1, false],
                    ['setNodeTypeAvailable', 0, 1, true],
                    ['setNodeTypeAvailable', 1, 1, false],
                    ['setNodeTypeAvailable', 2, 1, false],
                    ['setNodeTypeAvailable', 0, 2, false],
                    ['setNodeTypeAvailable', 0, 2, true],
                    ['setNodeTypeAvailable', 1, 2, false],
                    ['setNodeTypeAvailable', 2, 2, false],
                    ['setUpgradeLimit', 1, 0, 1],
                    ['setUpgradeLimit', 1, 1, 2],
                    ['setUpgradeLimit', 1, 2, 3],
                    ['setUpgradeLimit', 2, 0, 1],
                    ['setUpgradeLimit', 2, 1, 2],
                    ['setUpgradeLimit', 2, 2, 3],
                    ['setCredits', 1, 150],
                    ['wait', 0.1],
                    ['generateNode', 3, 1],
                    ['wait', 2],
                    ['doText', 'CDR. Murkington', 'We have incoming troops. @ LAUNCH RIFLEMEN! Defend the tub!'],
                    ['wait', 3],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeProgress', 2, 2, 0],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 1, 0],
                    ['nodeLevel', 2, 2, 0, 1],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 420],
                    ['activateCallins', 1, false],
                    ['wave'],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 2'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'Engineers have our CANNON MACHINEGUN ONLINE.'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'We need more men! @ UPGRADE INFANTRY TO LEVEL 2.'],
                    ['clearWave'],
                    ['activateCannon', 1, true],
                    ['setUpgradeLimit', 1, 0, 2],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeProgress', 2, 2, 100],
                    ['setUpgradeLimit', 1, 0, 2],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 1, 0],
                    ['nodeLevel', 2, 2, 0, 2],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 70],
                    ['wave'],
                    ['addTokens', 2],
                    ['stopAutoFire'],
                    ['activateCannon', 2, false],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 3'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'We have ANOTHER FACTORY ONLINE, @ BUILD MORE RIFLE INFANTRY and get em into the field.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 1800, 300, 1],
                    ['generateNode', 2, 1],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['wait', 0.1],
                    ['nodeProgress', 2, 2, 100],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 1, 0],
                    ['nodeLevel', 2, 2, 0, 2],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 70],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeProgress', 3, 2, 100],
                    ['setUpgradeLimit', 1, 0, 2],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 1, 0],
                    ['nodeLevel', 3, 2, 0, 2],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 70],
                    ['doText', 'CDR. Murkington', 'It looks like the ENEMY @ HAS ACTIVATED THEIR CANNON.'],
                    ['wait', 0.5],
                    ['wave'],
                    ['addTokens', 2],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 4'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'Incoming FLAMER INFANTRY, @ keep your distance those guys are nasty.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 1, 0],
                    ['nodeLevel', 2, 2, 0, 2],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 70],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 1, 0],
                    ['nodeLevel', 3, 2, 0, 2],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 50],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeProgress', 1, 2, 100],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 1, 2],
                    ['nodeLevel', 1, 2, 2, 1],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 50],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wait', 10],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 2],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 5'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'Incoming ALPHA TEAM DROPSHIPS! @ Hold them off!'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['callInHeli', 2, 200, 300],
                    ['callInHeli', 2, 500, 300],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wait', 5],
                    ['wave'],
                    ['addTokens', 2],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 6'],
                    ['setNodeTypeAvailable', 1, 1, true],
                    ['wait', 0.1],
                    ['setUpgradeLimit', 1, 1, 2],
                    ['activateCallins', 1, true],
                    ['doText', 'CDR. Murkington', 'Engineers have the Coms Array back online, WE NOW HAVE CALL IN SUPPORT.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 1, 1],
                    ['nodeLevel', 1, 2, 1, 2],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 75],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 1, 0],
                    ['nodeLevel', 3, 2, 0, 2],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 70],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeProgress', 2, 2, 100],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 2, 0],
                    ['nodeLevel', 2, 2, 0, 1],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 300],
                    ['wait', 1],
                    ['doText', 'CDR. Murkington', 'The enemy are sending an APC at us, @ UNLOCK BAZOOKA INFANTRY and stop them.'],
                    ['wait', 5],
                    ['callInHeli', 1, 200, 700],
                    ['wait', 10],
                    ['callInBombs', 200, 300, 300, 400, 2],
                    ['wait', 10],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 1000, 40, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 2],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 7'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'The engineers have @ ANOTHER FACTORY READY.'],
                    ['generateNode', 1, 1],
                    ['setUpgradeLimit', 1, 0, 2],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeProgress', 2, 2, 100],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 2, 0],
                    ['nodeLevel', 2, 2, 0, 1],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 500],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 1, 0],
                    ['nodeLevel', 4, 2, 0, 2],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 200],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 1, 0],
                    ['nodeLevel', 3, 2, 0, 2],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 100],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 1, 1],
                    ['nodeLevel', 1, 2, 1, 1],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 60],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wait', 10],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 1000, 50, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 2],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 8'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'The enemy have another factory ready.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 1, 2],
                    ['nodeLevel', 1, 2, 2, 1],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 500],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 1, 0],
                    ['nodeLevel', 2, 2, 0, 2],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 500],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeProgress', 3, 2, 100],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 2, 0],
                    ['nodeLevel', 3, 2, 0, 1],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 700],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 1, 0],
                    ['nodeLevel', 4, 2, 0, 3],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 500],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 1, 2],
                    ['nodeLevel', 5, 2, 2, 1],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 10],
                    ['wait', 10],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 1000, 50, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 2],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 9'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'Let \'em have it.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['generateNode', 0, 2],
                    ['activateNode', 0, 2],
                    ['nodeProgress', 0, 2, 100],
                    ['nodeLeeway', 0, 2, 20],
                    ['nodeType', 0, 2, 1, 0],
                    ['nodeLevel', 0, 2, 0, 1],
                    ['nodeAngle', 0, 2, 0],
                    ['nodeFrequency', 0, 2, 600],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 1, 2],
                    ['nodeLevel', 1, 2, 2, 1],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 400],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeProgress', 3, 2, 100],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 2, 0],
                    ['nodeLevel', 3, 2, 0, 1],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 500],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 1, 0],
                    ['nodeLevel', 4, 2, 0, 1],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 500],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeProgress', 5, 2, 100],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 1, 2],
                    ['nodeLevel', 5, 2, 2, 1],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 500],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 1000, 50, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 2],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 10'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['doText', 'CDR. Murkington', 'MORE DROPSHIPS. @ I sense a pattern...'],
                    ['wait', 0.1],
                    ['callInHeli', 2, 200, 300],
                    ['callInHeli', 2, 500, 300],
                    ['callInHeli', 2, 700, 300],
                    ['wait', 5],
                    ['wave'],
                    ['addTokens', 5],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['doText', 'WAVE 11'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'Hmmm, looks like they are bringing in SNIPER TANKS for support.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeProgress', 5, 2, 100],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 2, 1],
                    ['nodeLevel', 5, 2, 1, 1],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 20],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeProgress', 1, 2, 100],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 1, 2],
                    ['nodeLevel', 1, 2, 2, 1],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 10],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 1000, 60, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 5],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['doText', 'WAVE 12'],
                    ['wait', 1.0],
                    ['doText', 'CDR. Murkington', 'There goes another one, @ lets see if he can play some catch!'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['generateNode', 0, 2],
                    ['activateNode', 0, 2],
                    ['nodeProgress', 0, 2, 100],
                    ['nodeLeeway', 0, 2, 20],
                    ['nodeType', 0, 2, 1, 0],
                    ['nodeLevel', 0, 2, 0, 2],
                    ['nodeAngle', 0, 2, 0],
                    ['nodeFrequency', 0, 2, 200],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeProgress', 1, 2, 100],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 1, 2],
                    ['nodeLevel', 1, 2, 2, 1],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 200],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeProgress', 2, 2, 100],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 1, 0],
                    ['nodeLevel', 2, 2, 0, 1],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 70],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeProgress', 3, 2, 100],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 1, 2],
                    ['nodeLevel', 3, 2, 2, 2],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 400],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeProgress', 5, 2, 100],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 1, 0],
                    ['nodeLevel', 4, 2, 0, 2],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 800],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeProgress', 5, 2, 100],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 2, 1],
                    ['nodeLevel', 5, 2, 1, 1],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 200],
                    ['wait', 20],
                    ['callInBombs', 250, 300, 310, 400, 2],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 1000, 40, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wait', 20],
                    ['callInBombs', 350, 400, 210, 300, 2],
                    ['wait', 1],
                    ['callInBombs', 375, 425, 240, 330, 2],
                    ['wait', 1],
                    ['callInBombs', 400, 450, 270, 360, 2],
                    ['wait', 1],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 5],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 13'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'Now it is getting serious.'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'Backup napalm stock has been replenished @ FLAMER INFANTRY NOW AVAILABLE.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['setNodeTypeAvailable', 2, 1, true],
                    ['setUpgradeLimit', 1, 0, 2],
                    ['setUpgradeLimit', 1, 1, 2],
                    ['setUpgradeLimit', 1, 2, 2],
                    ['wait', 5],
                    ['generateNode', 4, 1],
                    ['generateNode', 0, 2],
                    ['nodeProgress', 0, 2, 100],
                    ['activateNode', 0, 2],
                    ['nodeLeeway', 0, 2, 20],
                    ['nodeType', 0, 2, 1, 0],
                    ['nodeLevel', 0, 2, 0, 2],
                    ['nodeAngle', 0, 2, 0],
                    ['nodeFrequency', 0, 2, 400],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 1, 2],
                    ['nodeLevel', 1, 2, 2, 1],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 100],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 1, 0],
                    ['nodeLevel', 2, 2, 0, 2],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 120],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeProgress', 3, 2, 100],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 2, 0],
                    ['nodeLevel', 3, 2, 0, 1],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 500],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 1, 2],
                    ['nodeLevel', 4, 2, 2, 1],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 80],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeProgress', 5, 2, 100],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 2, 1],
                    ['nodeLevel', 5, 2, 1, 1],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 20],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 5],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 14'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'I will be impressed if you get through this without a callin.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['generateNode', 0, 2],
                    ['activateNode', 0, 2],
                    ['nodeProgress', 0, 2, 100],
                    ['nodeLeeway', 0, 2, 20],
                    ['nodeType', 0, 2, 2, 1],
                    ['nodeLevel', 0, 2, 1, 1],
                    ['nodeAngle', 0, 2, 0],
                    ['nodeFrequency', 0, 2, 200],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 1, 0],
                    ['nodeLevel', 1, 2, 0, 2],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 70],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 1, 0],
                    ['nodeLevel', 2, 2, 0, 1],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 70],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeProgress', 3, 2, 100],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 2, 1],
                    ['nodeLevel', 3, 2, 1, 1],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 600],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeProgress', 4, 2, 100],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 1, 2],
                    ['nodeLevel', 4, 2, 2, 1],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 80],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeProgress', 5, 2, 100],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 1, 0],
                    ['nodeLevel', 5, 2, 0, 1],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 100],
                    ['wait', 5],
                    ['callInHeli', 2, 200, 300],
                    ['wait', 10],
                    ['callInHeli', 2, 200, 300],
                    ['wait', 10],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 20, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wait', 1],
                    ['callInBombs', 200, 300, 300, 400, 2],
                    ['wait', 1],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 1],
                    ['callInBombs', 200, 520, 300, 620, 2],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 15, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 5],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 15'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['doText', 'CDR. Murkington', 'How predictable.'],
                    ['wait', 0.1],
                    ['callInHeli', 2, 100, 300],
                    ['callInHeli', 2, 200, 300],
                    ['callInHeli', 2, 300, 300],
                    ['callInHeli', 2, 400, 300],
                    ['wait', 5],
                    ['wave'],
                    ['addTokens', 7],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 16'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'Engineers finally got our @ MECH FACTORIES ONLINE.'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'We can now build the @ SNIPER TANK.'],
                    ['wait', 0.1],
                    ['unlock', 'Vehicles'],
                    ['setNodeTypeAvailable', 0, 2, false],
                    ['setNodeTypeAvailable', 1, 2, true],
                    ['setNodeTypeAvailable', 2, 2, false],
                    ['clearWave'],
                    ['wait', 0.1],
                    ['generateNode', 0, 1],
                    ['setUpgradeLimit', 2, 1, 1],
                    ['wait', 5],
                    ['generateNode', 0, 2],
                    ['activateNode', 0, 2],
                    ['nodeProgress', 0, 2, 100],
                    ['nodeLeeway', 0, 2, 20],
                    ['nodeType', 0, 2, 2, 1],
                    ['nodeLevel', 0, 2, 1, 1],
                    ['nodeAngle', 0, 2, 0],
                    ['nodeFrequency', 0, 2, 200],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 1, 2],
                    ['nodeLevel', 1, 2, 2, 1],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 120],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 1, 2],
                    ['nodeLevel', 2, 2, 2, 1],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 120],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 1, 1],
                    ['nodeLevel', 3, 2, 1, 1],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 60],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeProgress', 4, 2, 100],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 1, 0],
                    ['nodeLevel', 4, 2, 0, 3],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 400],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 1, 1],
                    ['nodeLevel', 5, 2, 1, 1],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 60],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wait', 10],
                    ['callInHeli', 2, 200, 300],
                    ['wait', 15],
                    ['callInHeli', 2, 200, 300],
                    ['wait', 12],
                    ['callInBombs', 200, 300, 300, 400, 2],
                    ['wait', 1],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 1],
                    ['callInBombs', 200, 520, 300, 620, 2],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['callInBombs', 200, 300, 300, 400, 2],
                    ['wait', 1],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 1],
                    ['callInBombs', 200, 520, 300, 620, 2],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 7],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 17'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'All our factories are at your command.'],
                    ['doText', 'CDR. Murkington', 'The APC can now be built in the MECH FACTORY.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['setNodeTypeAvailable', 2, 0, true],
                    ['generateNode', 5, 1],
                    ['setUpgradeLimit', 2, 0, 1],
                    ['generateNode', 0, 2],
                    ['activateNode', 0, 2],
                    ['nodeProgress', 0, 2, 100],
                    ['nodeLeeway', 0, 2, 20],
                    ['nodeType', 0, 2, 2, 1],
                    ['nodeLevel', 0, 2, 1, 1],
                    ['nodeAngle', 0, 2, 0],
                    ['nodeFrequency', 0, 2, 200],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 1, 2],
                    ['nodeLevel', 1, 2, 2, 1],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 120],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeProgress', 2, 2, 100],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 2, 0],
                    ['nodeLevel', 2, 2, 0, 2],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 500],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 1, 1],
                    ['nodeLevel', 3, 2, 1, 1],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 60],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 1, 0],
                    ['nodeLevel', 4, 2, 0, 1],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 80],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeProgress', 5, 2, 100],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 2, 1],
                    ['nodeLevel', 5, 2, 1, 1],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 100],
                    ['wait', 12],
                    ['callInBombs', 200, 300, 300, 400, 2],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 1],
                    ['callInBombs', 200, 520, 300, 620, 2],
                    ['wait', 12],
                    ['callInBombs', 200, 300, 300, 400, 2],
                    ['wait', 1],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 10],
                    ['callInBombs', 200, 520, 300, 620, 2],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 1800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 7],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['doText', 'WAVE 18'],
                    ['doText', 'CDR. Murkington', 'It will not get any easier.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['generateNode', 0, 2],
                    ['activateNode', 0, 2],
                    ['nodeProgress', 0, 2, 100],
                    ['nodeLeeway', 0, 2, 20],
                    ['nodeType', 0, 2, 2, 1],
                    ['nodeLevel', 0, 2, 1, 1],
                    ['nodeAngle', 0, 2, 0],
                    ['nodeFrequency', 0, 2, 600],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeProgress', 1, 2, 100],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 1, 2],
                    ['nodeLevel', 1, 2, 2, 2],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 400],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeProgress', 2, 2, 100],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 2, 0],
                    ['nodeLevel', 2, 2, 0, 1],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 600],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeProgress', 3, 2, 100],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 1, 2],
                    ['nodeLevel', 3, 2, 2, 1],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 50],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 1, 1],
                    ['nodeLevel', 4, 2, 1, 1],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 50],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeProgress', 5, 2, 100],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 2, 1],
                    ['nodeLevel', 5, 2, 1, 1],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 200],
                    ['wait', 12],
                    ['callInBombs', 200, 300, 300, 400, 2],
                    ['wait', 10],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 20],
                    ['callInHeli', 2, 200, 300],
                    ['wait', 15],
                    ['callInHeli', 2, 200, 300],
                    ['wait', 12],
                    ['callInBombs', 200, 520, 300, 620, 2],
                    ['wait', 20],
                    ['callInBombs', 200, 300, 300, 400, 2],
                    ['wait', 1],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 10],
                    ['callInBombs', 200, 520, 300, 620, 2],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 7],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 19'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'Yeah you might want a few airstrikes.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['generateNode', 0, 2],
                    ['activateNode', 0, 2],
                    ['nodeProgress', 0, 2, 100],
                    ['nodeLeeway', 0, 2, 20],
                    ['nodeType', 0, 2, 2, 1],
                    ['nodeLevel', 0, 2, 2, 2],
                    ['nodeAngle', 0, 2, 0],
                    ['nodeFrequency', 0, 2, 300],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeProgress', 1, 2, 100],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 1, 1],
                    ['nodeLevel', 1, 2, 1, 2],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 200],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeProgress', 2, 2, 100],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 2, 0],
                    ['nodeLevel', 2, 2, 0, 1],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 500],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeProgress', 3, 2, 100],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 2, 0],
                    ['nodeLevel', 3, 2, 0, 2],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 700],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 1, 1],
                    ['nodeLevel', 4, 2, 1, 2],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 200],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeProgress', 5, 2, 100],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 2, 1],
                    ['nodeLevel', 5, 2, 1, 1],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 800],
                    ['wait', 10],
                    ['callInBombs', 200, 300, 300, 400, 2],
                    ['wait', 2],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 2],
                    ['callInHeli', 2, 200, 300],
                    ['wait', 10],
                    ['callInHeli', 2, 200, 300],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 10],
                    ['callInBombs', 200, 520, 300, 620, 2],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 50, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 7],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 20'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'Again? Seriously.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['callInHeli', 2, 100, 300],
                    ['callInHeli', 2, 200, 300],
                    ['callInHeli', 2, 300, 300],
                    ['callInHeli', 2, 400, 300],
                    ['wait', 50],
                    ['callInHeli', 2, 100, 300],
                    ['callInHeli', 2, 200, 300],
                    ['callInHeli', 2, 300, 300],
                    ['callInHeli', 2, 400, 300],
                    ['wait', 5],
                    ['callInHeal', 2, 100, 300],
                    ['callInHeal', 2, 200, 300],
                    ['callInHeal', 2, 300, 300],
                    ['callInHeal', 2, 400, 300],
                    ['wait', 5],
                    ['callInBombs', 500, 520, 600, 620, 2],
                    ['wait', 2],
                    ['callInBombs', 600, 300, 700, 400, 2],
                    ['wait', 1],
                    ['callInBombs', 500, 410, 600, 510, 2],
                    ['wait', 1],
                    ['callInBombs', 600, 520, 700, 620, 2],
                    ['wave'],
                    ['addTokens', 10],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 21'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'You show real promise. You can now UPGRADE INFANTRY TO LEVEL 3.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['setUpgradeLimit', 1, 0, 3],
                    ['setUpgradeLimit', 1, 1, 3],
                    ['setUpgradeLimit', 1, 2, 3],
                    ['generateNode', 0, 2],
                    ['activateNode', 0, 2],
                    ['nodeProgress', 0, 2, 100],
                    ['nodeLeeway', 0, 2, 20],
                    ['nodeType', 0, 2, 1, 1],
                    ['nodeLevel', 0, 2, 1, 2],
                    ['nodeAngle', 0, 2, 0],
                    ['nodeFrequency', 0, 2, 200],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeProgress', 1, 2, 100],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 1, 0],
                    ['nodeLevel', 1, 2, 0, 2],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 400],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeProgress', 2, 2, 100],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 2, 1],
                    ['nodeLevel', 2, 2, 1, 2],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 500],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeProgress', 3, 2, 100],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 2, 1],
                    ['nodeLevel', 3, 2, 1, 1],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 500],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 1, 2],
                    ['nodeLevel', 4, 2, 2, 2],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 400],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeProgress', 5, 2, 100],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 2, 0],
                    ['nodeLevel', 5, 2, 0, 1],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 200],
                    ['wait', 12],
                    ['callInBombs', 500, 300, 600, 400, 2],
                    ['wait', 10],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 30],
                    ['callInHeli', 2, 400, 300],
                    ['wait', 15],
                    ['callInHeli', 2, 400, 600],
                    ['wait', 1],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 10],
                    ['callInBombs', 200, 520, 300, 620, 2],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 1000, 40, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 10],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 22'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'Looks like the enemy have TANKS now.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['generateNode', 0, 2],
                    ['activateNode', 0, 2],
                    ['nodeProgress', 0, 2, 100],
                    ['nodeLeeway', 0, 2, 20],
                    ['nodeType', 0, 2, 1, 0],
                    ['nodeLevel', 0, 2, 0, 2],
                    ['nodeAngle', 0, 2, 0],
                    ['nodeFrequency', 0, 2, 300],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeProgress', 1, 2, 100],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 2, 2],
                    ['nodeLevel', 1, 2, 2, 1],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 200],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeProgress', 2, 2, 100],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 1, 2],
                    ['nodeLevel', 2, 2, 2, 2],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 500],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeProgress', 3, 2, 100],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 2, 0],
                    ['nodeLevel', 3, 2, 0, 1],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 400],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 1, 0],
                    ['nodeLevel', 4, 2, 0, 2],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 300],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeProgress', 5, 2, 100],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 1, 0],
                    ['nodeLevel', 5, 2, 0, 1],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 100],
                    ['wait', 2],
                    ['callInBombs', 500, 300, 600, 400, 2],
                    ['wait', 1],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 3],
                    ['callInHeli', 2, 400, 300],
                    ['wait', 2],
                    ['callInHeli', 2, 400, 600],
                    ['wait', 1],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 1],
                    ['callInBombs', 200, 520, 300, 620, 2],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 10],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 23'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'I\'m not a fan of these guys.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['generateNode', 0, 2],
                    ['activateNode', 0, 2],
                    ['nodeProgress', 0, 2, 100],
                    ['nodeLeeway', 0, 2, 20],
                    ['nodeType', 0, 2, 1, 0],
                    ['nodeLevel', 0, 2, 0, 2],
                    ['nodeAngle', 0, 2, 0],
                    ['nodeFrequency', 0, 2, 300],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeProgress', 1, 2, 100],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 2, 2],
                    ['nodeLevel', 1, 2, 2, 1],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 200],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeProgress', 2, 2, 100],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 1, 0],
                    ['nodeLevel', 2, 2, 0, 2],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 200],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeProgress', 3, 2, 100],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 2, 0],
                    ['nodeLevel', 3, 2, 0, 2],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 400],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 1, 1],
                    ['nodeLevel', 4, 2, 1, 2],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 300],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeProgress', 5, 2, 100],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 2, 2],
                    ['nodeLevel', 5, 2, 2, 2],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 300],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['callInBombs', 500, 300, 600, 400, 2],
                    ['wait', 30],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 1],
                    ['callInHeli', 2, 400, 300],
                    ['wait', 1],
                    ['callInHeli', 2, 400, 600],
                    ['wait', 10],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 2],
                    ['callInBombs', 200, 520, 300, 620, 2],
                    ['wait', 2],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 10],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 24'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'You now have TANKS.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['setNodeTypeAvailable', 2, 2, true],
                    ['setUpgradeLimit', 2, 2, 2],
                    ['generateNode', 0, 2],
                    ['activateNode', 0, 2],
                    ['nodeProgress', 0, 2, 100],
                    ['nodeLeeway', 0, 2, 20],
                    ['nodeType', 0, 2, 1, 0],
                    ['nodeLevel', 0, 2, 0, 3],
                    ['nodeAngle', 0, 2, 0],
                    ['nodeFrequency', 0, 2, 400],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeProgress', 1, 2, 100],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 2, 2],
                    ['nodeLevel', 1, 2, 2, 2],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 100],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeProgress', 2, 2, 100],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 1, 0],
                    ['nodeLevel', 2, 2, 0, 2],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 200],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeProgress', 3, 2, 100],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 1, 2],
                    ['nodeLevel', 3, 2, 2, 2],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 500],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 1, 1],
                    ['nodeLevel', 4, 2, 1, 2],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 300],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeProgress', 5, 2, 100],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 2, 2],
                    ['nodeLevel', 5, 2, 2, 2],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 300],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['callInBombs', 500, 300, 600, 400, 2],
                    ['wait', 30],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 1],
                    ['callInHeli', 2, 400, 300],
                    ['wait', 1],
                    ['callInHeli', 2, 400, 600],
                    ['wait', 10],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 2],
                    ['callInBombs', 200, 520, 300, 620, 2],
                    ['wait', 2],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['wave'],
                    ['addTokens', 10],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['wait', 0.1],
                    ['doText', 'WAVE 25'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'All upgrades are available.'],
                    ['wait', 0.1],
                    ['clearWave'],
                    ['setUpgradeLimit', 1, 0, 3],
                    ['setUpgradeLimit', 1, 1, 3],
                    ['setUpgradeLimit', 1, 2, 3],
                    ['setUpgradeLimit', 2, 0, 3],
                    ['setUpgradeLimit', 2, 1, 3],
                    ['setUpgradeLimit', 2, 2, 3],
                    ['wait', 2],
                    ['callInHeli', 2, 100, 300],
                    ['callInHeli', 2, 200, 300],
                    ['callInHeli', 2, 300, 300],
                    ['callInHeli', 2, 400, 300],
                    ['wait', 5],
                    ['callInHeli', 2, 100, 300],
                    ['callInHeli', 2, 200, 300],
                    ['callInHeli', 2, 300, 300],
                    ['callInHeli', 2, 400, 300],
                    ['wait', 5],
                    ['callInHeal', 2, 100, 300],
                    ['callInHeal', 2, 200, 300],
                    ['callInHeal', 2, 300, 300],
                    ['callInHeal', 2, 400, 300],
                    ['wait', 5],
                    ['callInBombs', 500, 520, 600, 620, 2],
                    ['wait', 2],
                    ['callInBombs', 600, 300, 700, 400, 2],
                    ['wait', 1],
                    ['callInBombs', 500, 410, 600, 510, 2],
                    ['wait', 1],
                    ['callInBombs', 600, 520, 700, 620, 2],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['generateNode', 0, 2],
                    ['activateNode', 0, 2],
                    ['nodeProgress', 0, 2, 100],
                    ['nodeLeeway', 0, 2, 20],
                    ['nodeType', 0, 2, 1, 0],
                    ['nodeLevel', 0, 2, 0, 3],
                    ['nodeAngle', 0, 2, 0],
                    ['nodeFrequency', 0, 2, 300],
                    ['generateNode', 1, 2],
                    ['activateNode', 1, 2],
                    ['nodeProgress', 1, 2, 100],
                    ['nodeLeeway', 1, 2, 20],
                    ['nodeType', 1, 2, 2, 0],
                    ['nodeLevel', 1, 2, 0, 2],
                    ['nodeAngle', 1, 2, 0],
                    ['nodeFrequency', 1, 2, 100],
                    ['generateNode', 2, 2],
                    ['activateNode', 2, 2],
                    ['nodeProgress', 2, 2, 100],
                    ['nodeLeeway', 2, 2, 20],
                    ['nodeType', 2, 2, 1, 3],
                    ['nodeLevel', 2, 2, 3, 2],
                    ['nodeAngle', 2, 2, 0],
                    ['nodeFrequency', 2, 2, 150],
                    ['generateNode', 3, 2],
                    ['activateNode', 3, 2],
                    ['nodeProgress', 3, 2, 100],
                    ['nodeLeeway', 3, 2, 20],
                    ['nodeType', 3, 2, 1, 0],
                    ['nodeLevel', 3, 2, 0, 2],
                    ['nodeAngle', 3, 2, 0],
                    ['nodeFrequency', 3, 2, 200],
                    ['generateNode', 4, 2],
                    ['activateNode', 4, 2],
                    ['nodeLeeway', 4, 2, 20],
                    ['nodeType', 4, 2, 2, 1],
                    ['nodeLevel', 4, 2, 1, 2],
                    ['nodeAngle', 4, 2, 0],
                    ['nodeFrequency', 4, 2, 150],
                    ['generateNode', 5, 2],
                    ['activateNode', 5, 2],
                    ['nodeProgress', 5, 2, 100],
                    ['nodeLeeway', 5, 2, 20],
                    ['nodeType', 5, 2, 2, 2],
                    ['nodeLevel', 5, 2, 2, 3],
                    ['nodeAngle', 5, 2, 0],
                    ['nodeFrequency', 5, 2, 100],
                    ['wait', 5],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['callInBombs', 500, 300, 600, 400, 2],
                    ['wait', 30],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 1],
                    ['callInHeli', 2, 400, 300],
                    ['wait', 1],
                    ['callInHeli', 2, 400, 600],
                    ['wait', 10],
                    ['callInBombs', 200, 410, 300, 510, 2],
                    ['wait', 2],
                    ['callInBombs', 200, 520, 300, 620, 2],
                    ['wait', 2],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 800, 30, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['callInBombs', 300, 100, 300, 100, 2],
                    ['wait', 1],
                    ['callInBombs', 320, 120, 320, 120, 2],
                    ['wait', 1],
                    ['callInBombs', 340, 140, 340, 140, 2],
                    ['wait', 15],
                    ['callInHeli', 2, 400, 300],
                    ['wait', 1],
                    ['callInHeli', 2, 400, 600],
                    ['wait', 10],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 1000, 60, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['callInBombs', 350, 150, 350, 150, 2],
                    ['wait', 1],
                    ['callInBombs', 320, 120, 320, 120, 2],
                    ['wait', 1],
                    ['callInBombs', 400, 240, 310, 110, 2],
                    ['wait', 15],
                    ['callInHeli', 2, 200, 200],
                    ['wait', 1],
                    ['callInHeli', 2, 300, 600],
                    ['wait', 10],
                    ['activateCannon', 2, true],
                    ['activateAutoCannon', 1000, 60, 1],
                    ['stopAutoFire', 2, true],
                    ['activateCannon', 2, false],
                    ['callInBombs', 350, 150, 350, 150, 2],
                    ['wait', 1],
                    ['callInBombs', 320, 120, 320, 120, 2],
                    ['wait', 1],
                    ['callInBombs', 400, 240, 310, 110, 2],
                    ['wait', 15],
                    ['callInBombs', 350, 150, 350, 150, 2],
                    ['wait', 1],
                    ['callInBombs', 320, 120, 320, 120, 2],
                    ['wait', 1],
                    ['callInBombs', 400, 240, 310, 110, 2],
                    ['wait', 15],
                    ['wave'],
                    ['removeNode', 0, 2],
                    ['removeNode', 1, 2],
                    ['removeNode', 2, 2],
                    ['removeNode', 3, 2],
                    ['removeNode', 4, 2],
                    ['removeNode', 5, 2],
                    ['addTokens', 50],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'MISSION COMPLETED. Great work soldier. @ I\'ve authorised 50 BONUS TOKENS.'],
                    ['wait', 0.1],
                    ['doText', 'CDR. Murkington', 'The engineers want your feedback. @ Email them at contact@nyuknyukgames.com'],
                    ['wait', 5.0],
                    ['end']
                ]
            ];

            levelData.push(this.myLevelData);
        }
        return Level1;
    })();
    Levels.Level1 = Level1;
})(Levels || (Levels = {}));
var Maps;
(function (Maps) {
    var Map1 = (function () {
        /*
        Map data is only the appearance and tile collisions of the terrain
        0 - normal tile. walkable, no interaction
        1 - block tile. boulders, pits, things you walk around
        2 - slow tile. sand, water, things you walk through, affecting your speed
        3 - instant death
        4 - trench. MUST have 3 in a row, and not touch other trenches
        */
        function Map1(mapData) {
            this.myMapData = [
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            ];
            mapData.push(this.myMapData);
        }
        return Map1;
    })();
    Maps.Map1 = Map1;
})(Maps || (Maps = {}));
var Maps;
(function (Maps) {
    var Map2 = (function () {
        /*
        Map data is only the appearance and tile collisions of the terrain
        0 - normal tile. walkable, no interaction
        1 - block tile. boulders, pits, things you walk around
        2 - slow tile. sand, water, things you walk through, affecting your speed
        3 - instant death
        4 - trench. MUST have 3 in a row, and not touch other trenches
        */
        function Map2(mapData) {
            this.myMapData = [
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            ];
            mapData.push(this.myMapData);
        }
        return Map2;
    })();
    Maps.Map2 = Map2;
})(Maps || (Maps = {}));
var Maps;
(function (Maps) {
    var Map3 = (function () {
        /*
        Map data is only the appearance and tile collisions of the terrain
        0 - normal tile. walkable, no interaction
        1 - block tile. boulders, pits, things you walk around
        2 - slow tile. sand, water, things you walk through, affecting your speed
        3 - instant death
        4 - trench. MUST have 3 in a row, and not touch other trenches
        */
        function Map3(mapData) {
            this.myMapData = [
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            ];
            mapData.push(this.myMapData);
        }
        return Map3;
    })();
    Maps.Map3 = Map3;
})(Maps || (Maps = {}));
var Maps;
(function (Maps) {
    var Map4 = (function () {
        /*
        Map data is only the appearance and tile collisions of the terrain
        0 - normal tile. walkable, no interaction
        1 - block tile. boulders, pits, things you walk around
        2 - slow tile. sand, water, things you walk through, affecting your speed
        3 - instant death
        4 - trench. MUST have 3 in a row, and not touch other trenches
        */
        function Map4(mapData) {
            this.myMapData = [
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [2, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0],
                [2, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0],
                [2, 2, 2, 2, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 0, 0],
                [2, 2, 2, 2, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 0, 0],
                [0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 2, 2, 2, 0],
                [0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 2, 2, 2, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            ];
            mapData.push(this.myMapData);
        }
        return Map4;
    })();
    Maps.Map4 = Map4;
})(Maps || (Maps = {}));
var Maps;
(function (Maps) {
    var Map5 = (function () {
        /*
        Map data is only the appearance and tile collisions of the terrain
        0 - normal tile. walkable, no interaction
        1 - block tile. boulders, pits, things you walk around
        2 - slow tile. sand, water, things you walk through, affecting your speed
        3 - instant death
        4 - trench. MUST have 3 in a row, and not touch other trenches
        */
        function Map5(mapData) {
            this.myMapData = [
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            ];
            mapData.push(this.myMapData);
        }
        return Map5;
    })();
    Maps.Map5 = Map5;
})(Maps || (Maps = {}));
var Maps;
(function (Maps) {
    var Map6 = (function () {
        /*
        Map data is only the appearance and tile collisions of the terrain
        0 - normal tile. walkable, no interaction
        1 - block tile. boulders, pits, things you walk around
        2 - slow tile. sand, water, things you walk through, affecting your speed
        3 - instant death
        4 - trench. MUST have 3 in a row, and not touch other trenches
        */
        function Map6(mapData) {
            this.myMapData = [
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            ];
            mapData.push(this.myMapData);
        }
        return Map6;
    })();
    Maps.Map6 = Map6;
})(Maps || (Maps = {}));
/// <reference path="kiwi.d.ts" />
/// <reference path="KiwiLoadingScreen.d.ts" />
/// <reference path="cocoon.d.ts" />
/// <reference path="Tiles/tile.ts" />
/// ============= User ===============
/// <reference path="Managers/WebviewManager.ts" />
/// <reference path="Managers/MessageHandler.ts" />
/// <reference path="Managers/User.ts" />
/// <reference path="Managers/UserManager.ts" />
/// <reference path="Managers/StatManager.ts" />
/// ============= Entity classes =============
/// <reference path="StandOffEntities/movingContent.ts" />
/// <reference path="StandOffEntities/vehicle.ts" />
/// <reference path="StandOffEntities/infantry.ts" />
/// <reference path="StandOffEntities/apc.ts" />
/// <reference path="StandOffEntities/bazooka.ts" />
/// <reference path="StandOffEntities/buildNode.ts" />
/// <reference path="StandOffEntities/buildNodeBase.ts" />
/// <reference path="StandOffEntities/bullet.ts" />
/// <reference path="StandOffEntities/bazookaShell.ts" />
/// <reference path="StandOffEntities/cannonShell.ts" />
/// <reference path="StandOffEntities/machineGunBullet.ts" />
/// <reference path="StandOffEntities/callInButton.ts" />
/// <reference path="StandOffEntities/cannon.ts" />
/// <reference path="StandOffEntities/cannonButton.ts" />
/// <reference path="StandOffEntities/cannonButtonBase.ts" />
/// <reference path="StandOffEntities/cannonProgress.ts" />
/// <reference path="StandOffEntities/effect.ts" />
/// <reference path="StandOffEntities/followingEffect.ts" />
/// <reference path="StandOffEntities/bomber.ts" />
/// <reference path="StandOffEntities/bomb.ts" />
/// <reference path="StandOffEntities/flamer.ts" />
/// <reference path="StandOffEntities/flare.ts" />
/// <reference path="StandOffEntities/helicopter.ts" />
/// <reference path="StandOffEntities/dropper.ts" />
/// <reference path="StandOffEntities/crateDrop.ts" />
/// <reference path="StandOffEntities/crate.ts" />
/// <reference path="StandOffEntities/rifleman.ts" />
/// <reference path="StandOffEntities/selectButton.ts" />
/// <reference path="StandOffEntities/sniper.ts" />
/// <reference path="StandOffEntities/tank.ts" />
/// <reference path="StandOffEntities/tutorial.ts" />
/// <reference path="StandOffEntities/player.ts" />
/// ============= Core classes =============
/// <reference path="Parameters.ts" />
/// <reference path="./myStates/Loader.ts" />
/// <reference path="./myStates/MenuLoader.ts" />
/// <reference path="./myStates/MainMenu.ts" />
/// <reference path="./myStates/AccountSetup.ts" />
/// <reference path="./myStates/Play.ts" />
/// <reference path="./myStates/MainMenu.ts" />
/// <reference path="./myStates/Replay.ts" />
/// <reference path="./myStates/TwoPlayerSetup.ts" />
/// <reference path="./myStates/TwoPlayerSettings.ts" />
/// <reference path="./myStates/TrainingSetup.ts" />
/// <reference path="./myStates/TrainingSettings.ts" />
/// <reference path="./myStates/StoreMenu.ts" />
/// <reference path="./myStates/StatsMenu.ts" />
/// ============= Managers =============
/// <reference path="./Managers/AudioManager.ts" />
/// <reference path="./Managers/ActionManager.ts" />
/// <reference path="./Managers/CallInManager.ts" />
/// <reference path="./Managers/UIManager.ts" />
/// <reference path="./Managers/UnitManager.ts" />
/// <reference path="./Managers/CannonManager.ts" />
/// <reference path="./Managers/GameDataManager.ts" />
/// <reference path="./Managers/CommodityManager.ts" />
/// <reference path="./Managers/PurchaseManager.ts" />
/// <reference path="./Managers/AudioSoundFX.ts" />
/// ================ MENU ENTITIES=================
/// <reference path="MenuEntities/TwoPlayerSetupPanel.ts" />
/// <reference path="MenuEntities/TwoPlayerSettingsPanel.ts" />
/// <reference path="MenuEntities/TwoPlayerSettingsTop.ts" />
/// <reference path="MenuEntities/TwoPlayerSettingsCallinPanel.ts" />
/// <reference path="MenuEntities/TrainingSetupTop.ts" />
/// <reference path="MenuEntities/TrainingSetupBottom.ts" />
/// <reference path="MenuEntities/TrainingSettingsTop.ts" />
/// <reference path="MenuEntities/TrainingSettingsBottom.ts" />
/// <reference path="MenuEntities/TrainingSettingsCallinPanel.ts" />
/// <reference path="MenuEntities/StoreBottom.ts" />
/// <reference path="MenuEntities/StoreTop.ts" />
/// <reference path="MenuEntities/StorePanel.ts" />
/// <reference path="MenuEntities/AnimatedBackground.ts" />
/// <reference path="MenuEntities/MenuButton.ts" />
/// <reference path="MenuEntities/BackgroundShip.ts" />
/// <reference path="MenuEntities/BackgroundClouds.ts" />
/// <reference path="MenuEntities/backgroundAnimations.ts" />
/// <reference path="MenuEntities/UserChoice.ts" />
/// <reference path="MenuEntities/LeaderboardStat.ts" />
/// <reference path="MenuEntities/MenuButtonIncrement.ts" />
/// <reference path="MenuEntities/BuyCreditsButton.ts" />
/// <reference path="MenuEntities/Product.ts" />
/// <reference path="MenuEntities/Purchase.ts" />
/// <reference path="MenuEntities/StoreProduct.ts" />
/// ============= Tile Classes =============
/// <reference path="Tiles/tile0.ts" />
/// <reference path="Tiles/tile1.ts" />
/// <reference path="Tiles/tile2.ts" />
/// <reference path="Tiles/tile3.ts" />
/// <reference path="Tiles/tile4.ts" />
/// ============= Map classes =============
/// <reference path="StandOffLevels/level1.ts" />
/// <reference path="StandOffMaps/map1.ts" />
/// <reference path="StandOffMaps/map2.ts" />
/// <reference path="StandOffMaps/map3.ts" />
/// <reference path="StandOffMaps/map4.ts" />
/// <reference path="StandOffMaps/map5.ts" />
/// <reference path="StandOffMaps/map6.ts" />
var StandOffGame = (function (_super) {
    __extends(StandOffGame, _super);
    function StandOffGame() {
        var gameoptions = {
            renderer: Kiwi.RENDERER_CANVAS,
            debug: Kiwi.DEBUG_OFF,
            deviceTarget: Kiwi.TARGET_COCOON,
            plugins: ['SaveGame', 'GamefrootAccount', 'WebviewCommunicator', 'GamefrootLeaderboard', 'InAppPurchase'],
            bootCallback: this.addManagers.bind(this)
        };

        _super.call(this, null, 'StandOff', null, gameoptions);

        this.mapSelected = 0;
        this.colorsSelected = [1, 2];
        this.muteMusic = false;
        this.muteSFX = false;
        this.playTutorial = true;
    }
    StandOffGame.prototype.addManagers = function () {
        this.userManager = new Managers.UserManager(this);
        this.webview = new Managers.WebviewManager(this);
        this.gameDataManager = new Managers.GameDataManager(this);
        this.commodityManager = new Managers.CommodityManager(this);
    };
    return StandOffGame;
})(Kiwi.Game);

var game = new StandOffGame();

game.stage.resize(768, 1024);

game.states.addState(MyStates.MenuLoader);
game.states.switchState('MenuLoader');
